package com.aia.utility;

import java.util.HashMap;
import java.util.Map;

import com.aia.common.db.DBCommon;
import com.aia.common.model.Lookup;

public class DataLoader {
	private static HashMap<String, String> nationalityList = new HashMap<String, String>();
	private static HashMap<String, String> occupationList = new HashMap<String, String>();
	private static HashMap<String, String> countryList = new HashMap<String, String>();
	private static HashMap<String, String> planList = new HashMap<String, String>();
	private static HashMap<String, String> relationshipList = new HashMap<String, String>();
	private static HashMap<String, Lookup> lookupList = new HashMap<String, Lookup>();

	public synchronized static void loadData() {
		loadNationalityList();
		loadOccupationList();
		loadCountryList();
		loadPlanList();
		loadRelationshipList();
		loadLookupList();
	}
	
	public synchronized static void resetUBPData() {
		resetNotification();
		resetNBDataMart();
		resetClaimsDataMart();
		resetPOSDataMart();
	}
	
	public synchronized static void resetTaxInvImg() {
		resetTaxInvImgNow();
	}

	private static void resetPOSDataMart() {
		DBCommon db = new DBCommon();
		db.updateUBPTableAllRow("NEW", 0, null, "db_pos2..ubp_POSREQ01");
	}

	private static void resetClaimsDataMart() {
		DBCommon db = new DBCommon();
		db.updateUBPTableAllRow("NEW", 0, null, "db_claims..ubp_tclaim_listing");
	}

	private static void resetNBDataMart() {
		DBCommon db = new DBCommon();
		db.updateUBPTableAllRow("NEW", 0, null, "db_nb..tAGMUPDCON");
	}

	private static void resetNotification() {
		DBCommon db = new DBCommon();
		db.updateUBPTableAllRow("NEW", 0, null, "db_iws..ubp_AgentNotification");
	}
	
	private static void resetTaxInvImgNow() {
		DBCommon db = new DBCommon();
		db.deleteTaxInvImgRow();
	}

	private static void loadNationalityList() {
		DBCommon db = new DBCommon();
		
		HashMap<Integer, HashMap<String, String>> nationalityMap = db.getNBLookup("NATIONALITY", "016", "LA");
		
		for(int i = 0; i < nationalityMap.size(); i++) {
			HashMap<String, String> row = nationalityMap.get(i);
			
			nationalityList.put(row.get("FEValue"), row.get("FEDescription"));
		}
	}
	
	private static void loadOccupationList() {
		DBCommon db = new DBCommon();
		
		HashMap<Integer, HashMap<String, String>> occupationMap = db.getNBLookup("OCCUPATION_CODE", "016", "LA");
		
		for(int i = 0; i < occupationMap.size(); i++) {
			HashMap<String, String> row = occupationMap.get(i);
			
			occupationList.put(row.get("FEValue"), row.get("FEDescription"));
		}
	}
	
	private static void loadCountryList() {
		DBCommon db = new DBCommon();
		
		HashMap<Integer, HashMap<String, String>> countryMap = db.getNBLookup("CTRYCODE", "016", "LA");
		
		for(int i = 0; i < countryMap.size(); i++) {
			HashMap<String, String> row = countryMap.get(i);
			
			countryList.put(row.get("FEValue"), row.get("FEDescription"));
		}
	}
	
	private static void loadPlanList() {
		DBCommon db = new DBCommon();
		 Map<String,String> planNames = db.getPlanNames();
		 
		 
		HashMap<Integer, HashMap<String, String>> planMap = db.getPlans();
		
		for(int i = 0; i < planMap.size(); i++) {
			HashMap<String, String> row = planMap.get(i);
			
			String value = row.get("FullName");
			String key = row.get("CompanyCode") + row.get("CoverageCode");

			for(Map.Entry<String,String> entry : planNames.entrySet()) {
				if(key.contains(entry.getKey())) {
					value = entry.getValue();
				}
			}
			
			planList.put(key, value);
		}
	}
	
	private static void loadRelationshipList() {
		DBCommon db = new DBCommon();
		
		HashMap<Integer, HashMap<String, String>> relationshipMap = db.getNBRelationship("016");
		
		for(int i = 0; i < relationshipMap.size(); i++) {
			HashMap<String, String> row = relationshipMap.get(i);
			
			relationshipList.put(row.get("FEValue"), row.get("FEDescription"));
		}
	}
	
	private static void loadLookupList() {
		DBCommon db = new DBCommon();
		
		HashMap<Integer, HashMap<String, String>> lookupMap = db.getLookups();
		
		for(int i = 0; i < lookupMap.size(); i++) {
			HashMap<String, String> row = lookupMap.get(i);
			
			Lookup l = new Lookup();
			l.setType(row.get("LKType"));
			l.setCode(row.get("LKCode"));
			l.setDescription(row.get("LKDescription"));
			l.setCategory(row.get("LKCategory"));
			l.setSubCategory(row.get("LKSubCategory"));
			
			lookupList.put(l.getType() + l.getCode(), l);
		}
	}

	public static HashMap<String, String> getNationalityList() {
		return nationalityList;
	}

	public static HashMap<String, String> getOccupationList() {
		return occupationList;
	}

	public static HashMap<String, String> getCountryList() {
		return countryList;
	}

	public static HashMap<String, String> getPlanList() {
		return planList;
	}

	public static HashMap<String, String> getRelationshipList() {
		return relationshipList;
	}
	
	public static HashMap<String, Lookup> getLookupList() {
		return lookupList;
	}
}
