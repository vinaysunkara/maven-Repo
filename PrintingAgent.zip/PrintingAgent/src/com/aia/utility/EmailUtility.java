package com.aia.utility;

import java.io.IOException;
import java.net.InetAddress;

/*
 * This email class will only works in Linux. It will use mailx as email relay
 */
public class EmailUtility {
	private String sendTo;
	private String sendFrom;
	private String sendCC;
	private String emailTitle;
	private String emailContents;
	private String attachmentPath;
	
	public boolean sendEmail() {
		boolean success = true;
		
		try {
			StringBuffer cmdStr = new StringBuffer();
			
			cmdStr.append("echo \""+ getEmailContents() +"\" | ");
			cmdStr.append("mailx -s \"" + getEmailTitle() +"\" ");
			
			if(!isBlank(getSendCC())) cmdStr.append("-c " + getSendCC() + " ");
			if(!isBlank(getAttachmentPath())) cmdStr.append("-a " + getAttachmentPath() + " ");
			
			if(!isBlank(getSendFrom())) {
				String hostname = InetAddress.getLocalHost().getHostName();
				cmdStr.append("-r \"" + getSendFrom() + "<noreply@" + hostname + ".aia.biz>\" ");
			}
			
			cmdStr.append(getSendTo());
			
			String[] cmdarr = new String[] { "/bin/bash", "-c", cmdStr.toString() };
        
			Runtime.getRuntime().exec(cmdarr);
			
		} catch (IOException e) {
			success = false;
			e.printStackTrace();
			
		} catch (Exception e) {
			success = false;
			e.printStackTrace();
		}
		
		return success;
	}
	
	public static boolean isBlank(Object object) {
		if(object == null || "".equals(object.toString().trim()))
			return true;
		else
			return false;
	}

	public String getSendTo() {
		return sendTo;
	}

	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	public String getSendFrom() {
		return sendFrom;
	}

	public void setSendFrom(String sendFrom) {
		this.sendFrom = sendFrom;
	}

	public String getSendCC() {
		return sendCC;
	}

	public void setSendCC(String sendCC) {
		this.sendCC = sendCC;
	}

	public String getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(String emailTitle) {
		this.emailTitle = emailTitle;
	}

	public String getEmailContents() {
		return emailContents;
	}

	public void setEmailContents(String emailContents) {
		this.emailContents = emailContents;
	}

	public String getAttachmentPath() {
		return attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
}
