package com.aia.coverlater.common.model;

import java.util.Date;

public class Company {
	String address1;	
	String address2;
	String address3;	
	String address4;	
	String address5;	
	String attentionTo;	
	String phoneNum;	
	Date date; 	
	String companyName;	
	String polocyNum;	
	String docTypeName;	
	String billNumber;
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}
	public String getAddress5() {
		return address5;
	}
	public void setAddress5(String address5) {
		this.address5 = address5;
	}
	public String getAttentionTo() {
		return attentionTo;
	}
	public void setAttentionTo(String attentionTo) {
		this.attentionTo = attentionTo;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getPolocyNum() {
		return polocyNum;
	}
	public void setPolocyNum(String polocyNum) {
		this.polocyNum = polocyNum;
	}
	public String getDocTypeName() {
		return docTypeName;
	}
	public void setDocTypeName(String docTypeName) {
		this.docTypeName = docTypeName;
	}
	public String getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}	
	
}
