package com.aia.coverlater.conventional.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.aia.coverlater.common.model.Company;
import com.aia.coverlater.common.model.CompanyDto;
import com.aia.coverlater.common.model.DocTypesDto;

public class CoverLaterConventionalService {

	public void genReport() {
		System.out.println("genReport() " );
		

	}
	
	

  public static void main(String... args){
	  CoverLaterConventionalService cvltr=new CoverLaterConventionalService();
	  cvltr.genReport();
		
	  }


}
