package com.aia.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.json.JSONObject;

import com.aia.common.model.ClaimsData;
import com.aia.common.model.Lookup;
import com.aia.common.model.NBAgentContact;
import com.aia.common.model.Notification;
import com.aia.common.model.POSServiceRequest;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.utility.CommonUtil;
import com.aia.utility.DataLoader;

public class ESBService {
	public HashMap<String, String> callService(String json, int serviceType) throws Exception {
		String esbURL = "";
		CommonFileUtil cfu = new CommonFileUtil();
		
		String esbServiceURL = CommonUtil.getResourceBundle("system").getString("ESBServiceURL");
		
		switch(serviceType) {
			case 1:
				esbURL = esbServiceURL + "/rest/AIA_UBP_Notification.restAPI.insertNotification";
				break;
			case 2:
				esbURL = esbServiceURL + "/rest/AIA_UBP_Policy.restAPI.updateServiceRequest";
				break;
			case 3:
				esbURL = esbServiceURL + "/rest/AIA_UBP_Contact.restAPI.updateContact";
				break;
			case 4: // for claims
				esbURL = esbServiceURL + "/rest/AIA_UBP_Claim.restAPI.updateClaim";
				break;
			default:
				esbURL = "";
				break;
		}
		
		/*String esbUserId = "";
		String esbPassword = "";
		String esbAuthConcat = CommonUtil.decodeXSS(esbUserId) + ":" + CommonUtil.decodeXSS(esbPassword);
		
		BASE64Encoder enc = new BASE64Encoder();
		String encodedAuth = enc.encode(esbAuthConcat.getBytes());
		
		String esbAuth = "Basic " + encodedAuth;
		System.out.println("esbAuth: " + esbAuth);*/
		
		System.out.println("esbURL: " + esbURL);
		System.out.println("json: " + json);
		
		HashMap<String, String> jsonMap = new HashMap<String, String>();
		
		try {
			URL url = new URL(esbURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			//conn.setRequestProperty("Authorization", esbAuth);
			
			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes());
			os.flush();
			
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			StringBuilder strPol = new StringBuilder();
	
			while((output = br.readLine()) != null) {
				strPol.append(output);
			}
	
			String esbResult = strPol.toString();
			conn.disconnect();
			
			System.out.println("ESB result: " + esbResult);
			
			final JSONObject jsonObj = new JSONObject(esbResult);
			
			jsonMap.put("status", jsonObj.getString("status"));
			
			if(!isESBSuccess(jsonMap) && !cfu.isBlank(jsonObj.getString("errorDescription")))
				jsonMap.put("errorDescription", jsonObj.getString("errorDescription"));
			
		} catch(IOException ioe) {
			jsonMap.put("status", "error");
			jsonMap.put("errorDescription", ioe.toString());
			
			System.out.println("ESBService.callService() IO exception: " + ioe.toString());
			ioe.printStackTrace();
		}
		
		return jsonMap;
	}
	
	public String getNotificationJsonString(Notification n) {
		String jsonStr = "";
		
		String category = "";
		String subCategory = "";
		
		try {
			JSONObject main = new JSONObject();
			main.put("type", "");
			main.put("sound", "");
			main.put("title", "");
			main.put("linkModule", "");
			main.put("extLink", "");
			main.put("adHocGroupId", "");
			
			Lookup lookup = DataLoader.getLookupList().get("NOTIFY" + n.getNotificationType());
			if(lookup == null)
				System.out.println("No lookup for " + n.getNotificationType() + "!");
			
			String source = "";
			
			if(lookup != null) {
				if("New Business".equalsIgnoreCase(lookup.getCategory())) source = "NB";
				else if("Claims".equalsIgnoreCase(lookup.getCategory())) source = "CLM";
				else if("Service Request".equalsIgnoreCase(lookup.getCategory())) source = "SR";
				else if("ROP".equalsIgnoreCase(lookup.getCategory())) source = "ROP";
				
				category = lookup.getCategory();
				subCategory = lookup.getSubCategory();
			}
			
			main.put("notificationSource", source);
			main.put("notificationType", n.getNotificationType());
			main.put("notificationCategory", category);
			main.put("notificationSubCategory", subCategory);
			main.put("amount", n.getClaimAmount());
			main.put("statusCode", n.getClaimStatusCode());
			main.put("statusDesc", n.getClaimStatusDesc());
			main.put("coverMember", n.getCoveredMember());
			main.put("hospitalName", n.getHospitalName());
			main.put("policyNo", n.getPolicyNumber());
			main.put("lineOfBusiness", n.getLineOfBusiness());
			main.put("agentCode", n.getAgentCode());
			main.put("subReferenceNo", n.getClaimNo());
			main.put("ownerIdNo",  n.getNric());
			main.put("premiumDueDate", "");
			main.put("ownerName", n.getOwnerName());
			main.put("sourceSystemName", source);
			main.put("serviceRequestType", n.getServiceRequestType());
			main.put("remark", "");
			
			JSONObject reqHeader = new JSONObject();
			reqHeader.put("channel", "UBP");
			
			main.put("reqHeader", reqHeader);
			
			jsonStr = main.toString(0);
			
		} catch(Exception ex) {
			System.out.println("Error while creating json object: " + ex);
		}
		
		return jsonStr.replace("\n", "");
	}
	
	public String getNBUpdateContactJsonString(NBAgentContact ac) {
		String jsonStr = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		CommonFileUtil cfu = new CommonFileUtil();
		
		try {
			JSONObject main = new JSONObject();
			
			main.put("AGNTPFX", ac.getAgentPrefix());
			main.put("AGNTCOY", ac.getAgentCompany());
			main.put("AGNTNUM", ac.getAgentNo());
			main.put("CLNTPFX", ac.getClientPrefix());
			main.put("CLNTCOY", ac.getClientCompany());
			main.put("CLNTNUM", ac.getClientNo());
			main.put("SURNAME", ac.getOwnerName());
			main.put("SECUITYNO", ac.getOwnerIcNo());
			main.put("CLTRACE", ac.getRace());
			main.put("CLTSEX", ac.getGender());
			main.put("CLTDOB", !cfu.isBlank(ac.getDateOfBirth())? sdf.format(ac.getDateOfBirth()): "");
			main.put("RMBLPHONE", ac.getMobileNo());
			main.put("RINTERNET", ac.getEmailAddress());
			main.put("CLRRROLE", ac.getRole());
			main.put("LOB", ac.getLineOfBusiness());
			main.put("CHANNEL", ac.getChannel());
			
			JSONObject reqHeader = new JSONObject();
			reqHeader.put("channel", "UBP");
			
			main.put("reqHeader", reqHeader);
			
			jsonStr = main.toString(0);
			
		} catch(Exception ex) {
			System.out.println("Error while creating json object: " + ex);
		}
		
		return jsonStr.replace("\n", "");
	}
	
	public String getServiceRequestJsonString(POSServiceRequest sr) {
		String jsonStr = "";
		//SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		CommonFileUtil cfu = new CommonFileUtil();
		
		try {
			JSONObject main = new JSONObject();
			
			main.put("POLNUM", sr.getPolicyNo());
			main.put("KEYREQNUM", sr.getKeyRequestNo());
			main.put("REQNUM", sr.getRequestNo());
			main.put("REQTYPE", sr.getReqType());
			main.put("SUBAGTCD", sr.getSubmitAgentCode());
			main.put("REQSTAT", sr.getReqStatus());
			main.put("REQSTATDESC", sr.getReqStatusDesc());
			main.put("REQDATE", !cfu.isBlank(sr.getReqDate())? sdf.format(sr.getReqDate()): "");
			main.put("SYSTEM", sr.getLineOfBusiness());
			main.put("LastUpdDate", !cfu.isBlank(sr.getLastUpdateDate())? sdf.format(sr.getLastUpdateDate()): "");
			
			JSONObject reqHeader = new JSONObject();
			reqHeader.put("channel", "UBP");
			
			main.put("reqHeader", reqHeader);
			
			jsonStr = main.toString(0);
			
		} catch(Exception ex) {
			System.out.println("Error while creating json object: " + ex);
		}
		
		return jsonStr.replace("\n", "");
	}
	
	public String getClaimsDataJsonString(ClaimsData cd) {
		String jsonStr = "";
		//SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		CommonFileUtil cfu = new CommonFileUtil();
		
		try {
			JSONObject main = new JSONObject();
			
			main.put("AGNTNUM", cd.getAgentNo());
			main.put("CLMTYPE", cd.getClaimType());
			main.put("ZCVRMBR", cd.getInsuredPerson());
			main.put("CLAIM", cd.getClaimNo());
			main.put("CLMOCCR", cd.getOccurrence());
			main.put("CLMLOG", cd.getLogNo());
			main.put("CLMSTAC", cd.getClaimStatusCode());
			main.put("CLMSTDS", cd.getClaimStatusDesc());
			main.put("CLMLOGCDE", cd.getLogCode());
			main.put("CLMLOGDSC", cd.getLogDescription());
			main.put("CLMLOGDTE", !cfu.isBlank(cd.getLogDate())? sdf.format(cd.getLogDate()): "");
			main.put("REPNUM", cd.getPolicyNoWithCheckDigit());
			main.put("CHDRNUM", cd.getPolicyNoWithoutCheckDigit());
			main.put("LOB", cd.getLOB());
			main.put("GRPSTAT", cd.getGroupStatusCode());
			main.put("GRPDESC", cd.getGroupStatusDesc());
			main.put("CLAMAMT", cd.getClaimAmount().toString());
			main.put("ZHOSPNM", cd.getHospitalName());
			main.put("CHANNEL", "CLM");
			
			JSONObject reqHeader = new JSONObject();
			reqHeader.put("channel", "UBP");
			
			main.put("reqHeader", reqHeader);
			
			jsonStr = main.toString(0);
			
		} catch(Exception ex) {
			System.out.println("Error while creating json object: " + ex);
		}
		
		return jsonStr.replace("\n", "");
	}
	
	protected boolean isESBSuccess(HashMap<String, String> jsonMap) {
		boolean success = false;
		CommonFileUtil cfu = new CommonFileUtil();
		
		if(!cfu.isBlank(jsonMap) && jsonMap.size() > 0) {
			if(!cfu.isBlank(jsonMap.get("status")) && "success".equalsIgnoreCase(jsonMap.get("status")))
				success = true;
		}
			
		return success;
	}
 	
	public String getJsonString() {
		String jsonStr = "";
		
		try {
			JSONObject main = new JSONObject();
			main.put("POLNUM", "DA01623001");
			main.put("REQNUM", "POS2017A0743464");
			main.put("REQTYPE", "Add Rider");
			main.put("REQSTAT", "RS");
			main.put("REQSTATDESC", "Incomplete");
			main.put("REQDATE", "25-07-17");
			main.put("SYSTEM", "PA");
			main.put("LastUpdDate", "01-08-17");
			
			JSONObject reqHeader = new JSONObject();
			reqHeader.put("channel", "UBP");
			
			main.put("reqHeader", reqHeader);
			
			jsonStr = main.toString(0);
			
		} catch(Exception ex) {
			System.out.println("Error while creating json object: " + ex);
		}
		
		return jsonStr.replace("\n", "");
	}
	
	public static void main(String arg[]) {
		ESBService service = new ESBService();
		
		try {
			//System.out.println(service.callService(service.getJsonString(), 1).toString(0).replace("\n", ""));
			
			HashMap<String, String> jsonMap = service.callService(service.getJsonString(), 1);
			System.out.println(jsonMap.get("status") + ", " + jsonMap.get("errorDescription"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
