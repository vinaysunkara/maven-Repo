package com.aia.service;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.WordUtils;

import com.aia.common.db.DBCommon;
import com.aia.common.model.AgentContract;
import com.aia.common.model.AppForm;
import com.aia.common.model.PolCoverage;
import com.aia.common.model.PolWebForm;
import com.aia.common.model.PolicyInfo;
import com.aia.common.model.RelatedEntity;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericUtil;
import com.aia.utility.DataLoader;

public class ProcessBatch {
	private PolicyInfo policyInfo;
	private PolWebForm polWebForm;
	private AgentContract agentContract;
	private String templateCode;
	private String trxId;
	
	public ProcessBatch(PolicyInfo policyInfo, String templateCode) {
		this.policyInfo = policyInfo;
		this.templateCode = templateCode;
	}
	
	public ProcessBatch(PolWebForm polWebForm, String templateCode) {
		this.polWebForm = polWebForm;
		this.templateCode = templateCode;
	}
	
	public ProcessBatch(String trxId, String templateCode) {
		this.trxId = trxId;
		this.templateCode = templateCode;
	}
	public boolean execute() throws InterruptedException {
		boolean success = false;
		DBCommon db = new DBCommon();
		
		String companyCode = policyInfo.getCompanyCode();
		String policyNo = policyInfo.getPolicyNo();
		
		success = db.updatePrintStatus(companyCode, policyNo, "PROCESS");
		
		HashMap<Integer, HashMap<String, String>> policyInfoMap = db.getPolicyInfo(companyCode, policyNo);
		HashMap<Integer, HashMap<String, String>> covInfoMap = db.getPolCoverage(companyCode, policyNo);
		
		if(policyInfoMap.size() > 0) {
			String languageCode = ("8".equals(policyInfoMap.get(0).get("PolLanguage")))? "EN": "MS";
			//String languageCode = "MS";

			String policyId = policyInfoMap.get(0).get("PolicyID");
			
			List<PolCoverage> polCoverages = processCoverageInfo(covInfoMap, companyCode , policyInfoMap);
			processPolicyInfo(policyInfoMap, polCoverages, languageCode,covInfoMap);
			policyInfo.setCoverages(polCoverages);
			
			HashMap<Integer, HashMap<String, String>> questionMap = db.getAppFormQuestions(policyId);
			AppForm appForm = processAppForm(policyInfoMap, questionMap, languageCode);
			
			HashMap<Integer, HashMap<String, String>> nomineeMap = db.getNominees(policyId);
			List<RelatedEntity> nominees = processNominees(nomineeMap);
			
			HashMap<Integer, HashMap<String, String>> trusteeMap = db.getTrustees(policyId);
			List<RelatedEntity> trustees = processTrustees(trusteeMap);
			
			appForm.setNominees(nominees);
			appForm.setTrustees(trustees);
			
			GeneratePDF gp = new GeneratePDF();
			UploadWF uwf = new UploadWF();
			UploadALPP ualpp = new UploadALPP();
			
			// generate and upload to PFV
			Map<String, ByteArrayOutputStream> pdfBaosMap = gp.genPolicyPDF(policyInfo, appForm, templateCode, languageCode);
			ByteArrayOutputStream fullPdfBaos = uwf.getFullPDF(pdfBaosMap);
			uwf.upload(pdfBaosMap, companyCode, policyNo, false);
			
			// upload to imaging db for ALPP
			ualpp.upload(fullPdfBaos, companyCode, policyNo, policyInfo.getInsuredMykad(), policyInfo.getPolicyDate());
			ualpp.sendEmail(fullPdfBaos, companyCode, policyInfo, appForm, templateCode);
			
			success = db.updatePrintStatus(companyCode, policyNo, "COMPLETE");
			
		} else {
			success = db.updatePrintStatus(companyCode, policyNo, "INCOMPLETE");
		}
		
		return success; 
	}
	
	public boolean executeWebForm() throws InterruptedException {
		boolean success = false;
		DBCommon db = new DBCommon();
		
		String companyCode = "072";
		String policyNo = polWebForm.getPolicyNo();
		
		success = db.updateWebFormPrintStatus(companyCode, policyNo, "PROCESS");
		
		HashMap<Integer, HashMap<String, String>> cwebFormInfoMap = db.getPolWebInfo(policyNo);
		HashMap<Integer, HashMap<String, String>> cwebFormInfoMapNominee = db.getPolWebInfoNominee(policyNo);
		
		if(cwebFormInfoMap.size() > 0) {
			String languageCode = "MS";
			processPolicyInfoForWeb(cwebFormInfoMap,cwebFormInfoMapNominee);
			
			GeneratePDF gp = new GeneratePDF();
			UploadWF uwf = new UploadWF();
			System.out.println("template code  : "+templateCode);
			Map<String, ByteArrayOutputStream> pdfBaosMap = gp.genWebFormPolicyPDF(polWebForm, companyCode, templateCode, languageCode);
			uwf.upload(pdfBaosMap, companyCode, policyNo, true);
			
			success = db.updateWebFormPrintStatus(companyCode, policyNo, "COMPLETE");
		
		} else {
			System.out.println("[ProcessBatch][executeWebForm] MANDATORY FIELD NULL");
			success = db.updateWebFormPrintStatus(companyCode, policyNo, "INCOMPLETE");
		}
		
		return success; 
	}

	public boolean executeAgentForm() throws InterruptedException {
		boolean success = false;
		DBCommon db = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		String languageCode = "EN";
		String policyNo = "";
		String trxId = this.trxId;
//		List<String> templateList = new ArrayList<String>(); 
		String companyCode = "016";
		GeneratePDF genPDF = new GeneratePDF();
		UploadWF uwf = new UploadWF();
		UploadALPP ualpp = new UploadALPP();
//		Map<String, AgentContract> agentTemplateMap = new LinkedHashMap<String, AgentContract>();
		//success = db.updateAgentFormPrintStatus(trxId, "PENDING");
		
		String templCompCode = cu.getTemplCompCode(companyCode);
		String templHome = cu.getTemplatePath() + "/" + templCompCode + "/" + languageCode;
//		String templHome = "D:\\Workspace\\PrintingAgent\\config\\UAT";
		
		List<AgentContract> AgentContractsApp = db.getAgentContractListToPrint(trxId,"APPLICATION","Pending");
		if(!AgentContractsApp.isEmpty()) {
			if(!"".equalsIgnoreCase(trxId) && trxId.trim().length() > 0 ) {
				System.out.println("[ProcessBatch][executeAgentForm] trxId (APPLICATION)..:"+trxId);
				List<String> templateList = new ArrayList<String>(); 
				Map<String, AgentContract> agentTemplateMap = new LinkedHashMap<String, AgentContract>();
			try{
				
				AgentContractsApp = db.getAgentContractListToPrint(trxId,"APPLICATION","Pending");
				if(!cu.isBlank(AgentContractsApp)) {
					// process Each trxId and combine
					for(AgentContract ac: AgentContractsApp) {
						success = db.updateAgentFormPrintStatus(trxId,"APPLICATION", "PROCESSING");				
						this.agentContract = ac;
						if("AGENT".equalsIgnoreCase( agentContract.getAgentRank())){
							if("Conventional".equalsIgnoreCase(agentContract.getLicenseProd())){
								templateList.add("S00006");
								agentTemplateMap.put("S00006", agentContract);
								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00006");
							}else if("Takaful".equalsIgnoreCase(agentContract.getLicenseProd())){
								templateList.add("S00009");
								agentTemplateMap.put("S00009", agentContract);
								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00009");
							}
							
						}else if("UNIT MANAGER".equalsIgnoreCase( agentContract.getAgentRank())){
							if("Conventional".equalsIgnoreCase(agentContract.getLicenseProd())){
								templateList.add("S00007");
								agentTemplateMap.put("S00007", agentContract);
								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00007");
							}else if("Takaful".equalsIgnoreCase(agentContract.getLicenseProd())){
								templateList.add("S00010");
								agentTemplateMap.put("S00010", agentContract);
								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00010");
							}
							
						}else if("DISTRICT MANAGER".equalsIgnoreCase( agentContract.getAgentRank())){
							if("Conventional".equalsIgnoreCase(agentContract.getLicenseProd())){
								templateList.add("S00008");
								agentTemplateMap.put("S00008", agentContract);
								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00008");
							}else if("Takaful".equalsIgnoreCase(agentContract.getLicenseProd())){
								templateList.add("S00011");
								agentTemplateMap.put("S00011", agentContract);
								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00011");
							}
							
						}
					}
					
					for (String template : templateList) {
						System.out.println("[ProcessBatch][executeAgentForm] Templates need to be generate : "+template);
					}
				
					Map<String, ByteArrayOutputStream> pdfBaosMap = genPDF.genAgentManagerPDF( agentTemplateMap,templateList ,templHome);
					
				try {
					if(!cu.isBlank(pdfBaosMap)) {
						Iterator<Map.Entry<String, ByteArrayOutputStream>> it = pdfBaosMap.entrySet().iterator();
						
						while(it.hasNext()) {
							Map<String, ByteArrayOutputStream> pdfBaosMapForSingle = new LinkedHashMap<String, ByteArrayOutputStream>();
							Map.Entry<String, ByteArrayOutputStream> pair = (Map.Entry<String, ByteArrayOutputStream>) it.next();
							pdfBaosMapForSingle.put(pair.getKey(), pair.getValue());
							//String templCode = pair.getKey();
							//ByteArrayOutputStream pdfBaos = pair.getValue();
							uwf.upload(pdfBaosMapForSingle, companyCode, policyNo, false);
						}
					}
				} catch(Exception ex) {
					System.out.println("[ProcessBatch][executeAgentForm] Exception: " + ex.toString());
					ex.printStackTrace();
				}
					
					if(!cu.isBlank(pdfBaosMap)) {
						ualpp.sendEmailAgent(pdfBaosMap, companyCode, agentContract, templateCode);
						System.out.println("[ProcessBatch][executeAgentForm][Application]  ..Email successfully sent to " + agentContract.getIdNo());
						success = db.updateAgentFormPrintStatus(trxId,"APPLICATION", "COMPLETE");
					}else{
						success = db.updateAgentFormPrintStatus(trxId,"APPLICATION", "INCOMPLETE");
					}
					
				}
			
				} catch(Exception ex) {
				System.out.println("[GeneratePDF.genWebFormPolicyPDF] Exception: " + ex.toString());
				ex.printStackTrace();
				}
			
			} else {
				success = db.updateAgentFormPrintStatus(trxId,"PROMOTION", "INCOMPLETE");
			}
		}
		
		
//		List<AgentContract> AgentContractsPro = db.getAgentContractListToPrint(trxId,"PROMOTION","Pending");
//		if(!AgentContractsPro.isEmpty()) {
//			if(!"".equalsIgnoreCase(trxId) && trxId.trim().length() > 0 ) {
//				System.out.println("[ProcessBatch][executeAgentForm] trxId (PROMOTION)..:"+trxId);
//				List<String> templateList = new ArrayList<String>(); 
//				Map<String, AgentContract> agentTemplateMap = new LinkedHashMap<String, AgentContract>();
//			try{
//				
////				List<AgentContract> AgentContractsApp = db.getAgentContractListToPrint(trxId,"APPLICATION","NEW");
//				AgentContractsPro = db.getAgentContractListToPrint(trxId,"PROMOTION","Pending");
//				if(!cu.isBlank(AgentContractsPro) || !AgentContractsPro.isEmpty()) {
//					// process Each trxId and combine
//					System.out.println("Process Started for PROMOTION...");
//					for(AgentContract ac: AgentContractsPro) {
//						success = db.updateAgentFormPrintStatus(trxId,"PROMOTION", "PROCESSING");				
//						this.agentContract = ac;
//						if("AGENT".equalsIgnoreCase( agentContract.getAgentRank())){
//							if("Conventional".equalsIgnoreCase(agentContract.getLicenseProd())){
//								templateList.add("S00006");
//								agentTemplateMap.put("S00006", agentContract);
//								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00006");
//							}else if("Takaful".equalsIgnoreCase(agentContract.getLicenseProd())){
//								templateList.add("S00009");
//								agentTemplateMap.put("S00009", agentContract);
//								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00009");
//							}
//							
//						}else if("UNIT MANAGER".equalsIgnoreCase( agentContract.getAgentRank())){
//							if("Conventional".equalsIgnoreCase(agentContract.getLicenseProd())){
//								templateList.add("S00007");
//								agentTemplateMap.put("S00007", agentContract);
//								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00007");
//							}else if("Takaful".equalsIgnoreCase(agentContract.getLicenseProd())){
//								templateList.add("S00010");
//								agentTemplateMap.put("S00010", agentContract);
//								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00010");
//							}
//							
//						}else if("DISTRICT MANAGER".equalsIgnoreCase( agentContract.getAgentRank())){
//							if("Conventional".equalsIgnoreCase(agentContract.getLicenseProd())){
//								templateList.add("S00008");
//								agentTemplateMap.put("S00008", agentContract);
//								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00008");
//							}else if("Takaful".equalsIgnoreCase(agentContract.getLicenseProd())){
//								templateList.add("S00011");
//								agentTemplateMap.put("S00011", agentContract);
//								System.out.println("[ProcessBatch][executeAgentForm] added ..:S00011");
//							}
//							
//						}
//					}
//					
//					for (String template : templateList) {
//						System.out.println("[ProcessBatch][executeAgentForm] Templates need to be generate : "+template);
//					}
//				
//					Map<String, ByteArrayOutputStream> pdfBaosMap = genPDF.genAgentManagerPDF( agentTemplateMap,templateList ,templHome);
//					
//					/*try {
//						if(!cu.isBlank(pdfBaosMap)) {
//							Iterator<Map.Entry<String, ByteArrayOutputStream>> it = pdfBaosMap.entrySet().iterator();
//							
//							while(it.hasNext()) {
//								Map<String, ByteArrayOutputStream> pdfBaosMapForSingle = new LinkedHashMap<String, ByteArrayOutputStream>();
//								Map.Entry<String, ByteArrayOutputStream> pair = (Map.Entry<String, ByteArrayOutputStream>) it.next();
//								pdfBaosMapForSingle.put(pair.getKey(), pair.getValue());
//								//String templCode = pair.getKey();
//								//ByteArrayOutputStream pdfBaos = pair.getValue();
//								uwf.upload(pdfBaosMapForSingle, companyCode, policyNo, false);
//							}
//						}
//					} catch(Exception ex) {
//						System.out.println("[ProcessBatch][executeAgentForm] Exception: " + ex.toString());
//						ex.printStackTrace();
//					}*/
//					if(!cu.isBlank(pdfBaosMap)) {
////						ualpp.sendEmailAgent(pdfBaosMap, companyCode, agentContract, templateCode);
//						System.out.println("[ProcessBatch][executeAgentForm][Promotion]  ..Email successfully sent to " + agentContract.getIdNo());
//						success = db.updateAgentFormPrintStatus(trxId,"PROMOTION", "COMPLETE");
//					}else{
//						success = db.updateAgentFormPrintStatus(trxId,"PROMOTION", "INCOMPLETE");
//					}
//					
//				}
//			
//				} catch(Exception ex) {
//				System.out.println("[GeneratePDF.genWebFormPolicyPDF] Exception: " + ex.toString());
//				ex.printStackTrace();
//				}
//			
//			} else {
//				success = db.updateAgentFormPrintStatus(trxId,"PROMOTION", "INCOMPLETE");
//			}
//		}
//		
//		
		
		
		return success; 
	}
	
	private void processPolicyInfo(HashMap<Integer, HashMap<String, String>> policyInfoMap, List<PolCoverage> polCoverages, 
			String languageCode ,HashMap<Integer, HashMap<String, String>> covInfoMap) {
		CommonFileUtil cu = new CommonFileUtil();
		String occClass = "";
		String occCode = "";
		DBCommon db = new DBCommon();
		
		policyInfo.setPolicyId(policyInfoMap.get(0).get("PolicyID"));
		policyInfo.setInsuredName(policyInfoMap.get(0).get("InsuredName").toUpperCase());
		policyInfo.setFaceAmount(new BigDecimal(policyInfoMap.get(0).get("FaceAmount")));
		policyInfo.setPolicyDate(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss"));
		if("01".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "1".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			policyInfo.setPaymentType("MONTHLY");
			policyInfo.setPaymentTypeWord("ONE MONTH");
			policyInfo.setPaymentTypeBM("BULANAN");
			policyInfo.setPaymentTypeWordBM("SATU "); 
			policyInfo.setAnnualCommission(new BigDecimal(policyInfoMap.get(0).get("TotalAmount")).multiply(new BigDecimal(0.2)));
			
		}
		if("03".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "3".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			policyInfo.setPaymentType("QUARTERLY");
			policyInfo.setPaymentTypeWord("THREE MONTHS");
			policyInfo.setPaymentTypeBM("SUKU TAHUNAN");
			policyInfo.setPaymentTypeWordBM("TIGA");
			policyInfo.setAnnualCommission(new BigDecimal(policyInfoMap.get(0).get("TotalAmount")).multiply(new BigDecimal(0.2)));
		}
		if("06".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "6".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			policyInfo.setPaymentType("SEMI ANNUAL");
			policyInfo.setPaymentTypeWord("SIX MONTHS");
			policyInfo.setPaymentTypeBM("SETENGAH TAHUNAN");
			policyInfo.setPaymentTypeWordBM("ENAM");
			policyInfo.setAnnualCommission(new BigDecimal(policyInfoMap.get(0).get("TotalAmount")).multiply(new BigDecimal(0.2)));
		}
		if("12".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			policyInfo.setPaymentType("ANNUAL");
			policyInfo.setPaymentTypeWord("TWELVE MONTHS");
			policyInfo.setPaymentTypeBM("TAHUNAN");
			policyInfo.setPaymentTypeWordBM("DUA BELAS");
			policyInfo.setAnnualCommission(new BigDecimal(policyInfoMap.get(0).get("TotalAmount")).multiply(new BigDecimal(0.2)));
		}
		
		policyInfo.setPlanName(polCoverages.get(0).getCoverageName());
		policyInfo.setIssueDate(GenericUtil.parseDate(policyInfoMap.get(0).get("IssueDate"), "yyyy-MM-dd HH:mm:ss"));
		
		
		HashMap<String, String> row = covInfoMap.get(0);
		System.out.println("ProcessBatch (Plan Code):"+ row.get("PlanCode"));
		System.out.println("Process Batch - processPolicyInfo : Occupation "+policyInfoMap.get(0).get("Occupation") );
		
		if(policyInfoMap.get(0).get("NatureOfBiz") != null && policyInfoMap.get(0).get("NatureOfBiz").trim().length()>0){
			occCode = policyInfoMap.get(0).get("NatureOfBiz");
		}else{
			occCode = policyInfoMap.get(0).get("Occupation");
		}
		occClass  = db.getOccupationClass(occCode, row.get("PlanCode"));
		policyInfo.setOccupationClass(occClass);
		System.out.println("ProcessBatch (OccupationClass):"+ policyInfo.getOccupationClass());
//		policyInfo.setOccupationClass("TESTER");
		Locale locale = null;
		for(Locale local: Locale.getAvailableLocales()) {
			if("MY".equalsIgnoreCase(local.getCountry())) locale = local;
		}
		SimpleDateFormat df = new SimpleDateFormat("MMM dd, yyyy", locale);
		System.out.println("date for Malay Version: " + df.format(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss")));
		policyInfo.setIssueDateMS(df.format(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss")).toUpperCase());
		policyInfo.setExpiryDate(GenericUtil.parseDate(policyInfoMap.get(0).get("ExpiryDate"), "yyyy-MM-dd HH:mm:ss"));
		policyInfo.setInsuredAge(Integer.parseInt(policyInfoMap.get(0).get("InsuredAge")));
		policyInfo.setAgeAdmitted(("MS".equalsIgnoreCase(languageCode))? "TIDAK": "NO");
		
		policyInfo.setGender(getGenderDesc(policyInfoMap.get(0).get("Gender"), languageCode).toUpperCase());
		policyInfo.setCurrency(getCurrencyDesc(policyInfoMap.get(0).get("Currency")).toUpperCase());
		
		Integer remYears = 0;
		if(policyInfoMap.get(0).get("InsuredAge") != null && policyInfoMap.get(0).get("InsuredAge").length()>0){
			 remYears = 80 - Integer.parseInt(policyInfoMap.get(0).get("InsuredAge"));
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar c = Calendar.getInstance();
		c.setTime(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss")); // Now use today date.
		System.out.println("processPolicyInfo - Policy Date : "+ c.getTime());
		System.out.println("processPolicyInfo - Remaining Years : "+ remYears);
		c.add(Calendar.YEAR, remYears); // Adding remaining years(Insured Age - 80) to Policy date 
		String output = sdf.format(c.getTime());
		System.out.println("processPolicyInfo - OutPut : "+ output);
		policyInfo.setMaturityDateCICare(c.getTime());
		
		Integer remYearsCIandBasic = 0;
		if(policyInfoMap.get(0).get("InsuredAge") != null && policyInfoMap.get(0).get("InsuredAge").length()>0){
			remYearsCIandBasic = 70 - Integer.parseInt(policyInfoMap.get(0).get("InsuredAge"));
		}
		
		Calendar c1 = Calendar.getInstance();
		c1.setTime(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss")); // Now use today date.
		System.out.println("processPolicyInfo - Policy Date : "+ c1.getTime());
		System.out.println("processPolicyInfo - Remaining Years CI and Med Basic: "+ remYearsCIandBasic);
		c1.add(Calendar.YEAR, remYearsCIandBasic); // Adding remaining years(Insured Age - 80) to Policy date 
		String output1 = sdf.format(c1.getTime());
		System.out.println("processPolicyInfo - OutPut CI and Med basic: "+ output1);
		policyInfo.setMaturityDateCIandMedBasic(c1.getTime());
		
		// set either insured MyKad or other insured IDs
		if(!cu.isBlank(policyInfoMap.get(0).get("InsuredMykad")))
			policyInfo.setInsuredMykad(policyInfoMap.get(0).get("InsuredMykad"));
		else if(!cu.isBlank(policyInfoMap.get(0).get("InsuredPassport")))
			policyInfo.setInsuredMykad(policyInfoMap.get(0).get("InsuredPassport"));
		
		policyInfo.setOwnerName(policyInfoMap.get(0).get("OwnerName").toUpperCase());
		
		// set either owner MyKad or other owner IDs
		if(!cu.isBlank(policyInfoMap.get(0).get("OwnerMykad")))
			policyInfo.setOwnerMykad(policyInfoMap.get(0).get("OwnerMykad"));
		else if(!cu.isBlank(policyInfoMap.get(0).get("OwnerPassport")))
			policyInfo.setOwnerMykad(policyInfoMap.get(0).get("OwnerPassport"));
		
		policyInfo.setOwnerAge(Integer.parseInt(policyInfoMap.get(0).get("OwnerAge")));
		
		policyInfo.setOwnerGender(getGenderDesc(policyInfoMap.get(0).get("OwnerGender"), languageCode).toUpperCase());
		
		String policyDesc = ("MS".equalsIgnoreCase(languageCode))? 
				"POLISI INI ADALAH TANPA PENYERTAAN": "THIS POLICY IS NON-PARTICIPATING";
		policyInfo.setPolicyDesc(policyDesc);
		
		//policyInfo.setGstAmount(new BigDecimal(0));
		policyInfo.setPremiumAmount(new BigDecimal(policyInfoMap.get(0).get("PremiumAmount")));
		policyInfo.setTotalAmount(new BigDecimal(policyInfoMap.get(0).get("TotalAmount")));
		
		policyInfo.setInsuredEmail(policyInfoMap.get(0).get("Email"));
	}
	
private void processPolicyInfoForWeb(HashMap<Integer, HashMap<String, String>> cwebFormInfoMap,HashMap<Integer, HashMap<String, String>> cwebFormInfoMapNominee) {
		
		if(cwebFormInfoMap.get(0).get("appChildPolNo")!=null){
        String childPolicyNo=cwebFormInfoMap.get(0).get("appChildPolNo");
        polWebForm.setPolicyNo(cwebFormInfoMap.get(0).get("policyNo")+ " / "+ childPolicyNo);
		}else{
			polWebForm.setPolicyNo(cwebFormInfoMap.get(0).get("policyNo"));
		}
		
		
		polWebForm.setSerialNo(cwebFormInfoMap.get(0).get("serialNo"));
		polWebForm.setTypePri(cwebFormInfoMap.get(0).get("typePri"));
		polWebForm.setTypeSec(cwebFormInfoMap.get(0).get("typeSec"));
		polWebForm.setRcDate(GenericUtil.parseDate(cwebFormInfoMap.get(0).get("rcDate"), "yyyy-MM-dd HH:mm:ss"));
		polWebForm.setWithOriSignedForm(cwebFormInfoMap.get(0).get("withOriSignedForm"));
		polWebForm.setAppAuthorizeBankStaffID(cwebFormInfoMap.get(0).get("appAuthorizeBankStaffID"));
		polWebForm.setAppSellingAgent(cwebFormInfoMap.get(0).get("appSellingAgent"));
		polWebForm.setAppBankBranch(cwebFormInfoMap.get(0).get("appBankBranch"));
		polWebForm.setAppHseLoanNo(cwebFormInfoMap.get(0).get("appHseLoanNo"));
		polWebForm.setAppCCSSRefno(cwebFormInfoMap.get(0).get("appCCSSRefno"));
		polWebForm.setLaPremiumPayable(new BigDecimal(cwebFormInfoMap.get(0).get("laPremiumPayable").substring(0,cwebFormInfoMap.get(0).get("laPremiumPayable").length()-2)));
		polWebForm.setAppStaffName(cwebFormInfoMap.get(0).get("appStaffName"));
		polWebForm.setAppWitnessName(cwebFormInfoMap.get(0).get("appWitnessName"));
		polWebForm.setAppWitnessIc(cwebFormInfoMap.get(0).get("appWitnessIc"));
		polWebForm.setAppWitnessDate(GenericUtil.parseDate(cwebFormInfoMap.get(0).get("appWitnessDate"),"yyyy-MM-dd HH:mm:ss"));
		polWebForm.setAppName(cwebFormInfoMap.get(0).get("appName"));
		polWebForm.setAppIcNew(cwebFormInfoMap.get(0).get("appIcNew"));
		polWebForm.setAppIcOther(cwebFormInfoMap.get(0).get("appIcOther"));
		polWebForm.setAppNATIONALITY(cwebFormInfoMap.get(0).get("appNATIONALITY"));
		polWebForm.setAppDob(GenericUtil.parseDate(cwebFormInfoMap.get(0).get("appDob"),"yyyy-MM-dd HH:mm:ss"));
		polWebForm.setAppAge(new Integer(cwebFormInfoMap.get(0).get("appAge")).toString());
		polWebForm.setAppGender(cwebFormInfoMap.get(0).get("appGender"));
		polWebForm.setAppMarital(cwebFormInfoMap.get(0).get("appMarital"));
		polWebForm.setAppOCCNATURE(cwebFormInfoMap.get(0).get("APPOCCNATURE"));
		polWebForm.setAppOcc(cwebFormInfoMap.get(0).get("appOcc"));
		polWebForm.setAppOccclass(cwebFormInfoMap.get(0).get("appOccclass"));
		polWebForm.setAppAddLine1(cwebFormInfoMap.get(0).get("appAddLine1"));
		polWebForm.setAppAddLine2(cwebFormInfoMap.get(0).get("appAddLine2"));
		polWebForm.setAppAddLine3(cwebFormInfoMap.get(0).get("appAddLine3"));
		polWebForm.setAppAddPostcode(cwebFormInfoMap.get(0).get("appAddPostcode"));
		polWebForm.setAppAddState(cwebFormInfoMap.get(0).get("appAddState"));
		polWebForm.setAppCountry(cwebFormInfoMap.get(0).get("AppCountry"));	
		polWebForm.setAppTelHp(cwebFormInfoMap.get(0).get("appTelHp"));
	    polWebForm.setAppEmailAddress(cwebFormInfoMap.get(0).get("appEmailAddress"));
		polWebForm.setAppFOREIGNERCLF(cwebFormInfoMap.get(0).get("appFOREIGNERCLF"));
		polWebForm.setAppFOREIGNERFT(cwebFormInfoMap.get(0).get("APPFOREIGNERFT"));
		polWebForm.setAppNomineeRel(cwebFormInfoMap.get(0).get("appNomineeRel"));
		polWebForm.setAppOptin(cwebFormInfoMap.get(0).get("appOptin"));
		if("1".equalsIgnoreCase(cwebFormInfoMap.get(0).get("appFATCAUSPersonCircumstances"))){
			polWebForm.setAppFATCAUSPersonCircumstances("Y");
		}else{
			polWebForm.setAppFATCAUSPersonCircumstances("");
		}
		if("1".equalsIgnoreCase(cwebFormInfoMap.get(0).get("appFATCAUSPersonDataWaiver"))){
			polWebForm.setAppFATCAUSPersonDataWaiver("Y");
		}else{
			polWebForm.setAppFATCAUSPersonDataWaiver("");
		}
//		polWebForm.setAppFATCAUSPersonCircumstances(cwebFormInfoMap.get(0).get("appFATCAUSPersonCircumstances"));
//     	polWebForm.setAppFATCAUSPersonDataWaiver(cwebFormInfoMap.get(0).get("appFATCAUSPersonDataWaiver"));
		polWebForm.setAppSignDated(GenericUtil.parseDate(cwebFormInfoMap.get(0).get("appSignDated"),"yyyy-MM-dd HH:mm:ss"));
		polWebForm.setAppq1Aht(new Integer (cwebFormInfoMap.get(0).get("appq1Aht")).toString());
		polWebForm.setAppq1bWt(new Integer (cwebFormInfoMap.get(0).get("appq1bWt")).toString());
		polWebForm.setAppq1cWtChg(new Integer (cwebFormInfoMap.get(0).get("appq1cWtChg")).toString());
		polWebForm.setAppq2(cwebFormInfoMap.get(0).get("appq2"));
		polWebForm.setAppq3(cwebFormInfoMap.get(0).get("appq3"));
	    polWebForm.setAppDetails(cwebFormInfoMap.get(0).get("appDetails"));
//	    polWebForm.setAppDetails("This is inside the text area asdasdasdadadaa");
		polWebForm.setAppFinancierName(cwebFormInfoMap.get(0).get("appFinancierName"));
		polWebForm.setApplnAmtHse(new BigDecimal (cwebFormInfoMap.get(0).get("applnAmtHse").substring(0,cwebFormInfoMap.get(0).get("applnAmtHse").length()-2)));
		polWebForm.setAppRepayPeriodHse(new Integer (cwebFormInfoMap.get(0).get("appRepayPeriodHse")));
		polWebForm.setAppInterimPeriod(new Integer (cwebFormInfoMap.get(0).get("appInterimPeriod")));
		polWebForm.setAppPremiumFinanced(cwebFormInfoMap.get(0).get("appPremiumFinanced"));
		polWebForm.setAppIntRateHse(new BigDecimal (cwebFormInfoMap.get(0).get("appIntRateHse").substring(0,cwebFormInfoMap.get(0).get("appIntRateHse").length()-3)));
		polWebForm.setAppIntRateHse(new BigDecimal (cwebFormInfoMap.get(0).get("appIntRateHse")));
		polWebForm.setAppFinancierSignDated(GenericUtil.parseDate(cwebFormInfoMap.get(0).get("appFinancierSignDated"),"yyyy-MM-dd HH:mm:ss"));
		
		//-----------------------------added new field-------------------------------------------
		String productType=cwebFormInfoMap.get(0).get("typePri");
		if(productType.contains("MRTT3")){
		polWebForm.setAppCompanyName(cwebFormInfoMap.get(0).get("appCompanyName"));
		polWebForm.setAppCompanyRegNo(cwebFormInfoMap.get(0).get("appCompanyRegNo"));
		polWebForm.setAppAddOffLine1(cwebFormInfoMap.get(0).get("appAddOffLine1"));
		polWebForm.setAppAddOffLine2(cwebFormInfoMap.get(0).get("appAddOffLine2"));
		polWebForm.setAppAddOffLine3(cwebFormInfoMap.get(0).get("appAddOffLine3"));
		polWebForm.setAppAddOffPostCode(cwebFormInfoMap.get(0).get("appAddOffPostCode"));
		polWebForm.setAppAddOffCountry(cwebFormInfoMap.get(0).get("appAddOffCountry"));
		polWebForm.setAppAddOffState(cwebFormInfoMap.get(0).get("appAddOffState"));
		polWebForm.setAppTelOffNo(cwebFormInfoMap.get(0).get("appTelOffNo"));
		polWebForm.setAppTelMobileNo(cwebFormInfoMap.get(0).get("appTelMobileNo"));
		polWebForm.setAppUsTaxPayerID(cwebFormInfoMap.get(0).get("appUsTaxPayerID"));
		polWebForm.setAppParentAppID(cwebFormInfoMap.get(0).get("appParentAppID"));
		polWebForm.setAppLnAmtMdtaciHse(cwebFormInfoMap.get(0).get("appLnAmtMdtaciHse"));
		polWebForm.setAppUsTaxPayerID(cwebFormInfoMap.get(0).get("appUsTaxPayerID"));
		
	    
		if(cwebFormInfoMap.get(0).get("appLASumAssured")!=null){
	   
		polWebForm.setAppLASumAssured(new BigDecimal (cwebFormInfoMap.get(0).get("appLASumAssured").substring(0,cwebFormInfoMap.get(0).get("appLASumAssured").length()-2)));
		polWebForm.setAppLASinglePrem(new BigDecimal (cwebFormInfoMap.get(0).get("appLASinglePrem").substring(0,cwebFormInfoMap.get(0).get("appLASinglePrem").length()-2)));
		polWebForm.setAppCoverageTerm(new Integer(cwebFormInfoMap.get(0).get("appAge")).toString());
		
		
		double totalContributionCIMRTT=Double.parseDouble(cwebFormInfoMap.get(0).get("appLASinglePrem"))+
				                       Double.parseDouble(cwebFormInfoMap.get(0).get("laPremiumPayable"));
		
		polWebForm.setAppTotalContributionCIMRTT(new BigDecimal(totalContributionCIMRTT).setScale(2,BigDecimal.ROUND_CEILING));
		}
		
		polWebForm.setAppCRS(cwebFormInfoMap.get(0).get("appCRS"));
		 
		
		polWebForm.setAppCRSCountry1(cwebFormInfoMap.get(0).get("appCRSCountry1"));
		polWebForm.setAppCRSTin1(cwebFormInfoMap.get(0).get("appCRSTin1"));
		if(cwebFormInfoMap.get(0).get("appCRSReason1")!=null){
		polWebForm.setAppCRSReason1("Reason "+cwebFormInfoMap.get(0).get("appCRSReason1"));
		}
		
		polWebForm.setAppCRSCountry2(cwebFormInfoMap.get(0).get("appCRSCountry2"));
		polWebForm.setAppCRSTin2(cwebFormInfoMap.get(0).get("appCRSTin2"));
		if(cwebFormInfoMap.get(0).get("appCRSReason2")!=null){
			polWebForm.setAppCRSReason2("Reason "+cwebFormInfoMap.get(0).get("appCRSReason2"));
			}
		
		
		polWebForm.setAppCRSCountry3(cwebFormInfoMap.get(0).get("appCRSCountry3"));
		polWebForm.setAppCRSTin3(cwebFormInfoMap.get(0).get("appCRSTin3"));
		if(cwebFormInfoMap.get(0).get("appCRSReason3")!=null){
			polWebForm.setAppCRSReason3("Reason "+cwebFormInfoMap.get(0).get("appCRSReason3"));
			}
		
		polWebForm.setAppCRSCountry4(cwebFormInfoMap.get(0).get("appCRSCountry4"));
		polWebForm.setAppCRSTin4(cwebFormInfoMap.get(0).get("appCRSTin4"));
		if(cwebFormInfoMap.get(0).get("appCRSReason4")!=null){
			polWebForm.setAppCRSReason4("Reason "+cwebFormInfoMap.get(0).get("appCRSReason4"));
			}
		
		polWebForm.setAppCRSCountry5(cwebFormInfoMap.get(0).get("appCRSCountry5"));
		polWebForm.setAppCRSTin5(cwebFormInfoMap.get(0).get("appCRSTin5"));
		if(cwebFormInfoMap.get(0).get("appCRSReason5")!=null){
			polWebForm.setAppCRSReason4("Reason "+cwebFormInfoMap.get(0).get("appCRSReason5"));
			}
		
		if(cwebFormInfoMap.get(0).get("CRSReasonOptj2")!=null){
			
			if(cwebFormInfoMap.get(0).get("CRSReasonOptj2").equalsIgnoreCase("A")){
				polWebForm.setCRSReasonOptj2("Low income and not required to register tax file/ " +
						                     "Pendapatan rendah dan tidak perlu mendaftar cukai");
			}
			else if(cwebFormInfoMap.get(0).get("CRSReasonOptj2").equalsIgnoreCase("B")){
				polWebForm.setCRSReasonOptj2("Tin application in progress/Permohonan Tin sedang berjalan");
			}
			else if(cwebFormInfoMap.get(0).get("CRSReasonOptj2").equalsIgnoreCase("C")){
				polWebForm.setCRSReasonOptj2("Working in tax heaven country/ Bekerja di negara bebas cukai");
			}
			else{
				polWebForm.setCRSReasonOptj2("Other explanation /Penjelasan lain");
			}
		}
		
        polWebForm.setCRSReasonj2(cwebFormInfoMap.get(0).get("CRSReasonj2"));
        
        if(cwebFormInfoMap.get(0).get("nonCRSReasonoptj3")!=null && cwebFormInfoMap.get(0).get("nonCRSReasonoptj3").toString().trim()==null){
		polWebForm.setNonCRSReasonoptj3(cwebFormInfoMap.get(0).get("nonCRSReasonoptj3"));
		System.out.println(cwebFormInfoMap.get(0).get("nonCRSReasonoptj3"));
        }
		
		polWebForm.setNonCRSReasonj3Other(cwebFormInfoMap.get(0).get("nonCRSReasonj3Other"));
		System.out.println(cwebFormInfoMap.get(0).get("nonCRSReasonj3Other"));
		
		polWebForm.setAppj4Option("Y");
		}
		
		
		//---------------------------------------------------------------------------------------
		
		
	
		System.out.println(cwebFormInfoMap.get(0).get("policyNo"));
		
		
		// For Nominee
		if(!cwebFormInfoMapNominee.isEmpty()){
			polWebForm.setAppWasi(cwebFormInfoMapNominee.get(0).get("appWasi"));
			polWebForm.setAppConditionalHibah(cwebFormInfoMapNominee.get(0).get("appConditionalHibah"));
			polWebForm.setAppNameNominee(cwebFormInfoMapNominee.get(0).get("appNameNominee"));
			polWebForm.setAppIcNewNominee(cwebFormInfoMapNominee.get(0).get("appIcNewNominee"));
			polWebForm.setAppNomineeRel(cwebFormInfoMapNominee.get(0).get("appNomineeRel"));
			polWebForm.setAppIcOtherNominee(cwebFormInfoMapNominee.get(0).get("appIcOtherNominee"));
			polWebForm.setAppDobNominee(GenericUtil.parseDate(cwebFormInfoMapNominee.get(0).get("appDobNominee"),"yyyy-MM-dd HH:mm:ss"));
			polWebForm.setAppAgeNominee(new Integer(cwebFormInfoMapNominee.get(0).get("appAgeNominee")).toString());
			polWebForm.setAppAddLine1Nominee(cwebFormInfoMapNominee.get(0).get("appAddLine1Nominee"));
			polWebForm.setAppAddLine2Nominee(cwebFormInfoMapNominee.get(0).get("appAddLine2Nominee"));
			polWebForm.setAppAddLine3Nominee(cwebFormInfoMapNominee.get(0).get("appAddLine3Nominee"));
			polWebForm.setAppAddPostcodeNominee(cwebFormInfoMapNominee.get(0).get("appAddPostcodeNominee"));
			polWebForm.setAppAddStateNominee(cwebFormInfoMapNominee.get(0).get("appAddStateNominee"));
			
			System.out.println(polWebForm.getAppWasi());
			System.out.println(polWebForm.getAppConditionalHibah());
			System.out.println(polWebForm.getAppNameNominee());
			System.out.println(polWebForm.getAppIcNewNominee());
			System.out.println(polWebForm.getAppNomineeRel());
			System.out.println(polWebForm.getAppDobNominee());
			System.out.println(polWebForm.getAppAgeNominee());
			System.out.println(polWebForm.getAppAddLine1Nominee());
			System.out.println(polWebForm.getAppCRSCountry1());
			System.out.println(polWebForm.getAppCRSTin1());
			System.out.println(polWebForm.getAppCRSReason1());
			System.out.println(polWebForm.getAppLASumAssured() +" This is Sum assured");
			
		
			
			
		}else{
			System.out.println("[ProcessBatch][processPolicyInfoForWeb]Nominee Details are empty");
		}
		
	}	
	
	
	private List<PolCoverage> processCoverageInfo(HashMap<Integer, HashMap<String, String>> covInfoMap, String companyCode,HashMap<Integer, HashMap<String, String>> policyInfoMap) {
		List<PolCoverage> coverages = new ArrayList<PolCoverage>();
		
		if(covInfoMap.size() > 0) {
			for(int i = 0; i < covInfoMap.size(); i++) {
				HashMap<String, String> row = covInfoMap.get(i);
				
				PolCoverage cov = new PolCoverage();
				System.out.println("ProcessBatch (Plan Code):"+ row.get("PlanCode"));
				cov.setCoverageName(DataLoader.getPlanList().get(companyCode + row.get("PlanCode")));
				cov.setFormNo(row.get("FormNo"));
				cov.setExpiryDate(GenericUtil.parseDate(row.get("ExpiryDate"), "yyyy-MM-dd HH:mm:ss"));
				cov.setBenefitAmount(new BigDecimal(row.get("BenefitAmount")));
				cov.setPremiumAmount(new BigDecimal(row.get("PremiumAmount")));
				cov.setCeasedDate(GenericUtil.parseDate(row.get("ExpiryDate"), "yyyy-MM-dd HH:mm:ss"));
				
				Integer remYears = 0;
				if(policyInfoMap.get(0).get("InsuredAge") != null && policyInfoMap.get(0).get("InsuredAge").length()>0){
					 remYears =80 -  Integer.parseInt(policyInfoMap.get(0).get("InsuredAge"));
				}	
				
				Integer remYearsCIBasic = 0;
				if(policyInfoMap.get(0).get("InsuredAge") != null && policyInfoMap.get(0).get("InsuredAge").length()>0){
					remYearsCIBasic =70 -  Integer.parseInt(policyInfoMap.get(0).get("InsuredAge"));
				}
				
				System.out.println(" ProcessCoverageInfo - remYears :"+ remYears);
				System.out.println(" ProcessCoverageInfo - remYearsCIBasic :"+ remYearsCIBasic);
				
/*				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Calendar c = Calendar.getInstance();
				c.setTime(GenericUtil.parseDate(DOB, "yyyyMMdd")); // Now use today date.
				c.add(Calendar.YEAR, 80); // Adding 80 years
				String output = sdf.format(c.getTime());*/
				
				Calendar c = Calendar.getInstance();
				c.setTime(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss")); // Now use today date.
				c.add(Calendar.YEAR, remYears); // Adding remaining years(Insured Age - 80) to Policy date 
				cov.setMaturityDateCICare(c.getTime());
				
				Calendar c1 = Calendar.getInstance();
				c1.setTime(GenericUtil.parseDate(policyInfoMap.get(0).get("PolicyDate"), "yyyy-MM-dd HH:mm:ss")); // Now use today date.
				c1.add(Calendar.YEAR, remYearsCIBasic); // Adding remaining years(Insured Age - 80) to Policy date 
				cov.setMaturityDateCIandMedBasic(c1.getTime());
				
				//cov.setMeturityDateCICare(GenericUtil.parseDate(DOB, "yyyy-MM-dd HH:mm:ss"));
				System.out.println(" ProcessCoverageInfo - DOB - MeturityDateCICare:"+cov.getMaturityDateCICare());
				System.out.println(" ProcessCoverageInfo - DOB - MaturityDateCIandMedBasic:"+cov.getMaturityDateCIandMedBasic());
				// set non-basic coverages as N/A
				if(i > 0) {
					cov.setPremiumAmount(null);
					cov.setCeasedDate(null);
				}
				
				coverages.add(cov);
			}
		}	
			
		return coverages;
	}
	
	private AppForm processAppForm(HashMap<Integer, HashMap<String, String>> policyInfoMap, 
			HashMap<Integer, HashMap<String, String>> questionMap, String languageCode) {
		CommonFileUtil cu = new CommonFileUtil();
		AppForm appForm = new AppForm();
		
		appForm.setPolicyId(policyInfo.getPolicyId());
		appForm.setPolicyNo(policyInfo.getPolicyNo());
		
		appForm.setInsuredName(WordUtils.capitalizeFully(policyInfo.getInsuredName()));
		appForm.setMykadNo(policyInfo.getInsuredMykad());
		appForm.setModeOfPayment(policyInfoMap.get(0).get("ModeOfPayment"));
		if("01".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "1".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			appForm.setPaymentType("MONTHLY");
			appForm.setPaymentTypeWord("ONE");
		}
		if("03".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "3".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			appForm.setPaymentType("QUARTERLY");
			appForm.setPaymentTypeWord("THREE");
		}
		if("06".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "6".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			appForm.setPaymentType("SEMI ANNUAL");
			appForm.setPaymentTypeWord("SIX");
		}
		if("01".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment")) || "1".equalsIgnoreCase(policyInfoMap.get(0).get("ModeOfPayment"))){
			appForm.setPaymentType("ANNUAL");
			appForm.setPaymentTypeWord("TWELVE");
		}
		appForm.setDateOfBirth(GenericUtil.parseDate(policyInfoMap.get(0).get("DateOfBirth"), "yyyyMMdd"));
		appForm.setGender(WordUtils.capitalizeFully(policyInfo.getGender()));
		appForm.setNationality(DataLoader.getNationalityList().get(policyInfoMap.get(0).get("Nationality")));
		
		if(policyInfoMap.get(0).get("NatureOfBiz") != null && policyInfoMap.get(0).get("NatureOfBiz").trim().length()>0){
			appForm.setOccupation(policyInfoMap.get(0).get("NatureOfBiz"));
		}else{
			appForm.setOccupation(WordUtils.capitalizeFully(
					DataLoader.getOccupationList().get(policyInfoMap.get(0).get("Occupation"))));
		}
		appForm.setEmployerName(policyInfoMap.get(0).get("EmployerName"));
		appForm.setEmail((policyInfoMap.get(0).get("Email")));
		appForm.setAddress(processAddress(policyInfoMap.get(0).get("ADDRESS1"), policyInfoMap.get(0).get("ADDRESS2"), 
				policyInfoMap.get(0).get("ADDRESS3"), policyInfoMap.get(0).get("CITYSTATE"), 
				policyInfoMap.get(0).get("POSTCODE"), policyInfoMap.get(0).get("COUNTRY")));
		
		/*appForm.setAddress1(policyInfoMap.get(0).get("ADDRESS1"));
		appForm.setAddress2(policyInfoMap.get(0).get("ADDRESS2"));
		appForm.setAddress3(policyInfoMap.get(0).get("ADDRESS3"));
		appForm.setCityState(policyInfoMap.get(0).get("CITYSTATE"));
		appForm.setCountry(policyInfoMap.get(0).get("COUNTRY"));
		*/
		appForm.setPostcode(policyInfoMap.get(0).get("POSTCODE"));
		appForm.setTelNo(policyInfoMap.get(0).get("TelNo"));
		appForm.setHeight(!cu.isBlank(policyInfoMap.get(0).get("Height"))? Float.parseFloat(policyInfoMap.get(0).get("Height")): 0);
		appForm.setWeight(!cu.isBlank(policyInfoMap.get(0).get("Weight"))? Float.parseFloat(policyInfoMap.get(0).get("Weight")): 0);
		appForm.setPlanName(policyInfo.getCoverages().get(0).getCoverageName());
		appForm.setSumAssured(new BigDecimal(policyInfoMap.get(0).get("SumAssured")));
		
		appForm.setqIsSmoke(policyInfoMap.get(0).get("QIsSmoke"));
		//appForm.setqCigaretteNo(rs.getInt("qCigaretteNo"));
		
		for(int i = 0; i < questionMap.size(); i++) {
			HashMap<String, String> row = questionMap.get(i);
			
			if("1".equals(row.get("OrderingNumber"))) appForm.setqIsCriticalIllness(row.get("UWAnswer"));
			if("2".equals(row.get("OrderingNumber"))) appForm.setqIsSymptoms(row.get("UWAnswer"));
			if("3".equals(row.get("OrderingNumber"))) appForm.setqIsDefects(row.get("UWAnswer"));
			if("4".equals(row.get("OrderingNumber"))) appForm.setqIsInsAccept(row.get("UWAnswer"));
			if("5".equals(row.get("OrderingNumber"))) appForm.setqIsFemaleQ(row.get("UWAnswer"));
		}
		
		String isReceiveInfo = policyInfoMap.get(0).get("IsReceiveInfo");
		appForm.setIsReceiveInfo(!cu.isBlank(isReceiveInfo)? isReceiveInfo: "N");
		
		appForm.setPolLanguage(languageCode);
		
		return appForm;
	}
	
	private List<RelatedEntity> processNominees(HashMap<Integer, HashMap<String, String>> nomineeMap) {
		List<RelatedEntity> nominees = new ArrayList<RelatedEntity>();
		
		for(int i = 0; i < nomineeMap.size(); i++) {
			HashMap<String, String> row = nomineeMap.get(i);
			
			RelatedEntity entity = new RelatedEntity();
			
			entity.setName(row.get("Name"));
			
			entity.setAddress(processAddress(row.get("ADDRESS1"), row.get("ADDRESS2"), row.get("ADDRESS3"), 
					row.get("CITYSTATE"), row.get("POSTCODE"), row.get("COUNTRY")));
			
			entity.setSharePercent(new BigDecimal(row.get("SharePercent")));
			entity.setIdNo(row.get("Mykad"));
			entity.setDateOfBirth(GenericUtil.parseDate(row.get("DateOfBirth"), "yyyyMMdd"));
			entity.setRelationship(DataLoader.getRelationshipList().get(row.get("Relationship")));
			
			nominees.add(entity);
		}
		
		return nominees;
	}
	
	private List<RelatedEntity> processTrustees(HashMap<Integer, HashMap<String, String>> trusteeMap) {
		List<RelatedEntity> trustees = new ArrayList<RelatedEntity>();
		CommonFileUtil cu = new CommonFileUtil();
		
		for(int i = 0; i < trusteeMap.size(); i++) {
			HashMap<String, String> row = trusteeMap.get(i);
			
			RelatedEntity entity = new RelatedEntity();
			
			entity.setName(row.get("Name"));
			
			entity.setAddress(processAddress(row.get("ADDRESS1"), row.get("ADDRESS2"), row.get("ADDRESS3"), 
					row.get("CITYSTATE"), row.get("POSTCODE"), row.get("COUNTRY")));
			
			//entity.setSharePercent(new BigDecimal(row.get("SharePercent")));
			entity.setIdNo(row.get("Mykad"));
			
			if(!cu.isBlank(row.get("DateOfBirth")))
				entity.setDateOfBirth(GenericUtil.parseDate(row.get("DateOfBirth"), "yyyyMMdd"));
			//entity.setRelationship(rs.getString("Relationship"));
			
			trustees.add(entity);
		}
		
		return trustees;
	}
	
	private String processAddress(String address1, String address2, String address3, String city, 
			String postcode, String countryCode) {
		String fullAddress = "";
		CommonFileUtil cu = new CommonFileUtil();
		
		String country = DataLoader.getCountryList().get(countryCode);
		
		if(!cu.isBlank(address1)) fullAddress = address1;
		if(!cu.isBlank(address2)) fullAddress += ", " + address2;
		if(!cu.isBlank(address3)) fullAddress += ", " + address3;
		if(!cu.isBlank(postcode)) fullAddress += ", " + postcode;
		if(!cu.isBlank(city)) fullAddress += ", " + city;
		if(!cu.isBlank(country)) fullAddress += ", " + country;
		
		return fullAddress;
	}

	private String getGenderDesc(String genderCode, String langCode) {
		CommonFileUtil cu = new CommonFileUtil();
		String gender = "";
		
		if(!cu.isBlank(genderCode)) {
			if("M".equalsIgnoreCase(genderCode)) return ("EN".equals(langCode))? "Male": "Lelaki";
			else if("F".equalsIgnoreCase(genderCode)) return ("EN".equals(langCode))? "Female": "Perempuan";
		}
		
		return gender;
	}
	
	private String getCurrencyDesc(String currencyCode) {
		CommonFileUtil cu = new CommonFileUtil();
		String currency = "";
		
		if(!cu.isBlank(currencyCode)) {
			if("RM".equalsIgnoreCase(currencyCode)) return "Malaysian Ringgit";
			else if("USD".equalsIgnoreCase(currencyCode)) return "US Dollar";
		}
		
		return currency;
	}

	public PolicyInfo getPolicyInfo() {
		return policyInfo;
	}
}
