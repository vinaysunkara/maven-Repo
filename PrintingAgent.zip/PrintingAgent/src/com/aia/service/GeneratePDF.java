package com.aia.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.imageio.ImageIO;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.dom4j.DocumentHelper;
import org.dom4j.Node;

import com.aia.common.db.DBCommon;
import com.aia.common.model.AgentContract;
import com.aia.common.model.AppForm;
import com.aia.common.model.PolWebForm;
import com.aia.common.model.PolicyInfo;
import com.aia.pdfGenerator.model.Reports;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericGenerator;
import com.aia.pdfGenerator.util.GenericUtil;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PRStream;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfDictionary;
import com.lowagie.text.pdf.PdfImage;
import com.lowagie.text.pdf.PdfIndirectObject;
import com.lowagie.text.pdf.PdfName;
import com.lowagie.text.pdf.PdfObject;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.PdfWriter;

public class GeneratePDF {
//	private static final Logger logger = Logger.getLogger(GenDuplicateCopy.class);
//	private static Document doc = null;	
//	private final String pdfPath = "pdf/";
	
	public String genBatchPDFOld(String processID, List<String> processFileList, String processYear, String inputType, String sourceSystem) {
		GenericUtil gu = new GenericUtil();
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		
		boolean isOriginal = false;
		boolean isDone = false;
		String sourceType = "";
		
		try {
			for (int i=0; i<processFileList.size(); i++) {
				int currTaxInvPerFile = 0;
				ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
				List<ByteArrayOutputStream> masterBaos = new ArrayList<ByteArrayOutputStream>();
				List<List<String>> taxInvListPerBaos = new ArrayList<List<String>>();  
				
				// check for duplicate Tax Invoice No in current process id
				String duplicateStr = dc.getTaxInvNoExists(processID, processYear, i+1);
				
				if(duplicateStr != null) {
					// log to error folder for the duplicate Tax Invoice No
					String errorPath = cu.addErrorLogToCSVFolder(duplicateStr, processID, processYear, i+1, processFileList.get(i), inputType);
					dc.updateTaxInvDataIfExists(processID, processYear, i+1);
					cu.sendEmailForDuplication(errorPath);
					
				} else {
					while (!isDone) {
						List<String> taxInvNoList = dc.getTaxInvList(processID, i+1, processYear, cu.getMaxTaxInvPerFile());
						List<String> taxInvPrintedList = new ArrayList<String>();
						
						if (taxInvNoList == null || taxInvNoList.size() == 0) {
							break;
						}
						
						for(String taxInvNo : taxInvNoList) {
							ByteArrayOutputStream tempPDFBaos = new ByteArrayOutputStream();
							HashMap<Integer, HashMap<String, String>> taxInvRS = dc.getTaxInvDetails(taxInvNo, processYear);
							HashMap<String, String> taxInvMaster = taxInvRS.get(0);
							
							String docFormat = dc.getDocFormat(taxInvMaster);
							sourceType = taxInvMaster.get("SourceType");
							
							// check for 8 characters policy number and convert to 10 characters
							taxInvRS = dc.checkAndConvertTo10CharPolNo(sourceType, taxInvRS);
							
							isOriginal = validateIsOriginalCopy(inputType, docFormat, taxInvMaster);
							
							if (docFormat != null && docFormat.trim().length() > 0) {
								boolean isGen = true;
								if ("B".equals(inputType)) {
									if (!cu.getHardCopy().equals(docFormat)) {
										isGen = false;
									}
								}
								
								if (isGen) {
									HashMap<Integer, HashMap<String, String>>  gstSummary =  dc.getGSTSummary(taxInvNo, processYear);
									
									taxInvPrintedList.add(taxInvNo);
									if (cu.getCreditNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
										tempPDFBaos = genCreditNote(taxInvRS, gstSummary);
									} else if (cu.getDebitNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
										tempPDFBaos = genDebitNote(taxInvRS, gstSummary);
									} else if (cu.getSelfBill().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
										tempPDFBaos = genSelfBill(taxInvRS);
									} else if (cu.getTaxInvoice().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
										tempPDFBaos = genTaxInvoice(taxInvRS, gstSummary);
									} else if (cu.getSelfBill_claim().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
										tempPDFBaos = genSelfBillClaim(taxInvRS);
									}
									
									if (!isOriginal) {
										tempPDFBaos = gu.addWaterMark(tempPDFBaos);
									}
									
									currTaxInvPerFile ++;
								}
							} else {
								System.out.println("-------------------------------- [" + taxInvMaster.get("TaxInvoiceNo") + "] docFormat Not Found! --------------------------------");
							}
							
							if (tempPDFBaos != null && tempPDFBaos.toByteArray().length > 0) {
								pdfBaos = gu.mergePDF(pdfBaos, tempPDFBaos);
							}
							
							if (currTaxInvPerFile == cu.getMaxTaxInvPerFile()) {
								if (!isOriginal) {
									pdfBaos = gu.addWaterMark(pdfBaos);
								}
								
								if ("B".equalsIgnoreCase(inputType)) {
									pdfBaos = gu.addOMRnIntNo(pdfBaos);
								}
								
								masterBaos.add(pdfBaos);
								pdfBaos = new ByteArrayOutputStream();
								currTaxInvPerFile = 0;
								
								taxInvListPerBaos.add(taxInvPrintedList);
								taxInvPrintedList = new ArrayList<String>();
							}
							
							dc.updateWorkableProcess(processYear, "Y", taxInvMaster.get("TaxInvoiceNo"));						
						}
	
	//					if (currTaxInvPerFile > 0 && currTaxInvPerFile < cu.getMaxTaxInvPerFile()) {
						if (currTaxInvPerFile > 0) {
							if ("B".equalsIgnoreCase(inputType)) {
								pdfBaos = gu.addOMRnIntNo(pdfBaos);
							}
							
							masterBaos.add(pdfBaos);
							pdfBaos = new ByteArrayOutputStream();
							currTaxInvPerFile = 0;
							
							taxInvListPerBaos.add(taxInvPrintedList);
							taxInvPrintedList = new ArrayList<String>();
						}
					}
					
					for (int baosNo = 0; baosNo < masterBaos.size(); baosNo++) {
						//-------------------------------------------- Generate Summary Page Start --------------------------------------------
						if ("B".equalsIgnoreCase(inputType)) {
							ByteArrayOutputStream pdfWithSumm = genSummaryPage(processID, masterBaos.get(baosNo), baosNo, taxInvListPerBaos, sourceType);
							
							pdfWithSumm = gu.mergePDF(pdfWithSumm, masterBaos.get(baosNo));
							
							masterBaos.set(baosNo, pdfWithSumm);
						}
						//-------------------------------------------- Generate Summary Page End --------------------------------------------
						
						if ("B".equalsIgnoreCase(inputType)) {
							dc.addToImgDB(processID, i+1, baosNo, masterBaos.get(baosNo), "Y", "N", sourceType, inputType, processFileList.get(i));
							
						} else if ("R".equalsIgnoreCase(inputType) || "A".equalsIgnoreCase(inputType)) {
							dc.addToImgDB(processID, i+1, baosNo, masterBaos.get(baosNo), "N", inputType, sourceType, inputType);
						}
						
						dc.addPrintSummDet(processID, i+1, baosNo, processID + "_" + baosNo, sourceSystem);					
					}
					
					dc.updatePrintSummaryCalled(processID, i+1);
				}
			}			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return null;
	}
	
	public String genBatchPDF(String processID, List<String> processFileList, String processYear, String inputType, String sourceSystem) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		
		CountDownLatch waitCount = null;
		ExecutorService executor = Executors.newFixedThreadPool(4);
		
		try {
			for(int i=0; i<processFileList.size(); i++) {
				// check for duplicate Tax Invoice No in current process id
				String duplicateStr = dc.getTaxInvNoExists(processID, processYear, i+1);
				
				if(duplicateStr != null) {
					// log to error folder for the duplicate Tax Invoice No
					String errorPath = cu.addErrorLogToCSVFolder(duplicateStr, processID, processYear, i+1, processFileList.get(i), inputType);
					dc.updateTaxInvDataIfExists(processID, processYear, i+1);
					cu.sendEmailForDuplication(errorPath);
					
				} else {
					int fileSeqNo = 0;
					
					List<String> taxInvNoList = dc.getTaxInvListWithDocFormat(processID, i+1, processYear, cu.getHardCopy(), 
													isT2Filename(processFileList.get(i)));
					
					// ignore DocFormat if Ad-Hoc request
					if("A".equalsIgnoreCase(inputType))
						taxInvNoList = dc.getTaxInvList(processID, i+1, processYear, cu.getMaxTaxInvPerFile());
										
					Map<Integer, List<String>> taxInvListMaps = getTaxInvListMaps(taxInvNoList);
					waitCount = new CountDownLatch(taxInvListMaps.size());
					
					for(List<String> newTaxInvNoList: taxInvListMaps.values()) {
						String taxInvNoStr = "";
						
						List<String> taxInvNoProcessList = new ArrayList<String>();
						
						//ThreadPool executor = new ThreadPool();
						
						for(String taxInvNo : newTaxInvNoList) {
							if (taxInvNoStr.length() > 0) {
								taxInvNoStr += ", ";
							}
							
							taxInvNoStr += "'" + taxInvNo + "'";
							taxInvNoProcessList.add(taxInvNo);
						}
						
						HashMap<Integer, HashMap<String, String>> taxInvRSAll = dc.getTaxInvDetails(taxInvNoStr, processYear);
						
						GenThread pdfThread = new GenThread(taxInvNoProcessList, taxInvRSAll, processYear, processID, 
								i+1, fileSeqNo++, processFileList.get(i), sourceSystem, waitCount, inputType);
						
						//executor.runTask(runner);
						executor.execute(pdfThread);
						
						taxInvNoProcessList	= new ArrayList<String>();
					}
					
					// synchronize before getting another list of tax invoice
					waitCount.await();
						
					dc.updatePrintSummaryCalled(processID, i+1);
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			executor.shutdownNow();
			
		} finally {
			executor.shutdown();
		}
		
		return null;
	}
	
	private boolean isT2Filename(String filename) {
		boolean isT2 = false;
		
		if(filename != null && filename.trim().length() > 0) {
			CommonFileUtil cfu = new CommonFileUtil();
			
			if(filename.toUpperCase().contains(cfu.getT2File()) || 
					filename.toUpperCase().contains(cfu.getT2FileYearly())) {
				isT2 = true;
			}
		}
		
		return isT2;
	}

	public void newReGen(String uniqueID, String seqNo) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		
		CountDownLatch waitCount = null;
		ExecutorService executor = Executors.newFixedThreadPool(4);
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss:SSS");
		
		try {
			HashMap<String, String> printSummaryList = dc.getPrintSummary(uniqueID, seqNo);
			String processYear = printSummaryList.get("ProcessYear");
			int summSeqNo = Integer.valueOf(printSummaryList.get("SeqNo"));
			
			dc.updateProcessCase(uniqueID, summSeqNo, processYear);
			
			System.out.println("--------------------------------[" + sdf.format(new java.util.Date()) + "][" + new java.util.Date().getTime() + "] [GeneratePDF.java] reGen() generate PDF File Start --------------------------------");
			
			int fileSeqNo = 0;
			
			List<String> taxInvNoList = dc.getTaxInvListWithDocFormat(uniqueID, summSeqNo, processYear, cu.getHardCopy(), false);
			
			Map<Integer, List<String>> taxInvListMaps = getTaxInvListMaps(taxInvNoList);
			waitCount = new CountDownLatch(taxInvListMaps.size());
			
			for(List<String> newTaxInvNoList: taxInvListMaps.values()) {
				String taxInvNoStr = "";
				
				List<String> taxInvNoProcessList = new ArrayList<String>();
				
				for(String taxInvNo : newTaxInvNoList) {
					if (taxInvNoStr.length() > 0) {
						taxInvNoStr += ", ";
					}
					
					taxInvNoStr += "'" + taxInvNo + "'";
					taxInvNoProcessList.add(taxInvNo);
				}
				
				HashMap<Integer, HashMap<String, String>> taxInvRSAll = dc.getTaxInvDetails(taxInvNoStr, processYear);
				
				GenThread pdfThread = new GenThread(taxInvNoProcessList, taxInvRSAll, processYear, uniqueID, 
						summSeqNo, fileSeqNo++, uniqueID, "RE-GEN", waitCount, "R");
				
				//executor.runTask(runner);
				executor.execute(pdfThread);
				
				taxInvNoProcessList	= new ArrayList<String>();
			}
			
			// synchronize before getting another list of tax invoice
			waitCount.await();
				
			dc.updatePrintSummaryCalled(uniqueID, summSeqNo);
			
		} catch(Exception ex) {
			ex.printStackTrace();
			executor.shutdownNow();
			
		} finally {
			executor.shutdown();
		}
	}
	
	public Map<Integer, List<String>> getTaxInvListMaps(List<String> taxInvNoList) {
		Map<Integer, List<String>> taxInvListMaps = new HashMap<Integer, List<String>>();
		CommonFileUtil cu = new CommonFileUtil();
		
		if(taxInvNoList.size() > 0) {
			int mapNo = 0;
			int currProcess = 0;
			List<String> newTaxInvNoList = new ArrayList<String>();
			
			for(int i = 0; i < taxInvNoList.size(); i++) {
				newTaxInvNoList.add(taxInvNoList.get(i));
				currProcess++;
				
				if(currProcess == cu.getMaxTaxInvPerFile()) {
					taxInvListMaps.put(mapNo++, newTaxInvNoList);
					newTaxInvNoList = new ArrayList<String>();
					currProcess = 0;
				}
			}
			
			if(newTaxInvNoList.size() > 0) 
				taxInvListMaps.put(mapNo++, newTaxInvNoList);
		}
		
		return taxInvListMaps;
	}
	
	public String genAdhocPDF(String currProcessID, String processID, HashMap<Integer, HashMap<String, String>> taxInvDetails, String inputType, String processYear, String sourceSystem) {
		GenericUtil gu = new GenericUtil();
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		
		boolean isOriginal = false;
		String sourceType = "";
				
		ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
				
		try {
			HashMap<String, String> taxInvMaster = taxInvDetails.get(0);
			
			sourceType = taxInvMaster.get("SourceType");
			
			String docFormat = dc.getDocFormat(taxInvMaster);
			
			// check for 8 characters policy number and convert to 10 characters
			taxInvDetails = dc.checkAndConvertTo10CharPolNo(sourceType, taxInvDetails);
			
			if(taxInvMaster.get("IsProcess") != null && !taxInvMaster.get("IsProcess").equalsIgnoreCase("Y") && "GAMS".equalsIgnoreCase(sourceSystem)) {
				isOriginal = validateIsOriginalCopy(inputType, docFormat, taxInvMaster);
			}
			
			if("GAMS".equalsIgnoreCase(sourceSystem) || "GSTS".equalsIgnoreCase(sourceSystem) || "SSTS".equalsIgnoreCase(sourceSystem)) 
				isOriginal = true;
			
			if (docFormat != null && docFormat.trim().length() > 0) {
				boolean isGen = true;
				if ("B".equals(inputType)) {
					if (!cu.getHardCopy().equals(docFormat)) {
						isGen = false;
					}
				}
				
				if (isGen) {
					HashMap<Integer, HashMap<String, String>>  gstSummary = dc.getGSTSummary(taxInvMaster.get("TaxInvoiceNo"), processYear);
					
					if (cu.getCreditNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
						pdfBaos = genCreditNote(taxInvDetails, gstSummary);
					} else if (cu.getDebitNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
						pdfBaos = genDebitNote(taxInvDetails, gstSummary);
					} else if (cu.getSelfBill().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
						pdfBaos = genSelfBill(taxInvDetails);
					} else if (cu.getTaxInvoice().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
						pdfBaos = genTaxInvoice(taxInvDetails, gstSummary);
					} else if (cu.getSelfBill_claim().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
						pdfBaos = genSelfBillClaim(taxInvDetails);
					}
					
					if (!isOriginal) {
						pdfBaos = gu.addWaterMark(pdfBaos);
					}
				}
				
				int summarySeqNo = dc.getPrintSummSeqNo (currProcessID);
				
				dc.addToImgDB(processID, summarySeqNo, 0, pdfBaos, "N", "Y", sourceType, inputType);
				
				dc.addPrintSummDet(processID, summarySeqNo, 0, processID + "_" + 0, sourceSystem);
								
				dc.updatePrintSummaryCalled(processID, summarySeqNo);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return null;
	}
	
	/*public void reGen(String uniqueID, String seqNo) {
		
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GenericUtil gu = new GenericUtil();
				
		boolean isOriginal = false;
		boolean isDone = false;
		String sourceType = "";
		
		List<ByteArrayOutputStream> masterBaos = new ArrayList<ByteArrayOutputStream>();
		List<List<String>> taxInvListPerBaos = new ArrayList<List<String>>();  
		
		int currTaxInvPerFile = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss:SSS");
		
		try{
			HashMap<String, String> printSummaryList = dc.getPrintSummary(uniqueID, seqNo);
			String processYear = printSummaryList.get("ProcessYear");
			int summSeqNo = Integer.valueOf(printSummaryList.get("SeqNo"));
			
			ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
			
			dc.updateProcessCase(uniqueID, summSeqNo, processYear);
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] [GeneratePDF.java] reGen() generate PDF File Start --------------------------------");
			
			while (!isDone) {
				List<String> taxInvNoList = dc.getTaxInvList(uniqueID, summSeqNo, processYear, cu.getMaxTaxInvPerFile());
				List<String> taxInvPrintedList = new ArrayList<String>();
				
				if (taxInvNoList == null || taxInvNoList.size() == 0) {
					break;
				}
				
				for(String taxInvNo : taxInvNoList) {
					ByteArrayOutputStream tempPDFBaos = new ByteArrayOutputStream();
					HashMap<Integer, HashMap<String, String>> taxInvRS = dc.getTaxInvDetails(taxInvNo, processYear);
					
					HashMap<String, String> taxInvMaster = taxInvRS.get(0);
					
					String docFormat = dc.getDocFormat(taxInvMaster);
					sourceType = taxInvMaster.get("SourceType");
					
					// check for 8 characters policy number and convert to 10 characters
					taxInvRS = dc.checkAndConvertTo10CharPolNo(sourceType, taxInvRS);
					
					isOriginal = validateIsOriginalCopy("B", docFormat, taxInvMaster);
					
					if (docFormat != null && docFormat.trim().length() > 0) {
						boolean isGen = true;
						
						if (!cu.getHardCopy().equals(docFormat)) {
							isGen = false;
						}
						
						if (isGen) {
							HashMap<Integer, HashMap<String, String>>  gstSummary = dc.getGSTSummary(taxInvNo, processYear);
							
							taxInvPrintedList.add(taxInvNo);
							
							System.out.println("--------------------------------[" + sdf.format(new java.util.Date()) + "][" + new java.util.Date() + "] [GeneratePDF.java] reGen() taxInvNo = [" + currTaxInvPerFile + "] " + taxInvNo + " --------------------------------");
							
							if (cu.getCreditNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
								tempPDFBaos = genCreditNote(taxInvRS, gstSummary);
							} else if (cu.getDebitNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
								tempPDFBaos = genDebitNote(taxInvRS, gstSummary);
							} else if (cu.getSelfBill().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
								tempPDFBaos = genSelfBill(taxInvRS);
							} else if (cu.getTaxInvoice().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
								tempPDFBaos = genTaxInvoice(taxInvRS, gstSummary);
							} else if (cu.getSelfBill_claim().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
								tempPDFBaos = genSelfBillClaim(taxInvRS);
							}
							
							if (!isOriginal) {
								tempPDFBaos = gu.addWaterMark(tempPDFBaos);
							}
							
							currTaxInvPerFile ++;
						}
					}
					
					if (tempPDFBaos != null && tempPDFBaos.toByteArray().length > 0) {
						pdfBaos = gu.mergePDF(pdfBaos, tempPDFBaos);
					}
					
					if (currTaxInvPerFile == cu.getMaxTaxInvPerFile()) {
						if (!isOriginal) {
							pdfBaos = gu.addWaterMark(pdfBaos);
						}
						
						pdfBaos = gu.addOMRnIntNo(pdfBaos);
						
						masterBaos.add(pdfBaos);
						pdfBaos = new ByteArrayOutputStream();
						currTaxInvPerFile = 0;
						
						taxInvListPerBaos.add(taxInvPrintedList);
						taxInvPrintedList = new ArrayList<String>();
					}
					
					dc.updateWorkableProcess(processYear, "Y", taxInvMaster.get("TaxInvoiceNo"));
				}
				
				if (currTaxInvPerFile > 0) {
					pdfBaos = gu.addOMRnIntNo(pdfBaos);
					
					masterBaos.add(pdfBaos);
					pdfBaos = new ByteArrayOutputStream();
					currTaxInvPerFile = 0;
					
					taxInvListPerBaos.add(taxInvPrintedList);
					taxInvPrintedList = new ArrayList<String>();
				}
			}
			
			for (int baosNo = 0; baosNo < masterBaos.size(); baosNo++) {
				//-------------------------------------------- Generate Summary Page Start --------------------------------------------
				ByteArrayOutputStream pdfWithSumm = genSummaryPage(uniqueID, masterBaos.get(baosNo), baosNo, taxInvListPerBaos, sourceType);
				
				pdfWithSumm = gu.mergePDF(pdfWithSumm, masterBaos.get(baosNo));
				
				masterBaos.set(baosNo, pdfWithSumm);
				//-------------------------------------------- Generate Summary Page End --------------------------------------------
				
				dc.addToImgDB(uniqueID, summSeqNo, baosNo, masterBaos.get(baosNo), "Y", "R", sourceType, "R");
				
				dc.addPrintSummDet(uniqueID, summSeqNo, baosNo, uniqueID + "_" + baosNo, "RE-GEN");
			}
			System.out.println("--------------------------------[" + sdf.format(new java.util.Date()) + "][" + new java.util.Date() + "] [GeneratePDF.java] reGen() generate PDF File END --------------------------------");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}*/
	
	public void reGen(String uniqueID, String seqNo) {
		
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
				
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss:SSS");
		
		try{
			HashMap<String, String> printSummaryList = dc.getPrintSummary(uniqueID, seqNo);
			String processYear = printSummaryList.get("ProcessYear");
			int summSeqNo = Integer.valueOf(printSummaryList.get("SeqNo"));
			
			dc.updateProcessCase(uniqueID, summSeqNo, processYear);
			
			System.out.println("--------------------------------[" + sdf.format(new java.util.Date()) + "][" + new java.util.Date().getTime() + "] [GeneratePDF.java] reGen() generate PDF File Start --------------------------------");
			

			List<String> taxInvNoList = dc.getTaxInvList(uniqueID, summSeqNo, processYear, cu.getMaxTaxInvPerFile());
			System.out.println("--------------------------------[" + new java.util.Date() + "] [GeneratePDF.java] reGen() line 405 [total taxInvNoList == " + taxInvNoList.size() + "] --------------------------------");
						
			int taxInvCalc = 0;
			int fileSeqNo = 0;
			String test = "";
			
			List<String> taxInvNoListprocess = new ArrayList<String>();
			
			ThreadPool executor = new ThreadPool();
			
			for(String taxInvNo : taxInvNoList) {
				if (test.length() > 0) {
					test += ", ";
				}
				
				test += "'" + taxInvNo + "'";
				taxInvCalc++;
				taxInvNoListprocess.add(taxInvNo);
			
				if (taxInvCalc == cu.getMaxTaxInvPerFile()) {
//					System.out.println("--------------------------------[" + new java.util.Date() + "] [GeneratePDF.java] reGen() line 427 --------------------------------");
					HashMap<Integer, HashMap<String, String>> taxInvRSAll = dc.getTaxInvDetails(test, processYear);
//					System.out.println("--------------------------------[" + new java.util.Date() + "] [GeneratePDF.java] reGen() line 429 --------------------------------");
				
					taxInvCalc = 0;
					test = "";
				
					final List<String> taxInvNoListprocess2 = taxInvNoListprocess;
					final HashMap<Integer, HashMap<String, String>> taxInvRSAll2 = taxInvRSAll;
					final String processYear2 = processYear;
					final String uniqueID2 = uniqueID;
					final int summSeqNo2 = summSeqNo;
					final int fileIdx = fileSeqNo;
					
					Runnable runner = new Runnable() {
						public void run() {
							long threadID = Thread.currentThread().getId();
							genPDFThread(taxInvRSAll2, taxInvNoListprocess2, processYear2, uniqueID2, summSeqNo2, threadID, fileIdx);
						}
					};
					
					executor.runTask(runner);
					
					fileSeqNo++;
					taxInvNoListprocess	= new ArrayList<String>();
				}
			}
			
			if (taxInvCalc > 0) {
				final List<String> taxInvNoListprocess2 = taxInvNoListprocess;
				final HashMap<Integer, HashMap<String, String>> taxInvRSAll2 = dc.getTaxInvDetails(test, processYear);
				final String processYear2 = processYear;
				final String uniqueID2 = uniqueID;
				final int summSeqNo2 = summSeqNo;
				final int fileIdx = fileSeqNo;
				
				Runnable runner = new Runnable() {
					public void run() {
						long threadID = Thread.currentThread().getId();
						genPDFThread(taxInvRSAll2, taxInvNoListprocess2, processYear2, uniqueID2, summSeqNo2, threadID, fileIdx);
					}
				};
				
				executor.runTask(runner);
			}
			
			executor.shutDown();
			System.out.println("--------------------------------[" + new java.util.Date() + "] [GeneratePDF.java] reGen() generate PDF File END --------------------------------");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void genPDFThread(HashMap<Integer, HashMap<String, String>> taxInvRSAll2, List<String> taxInvNoList2, String processYear2, String uniqueID2, int summSeqNo2, long threadID, int fileIdx) {
		
		List<String> taxInvNoList = taxInvNoList2;
		HashMap<Integer, HashMap<String, String>> taxInvRSAll = taxInvRSAll2;
		String processYear = processYear2;
		String uniqueID = uniqueID2;
		int summSeqNo = summSeqNo2;
		
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GenericUtil gu = new GenericUtil();
		
		boolean isOriginal = false;
		String sourceType = "";
		
		List<ByteArrayOutputStream> masterBaos = new ArrayList<ByteArrayOutputStream>();
		List<List<String>> taxInvListPerBaos = new ArrayList<List<String>>();  
		List<String> taxInvPrintedList = new ArrayList<String>();
		
		ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
		
		int currTaxInvPerFile = 0;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss:SSS");
		
		try {
			System.out.println("--------------------------------[" + sdf.format(new java.util.Date()) + "] [GeneratePDF.java] genPDFThread() line 490 [taxInvNoList = " + taxInvNoList.size() + "] --------------------------------");

			for(String taxInvNo : taxInvNoList) {
				ByteArrayOutputStream tempPDFBaos = new ByteArrayOutputStream();
				
				HashMap<Integer, HashMap<String, String>> taxInvRS = new HashMap<Integer, HashMap<String,String>>();
				
				int currIdx = 0;
				System.out.println("taxInvRSAll.size(): " + taxInvRSAll.size());
				for (int i=0; i<taxInvRSAll.size(); i++) {
					HashMap<String, String> singleTaxInvRS = taxInvRSAll.get(i);
					if (taxInvNo.equalsIgnoreCase(singleTaxInvRS.get("TaxInvoiceNo"))) {
						taxInvRS.put(currIdx, taxInvRSAll.get(i));
						currIdx ++;
						singleTaxInvRS.remove(i);
					}
				}
				
				//-------------------------------------------START CALCULATE TOTAL------------------------------------------- 
				Double totalIncGST = 0.0;
				Double totalGST = 0.0;
				Double totalExcGST = 0.0;
				
				for (int i=0; i<taxInvRS.size(); i++) {
					HashMap<String, String> taxRowRec = taxInvRS.get(i);
					
					totalExcGST += Double.parseDouble(taxRowRec.get("AmtExclGST"));
					totalGST += Double.parseDouble(taxRowRec.get("AmtGST"));
					totalIncGST += Double.parseDouble(taxRowRec.get("AMTInclGST"));
				}
				
				for(int i=0; i<taxInvRS.size(); i++) {
					HashMap<String, String> rowData = taxInvRS.get(i);
		        	rowData.put("totalIncGST", String.valueOf(totalIncGST));
		        	rowData.put("totalGST", String.valueOf(totalGST));
		        	rowData.put("totalExcGST", String.valueOf(totalExcGST));
		        }						
				//-------------------------------------------END CALCULATE TOTAL-------------------------------------------
										
				HashMap<String, String> taxInvMaster = taxInvRS.get(0);
				
				System.out.println("Tax No: " + taxInvMaster.get("TaxInvoiceNo") + 
						", SourceType: " + taxInvMaster.get("SourceType"));
				String docFormat = dc.getDocFormat(taxInvMaster);
				sourceType = taxInvMaster.get("SourceType");
				
				// check for 8 characters policy number and convert to 10 characters
				taxInvRS = dc.checkAndConvertTo10CharPolNo(sourceType, taxInvRS);
				
				isOriginal = validateIsOriginalCopy("B", docFormat, taxInvMaster);
				
				if (docFormat != null && docFormat.trim().length() > 0) {
					boolean isGen = true;
					
					if (!cu.getHardCopy().equals(docFormat)) {
						isGen = false;
					}
					
					if (isGen) {
						HashMap<Integer, HashMap<String, String>> gstSummary = getGSTSummary(taxInvRS);
						taxInvPrintedList.add(taxInvNo);
						
						if (currTaxInvPerFile%10 == 0) {
							System.out.println("[" + sdf.format(new java.util.Date()) + "][" + currTaxInvPerFile + "] [" + threadID + "] Records Done!!!");
						}
						
						if (cu.getCreditNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = genCreditNote(taxInvRS, gstSummary);									
						} else if (cu.getDebitNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = genDebitNote(taxInvRS, gstSummary);
						} else if (cu.getSelfBill().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = genSelfBill(taxInvRS);
						} else if (cu.getTaxInvoice().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = genTaxInvoice(taxInvRS, gstSummary);
						} else if (cu.getSelfBill_claim().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = genSelfBillClaim(taxInvRS);
						}
						
						if (!isOriginal) {
							tempPDFBaos = gu.addWaterMark(tempPDFBaos);
						}
						
						currTaxInvPerFile ++;
					}
				}
				
				if (tempPDFBaos != null && tempPDFBaos.toByteArray().length > 0) {
					pdfBaos = gu.mergePDF(pdfBaos, tempPDFBaos);
				}
				
				if (currTaxInvPerFile == cu.getMaxTaxInvPerFile()) {
					if (!isOriginal) {
						pdfBaos = gu.addWaterMark(pdfBaos);
					}
					
					pdfBaos = gu.addOMRnIntNo(pdfBaos);
					
					masterBaos.add(pdfBaos);
					pdfBaos = new ByteArrayOutputStream();
					currTaxInvPerFile = 0;
					
					taxInvListPerBaos.add(taxInvPrintedList);
					
					dc.updateWorkableProcess(processYear, "Y", taxInvPrintedList);
					
					taxInvPrintedList = new ArrayList<String>();
				}
			}
			
			System.out.println("--------------------------------[" + sdf.format(new java.util.Date()) + "][GeneratePDF.java] genPDFThread() line 603 [last file records currTaxInvPerFile = " + currTaxInvPerFile + "] --------------------------------");
			
			if (currTaxInvPerFile > 0) {
				pdfBaos = gu.addOMRnIntNo(pdfBaos);
				
				masterBaos.add(pdfBaos);
				pdfBaos = new ByteArrayOutputStream();
				currTaxInvPerFile = 0;
				
				taxInvListPerBaos.add(taxInvPrintedList);
				taxInvPrintedList = new ArrayList<String>();
			}
		
			for (int baosNo = 0; baosNo < masterBaos.size(); baosNo++) {
				//-------------------------------------------- Generate Summary Page Start --------------------------------------------
				ByteArrayOutputStream pdfWithSumm = genSummaryPage(uniqueID, masterBaos.get(baosNo), baosNo, taxInvListPerBaos, sourceType);
				
				pdfWithSumm = gu.mergePDF(pdfWithSumm, masterBaos.get(baosNo));
				
				masterBaos.set(baosNo, pdfWithSumm);
				//-------------------------------------------- Generate Summary Page End --------------------------------------------
				
				dc.addToImgDB(uniqueID, summSeqNo, fileIdx, masterBaos.get(baosNo), "Y", "R", sourceType, "R");
				
				dc.addPrintSummDet(uniqueID, summSeqNo, fileIdx, uniqueID + "_" + fileIdx, "RE-GEN");
				
			}
			System.out.println("--------------------------------[" + new java.util.Date() + "] [GeneratePDF.java] reGen() generate PDF File END --------------------------------");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	protected boolean validateIsOriginalCopy(String inputType, String docFormat, HashMap<String, String> taxInvMaster) {
		CommonFileUtil cu = new CommonFileUtil();
		
		boolean isOriginal = false;
		
		if (cu.getSoftCopy().equals(docFormat)) {
			isOriginal = true;
		} else if (cu.getHardCopy().equals(docFormat)) {
			if ("B".equals(inputType)) {
				isOriginal = true;
			} else {
				if (!"Y".equalsIgnoreCase(taxInvMaster.get("IsProcess"))) {
					isOriginal = true;
				}
			}
		}
		
		return isOriginal;
	}
	
	protected ByteArrayOutputStream genCreditNote(HashMap<Integer, HashMap<String, String>> taxInvRS, HashMap<Integer, HashMap<String, String>> gstSummary) {
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
        
		try {
			String xmlTemplatePath = null;
			HashMap<String, String> taxInvMaster = taxInvRS.get(0);
			
			String companyCode = taxInvMaster.get("CompanyCode");
			
			String taxInvoiceNo = taxInvMaster.get("TaxInvoiceNo");
			String taxType = (taxInvoiceNo.startsWith("CN"))? "GST": "SST";
			
			if ("016".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/BHD/";
			} else if ("072".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/TKF/";
			} else if ("0M3".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/AHS/";
			} else if ("0M4".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/GI/";
			} else {
				dc.updatePrintSummaryStatus(taxInvMaster.get("SummaryID"), Integer.parseInt(taxInvMaster.get("SummarySeqNo")), "E", "Invalid company Code for Credit Note");
				System.out.println("----- Invalid company Code for Credit Note!!! -----");
				return null;
			}
			
			String path = cu.getCurrentClassPath() + xmlTemplatePath + "CR.xml";
			
			pdfGenerator.setGstSummary(gstSummary);
			
			// Read XML to Java object
	    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
	
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
            pdfGenerator.setReportDefinition(rpt);
            
            pdfGenerator.setDbData(taxInvRS);
            pdfGenerator.setCurrRowDBData(null);
            
            crBaos = pdfGenerator.runReport();
            
            return crBaos;
        } catch (JAXBException jex) {
        	System.out.println("[GeneratePDF.java] [genCreditNote] JAXBException --> " + jex.toString());
        } catch (Exception ex) {
        	System.out.println("[GeneratePDF.java] [genCreditNote] Exception --> " + ex.toString());
        }
		
		return null;
    }
	
	protected ByteArrayOutputStream genDebitNote(HashMap<Integer, HashMap<String, String>> taxInvRS, HashMap<Integer, HashMap<String, String>> gstSummary) {
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
        
		try {
			String xmlTemplatePath = null;
			HashMap<String, String> taxInvMaster = taxInvRS.get(0);
			
			String companyCode = taxInvMaster.get("CompanyCode");
			
			String taxInvoiceNo = taxInvMaster.get("TaxInvoiceNo");
			String taxType = (taxInvoiceNo.startsWith("DN"))? "GST": "SST";
			
			if ("016".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/BHD/";
			} else if ("072".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/TKF/";
			} else if ("0M4".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/GI/";
			} else {
				dc.updatePrintSummaryStatus(taxInvMaster.get("SummaryID"), Integer.parseInt(taxInvMaster.get("SummarySeqNo")), "E", "Invalid company Code for Debit Note");
				System.out.println("----- Invalid company Code for Debit Note!!! -----");
				return null;
			}
			
			String path = cu.getCurrentClassPath() + xmlTemplatePath + "DR.xml";
			
			pdfGenerator.setGstSummary(gstSummary);
			
			// Read XML to Java object
	    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
	
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
            pdfGenerator.setReportDefinition(rpt);
            
            pdfGenerator.setDbData(taxInvRS);
            pdfGenerator.setCurrRowDBData(null);
            
            crBaos = pdfGenerator.runReport();
            
            return crBaos;
        } catch (JAXBException jex) {
        	System.out.println("[GeneratePDF.java] [genDebitNote] JAXBException --> " + jex.toString());
        } catch (Exception ex) {
        	System.out.println("[GeneratePDF.java] [genDebitNote] Exception --> " + ex.toString());
        }
		
		return null;
    }
	
	protected ByteArrayOutputStream genSelfBill(HashMap<Integer, HashMap<String, String>> taxInvRS) {
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
        
		try {
			String xmlTemplatePath = null;
			HashMap<String, String> taxInvMaster = taxInvRS.get(0);
			
			String companyCode = taxInvMaster.get("CompanyCode");
			
			String taxInvoiceNo = taxInvMaster.get("TaxInvoiceNo");
			String taxType = (taxInvoiceNo.startsWith("I"))? "SST": "GST";
			
			if ("016".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/BHD/";
			} else if ("072".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/TKF/";
			} else if ("0M4".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/GI/";
			} else {
				dc.updatePrintSummaryStatus(taxInvMaster.get("SummaryID"), Integer.parseInt(taxInvMaster.get("SummarySeqNo")), "E", "Invalid company Code for Self Bill");
				System.out.println("----- Invalid company Code for Self Bill!!! -----");
				return null;
			}
			
			String path = cu.getCurrentClassPath() + xmlTemplatePath + "SB.xml";
				
			// Read XML to Java object
	    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
	
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
            pdfGenerator.setReportDefinition(rpt);
            
            pdfGenerator.setDbData(taxInvRS);
            pdfGenerator.setCurrRowDBData(null);
            
            crBaos = pdfGenerator.runReport();
            
            return crBaos;
        } catch (JAXBException jex) {
        	System.out.println("[GeneratePDF.java] [genSelfBill] JAXBException --> " + jex.toString());
        } catch (Exception ex) {
        	System.out.println("[GeneratePDF.java] [genSelfBill] Exception --> " + ex.toString());
        }
		
		return null;
    }
	
	protected ByteArrayOutputStream genTaxInvoice(HashMap<Integer, HashMap<String, String>> taxInvRS, HashMap<Integer, HashMap<String, String>> gstSummary) {
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
        
		try {
			String xmlTemplatePath = null;
			HashMap<String, String> taxInvMaster = taxInvRS.get(0);
			
			String companyCode = taxInvMaster.get("CompanyCode");
			
			String taxInvoiceNo = taxInvMaster.get("TaxInvoiceNo");
			String taxType = (taxInvoiceNo.startsWith("I"))? "SST": "GST";
			
			if ("016".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/BHD/";
			} else if ("072".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/TKF/";
			} else if ("0M3".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/AHS/";
			} else if ("0M4".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/GI/";
			} else {
				dc.updatePrintSummaryStatus(taxInvMaster.get("SummaryID"), Integer.parseInt(taxInvMaster.get("SummarySeqNo")), "E", "Invalid company Code for Tax Invoice");
				System.out.println("----- Invalid company Code for Tax Invoice!!! -----");
				return null;
			}
			
			String path = cu.getCurrentClassPath() + xmlTemplatePath + "TI.xml";
			
			pdfGenerator.setGstSummary(gstSummary);
			
			// Read XML to Java object
	    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
	
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
            pdfGenerator.setReportDefinition(rpt);
            
            pdfGenerator.setDbData(taxInvRS);
            pdfGenerator.setCurrRowDBData(null);
            
            crBaos = pdfGenerator.runReport();
            
            return crBaos;
        } catch (JAXBException jex) {
        	System.out.println("[GeneratePDF.java] [genTaxInvoice] JAXBException --> " + jex.toString());
        } catch (Exception ex) {
        	ex.printStackTrace();
//        	System.out.println("[GeneratePDF.java] [genTaxInvoice] Exception --> " + ex.toString());
        }
		
		return null;
    }
	
	protected ByteArrayOutputStream genSelfBillClaim(HashMap<Integer, HashMap<String, String>> taxInvRS) {
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
        
		try {
			String xmlTemplatePath = null;
			HashMap<String, String> taxInvMaster = taxInvRS.get(0);
			
			String companyCode = taxInvMaster.get("CompanyCode");
			
			String taxInvoiceNo = taxInvMaster.get("TaxInvoiceNo");
			String taxType = (taxInvoiceNo.startsWith("I"))? "SST": "GST";
			
			if ("016".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/BHD/";
			} else if ("072".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/TKF/";
			} else if ("0M4".equals(companyCode)) {
				xmlTemplatePath = "com/aia/pdfGenerator/xml/" + taxType + "/GI/";
			} else {
				dc.updatePrintSummaryStatus(taxInvMaster.get("SummaryID"), Integer.parseInt(taxInvMaster.get("SummarySeqNo")), "E", "Invalid company Code for Self Bill Claim");
				System.out.println("----- Invalid company Code for Self Bill Claim!!! -----");
				return null;
			}
			
			String path = cu.getCurrentClassPath() + xmlTemplatePath + "RA.xml";
				
			// Read XML to Java object
	    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
	
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
            pdfGenerator.setReportDefinition(rpt);
            
            pdfGenerator.setDbData(taxInvRS);
            pdfGenerator.setCurrRowDBData(null);
            
            crBaos = pdfGenerator.runReport();
            
            return crBaos;
        } catch (JAXBException jex) {
        	System.out.println("[GeneratePDF.java] [genSelfBill] JAXBException --> " + jex.toString());
        } catch (Exception ex) {
        	System.out.println("[GeneratePDF.java] [genSelfBill] Exception --> " + ex.toString());
        }
		
		return null;
    }
	
	protected ByteArrayOutputStream genSummaryPage(String processID, ByteArrayOutputStream pdfBaos, int baosNo, List<List<String>> taxInvListPerBaos, String sourceType) {
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		try {
			String path = cu.getCurrentClassPath() + "com/aia/pdfGenerator/xml/SummaryPage.xml";
			
			JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
			
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
            pdfGenerator.setReportDefinition(rpt);
            
            String taxInvList = "";
            for(String taxInvPrinted : taxInvListPerBaos.get(baosNo)) {
            	if (taxInvList.length() > 0) {
            		taxInvList += ", ";
            	}
            	
            	taxInvList += taxInvPrinted;
            }
            
            HashMap<Integer, HashMap<String, String>> summaryRS = new HashMap<Integer, HashMap<String,String>>();
            
            HashMap<String,String> summDetRS = new HashMap<String, String>();
            
            PdfReader Read_PDF_To_OMR = new PdfReader(pdfBaos.toByteArray());
			int totalPage = Read_PDF_To_OMR.getNumberOfPages();
            
            summDetRS.put("ProcessID", processID + "_" + baosNo);
			summDetRS.put("TotalPage", String.valueOf(totalPage));
			summDetRS.put("TaxInvList", taxInvList);
			summDetRS.put("SourceType", dc.getSourceTypeDesc(sourceType));
			
            summaryRS.put(0, summDetRS);
            
            pdfGenerator.setDbData(summaryRS);
            pdfGenerator.setCurrRowDBData(null);
            
            ByteArrayOutputStream tempBaos = pdfGenerator.runReport();
            
            return tempBaos;
			
		} catch (JAXBException jex) {
        	jex.printStackTrace();        	
        } catch (Exception ex) {
        	ex.printStackTrace();        	
        }
		
		return null;
	}
	
	protected HashMap<Integer, HashMap<String, String>> getGSTSummary (HashMap<Integer, HashMap<String, String>> taxInvRS) {
		int summIdx = 0;
		String currTaxCode = "";
		String preTaxCode = "";
		String taxCode = "";
		String taxDesc = "";
		int totalItem = 0;
		Double totalAmt = 0.0;
		Double totalGST = 0.0;
		
		HashMap<Integer, HashMap<String, String>> gstSummary = new HashMap<Integer, HashMap<String,String>>();
		HashMap<String, String> curGSTSummary = new HashMap<String, String>();
		
		try {
			for(int i = 0; i < taxInvRS.size(); i++) {
				boolean isNew = false;
				HashMap<String, String> rsRow = taxInvRS.get(i);
				
				currTaxCode = rsRow.get("TaxCode");
				
				if (!currTaxCode.equalsIgnoreCase(preTaxCode) && preTaxCode.length() > 0) {
					isNew = true;
				}
				
				if (isNew) {
					curGSTSummary.put("TaxCode", taxCode);
					curGSTSummary.put("TaxDescription", taxDesc);
					curGSTSummary.put("TotalItem", Integer.toString(totalItem));
					curGSTSummary.put("TotalAmt", Double.toString(totalAmt));
					curGSTSummary.put("TotalGST", Double.toString(totalGST));
					
					gstSummary.put(summIdx++, curGSTSummary);
					curGSTSummary = new HashMap<String, String>();
					
					taxCode = rsRow.get("TaxCode");
					taxDesc = rsRow.get("TaxDescription");
					totalItem = 1;
					totalAmt = rsRow.get("AMTInclGST")!=null && rsRow.get("AMTInclGST").length() > 0 ? Double.valueOf(rsRow.get("AMTInclGST")) : 0;
					totalGST = rsRow.get("AmtGST")!=null && rsRow.get("AmtGST").length() > 0 ? Double.valueOf(rsRow.get("AmtGST")) : 0;
				} else {
					taxCode = rsRow.get("TaxCode");
					taxDesc = rsRow.get("TaxDescription");
					totalItem++;
					totalAmt += rsRow.get("AMTInclGST")!=null && rsRow.get("AMTInclGST").length() > 0 ? Double.valueOf(rsRow.get("AMTInclGST")) : 0;
					totalGST += rsRow.get("AmtGST")!=null && rsRow.get("AmtGST").length() > 0 ? Double.valueOf(rsRow.get("AmtGST")) : 0;
				}
				
				preTaxCode = rsRow.get("TaxCode");				
			}
			
			curGSTSummary.put("TaxCode", taxCode);
			curGSTSummary.put("TaxDescription", taxDesc);
			curGSTSummary.put("TotalItem", Integer.toString(totalItem));
			curGSTSummary.put("TotalAmt", Double.toString(totalAmt));
			curGSTSummary.put("TotalGST", Double.toString(totalGST));
			
			gstSummary.put(summIdx++, curGSTSummary);
			
		} catch (Exception ex) {
        	System.out.println("[getGSTSummary] Exception :: " + ex.toString());
        }
		
		return gstSummary;
	}

	public Map<String, ByteArrayOutputStream> genPolicyPDF(PolicyInfo policyInfoDb, AppForm appFormDb, String 
			templateCode, String language) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		Map<String, ByteArrayOutputStream> pdfBaosMap = new LinkedHashMap<String, ByteArrayOutputStream>();
		String subTemplate = null;
		
		try {
			HashMap<String, String> templMap = dc.getTemplates(templateCode);
			
			// get templates path
			String templCompCode = cu.getTemplCompCode(policyInfoDb.getCompanyCode());
			String templHome = cu.getTemplatePath() + "/" + templCompCode + "/" + language;
			
			Iterator<Map.Entry<String, String>> it = templMap.entrySet().iterator();
			
			while(it.hasNext()) {
				Map.Entry<String, String> pair = (Map.Entry<String, String>)it.next();
				String templCode = pair.getKey();
				String templType = pair.getValue();
				
				// process template
				ByteArrayOutputStream pdfBaos = null;
				
				if(CommonFileUtil.CON.equalsIgnoreCase(templType)) {
					// Kishore - to get the sub template
					if(!cu.isBlank(templCode) && templCode.equalsIgnoreCase("T00021")) {
						 subTemplate=  dc.getSubTemplate(!cu.isBlank(policyInfoDb.getInsuredAge()) ? policyInfoDb.getInsuredAge(): 0);
						 pdfBaos = populatePDF(templHome, subTemplate, templType, policyInfoDb);
						 
					} else {
						pdfBaos = populatePDF(templHome, templCode, templType, policyInfoDb);
					}

				}
				else if(CommonFileUtil.PDS.equalsIgnoreCase(templType)) 
					pdfBaos = populatePDF(templHome, templCode, templType, policyInfoDb);
				
				else if(CommonFileUtil.APF.equalsIgnoreCase(templType)) 
					pdfBaos = populatePDF(templHome, templCode, templType, appFormDb);
				
				if(pdfBaos != null) 
					pdfBaosMap.put(templType, pdfBaos);
				
				it.remove(); // avoids a ConcurrentModificationException
			}
			
			/*ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
			
			for(ByteArrayOutputStream tempPDFBaos: pdfBaosMap)
				pdfBaos = gu.combinePDF(pdfBaos, tempPDFBaos);
			
			cu.generateFile(pdfBaosMap.get(CommonFileUtil.APF), templHome + "/" + "result.pdf");
			
			// try output the tiff result
			List<ByteArrayOutputStream> tiffBaosList = cu.pdfToTiff(pdfBaosMap.get(CommonFileUtil.PDS));
			
			int i = 0;
			for(ByteArrayOutputStream tiffBaos: tiffBaosList) {
				cu.generateFile(tiffBaos, templHome + "/" + "PAGE" + ++i + ".TIF");
			}*/
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.genPolicyPDF] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return pdfBaosMap;
	}
	
	public Map<String, ByteArrayOutputStream> genAgentManagerPDF(Map<String, AgentContract> agentTemplateMap ,List<String> templates ,String templHome) {
		CommonFileUtil cu = new CommonFileUtil();
		Map<String, ByteArrayOutputStream> pdfBaosMap = new LinkedHashMap<String, ByteArrayOutputStream>();
		String agentName = "";
		
		try {
			
			for (String templCode : templates) {
				ByteArrayOutputStream pdfBaos = null;
				
				AgentContract agentContract = (AgentContract) agentTemplateMap.get(templCode);
					if("S00009".equalsIgnoreCase(templCode)){
						agentName = "and "+agentContract.getAgentName().toUpperCase() +", Identity Card No. "+ agentContract.getIdNo().toUpperCase();
						 
					}else{
						 agentName = agentContract.getAgentName().toUpperCase() +", Identity Card No: "+ agentContract.getIdNo().toUpperCase();	
					}
					if("S00010".equalsIgnoreCase(templCode) || "S00008".equalsIgnoreCase(templCode)){
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
						SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
						String conDate = sdf.format(agentContract.getContractDate());
						String effDte = sdf1.format(agentContract.getEffectiveDate());
						conDate = conDate.substring(0,2) + "  "+conDate.substring(3,6)+" "+conDate.substring(7,conDate.length());
						agentContract.setContractDateString(conDate);
						if ("S00010".equalsIgnoreCase(templCode)){
							/* agentName = "THIS CONTRACT FOR SERVICES is dated this " + agentContract.getContractDateString() +
								 		" is made by and between the AIA PUBLIC TAKAFUL BHD. (formerly known as PUBLIC TAKAFUL EHSAN BERHAD) and AIA AFG Takaful Bhd. " +
								 		"having a place of business at Menara AIA 99, Jalan Ampang, 50450 Kuala Lumpur (hereinafter jointly " +
								 		"referred to �the Takaful Operator�) and " + agentContract.getAgentName() +
								 		" (hereinafter called �the Unit Manager�) and shall be effective from the " + effDte ;*/ 
							 agentName = "This Unit Manager�s Contract is dated this " + agentContract.getContractDateString().toUpperCase() +
								 		" is made between the AIA PUBLIC TAKAFUL BHD.  (Company No. 935955-M) having the place of business at Level 14,Menara AIA, 99, Jalan Ampang, 50450 Kuala Lumpur (hereinafter called the �Takaful " +
								 		"Operator�) and " + agentContract.getAgentName().toUpperCase() +
								 		" (hereinafter called �the Unit Manager�). This Contract shall be effective from " + effDte.toUpperCase() ;
						}else if("S00008".equalsIgnoreCase(templCode)){
							 agentName = agentContract.getAgentName() +" and (hereinafter called �the District Manager�) and shall be effective from the "+ effDte.toUpperCase() +"." ; 
						}
						 
						 		
					}else  if("S00011".equalsIgnoreCase(templCode)){
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
						SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
						String conDate = sdf.format(agentContract.getContractDate());
						String effDte = sdf1.format(agentContract.getEffectiveDate());
						conDate = conDate.substring(0,2) + "  "+conDate.substring(3,6)+" "+conDate.substring(7,conDate.length());
						agentContract.setContractDateString(conDate);
						// agentName = agentContract.getAgentName() +" (hereinafter called �the District Manager�).";
						agentName = "This District Manager�s Contract is dated this " + agentContract.getContractDateString().toUpperCase() +
						 		" is made between the AIA PUBLIC TAKAFUL BHD.  (Company No. 935955-M) having the place of business at Level 14,Menara AIA, 99, Jalan Ampang, 50450 Kuala Lumpur (hereinafter called the �Takaful " +
						 		"Operator�) and " + agentContract.getAgentName().toUpperCase() +
						 		" (hereinafter called �the District Manager�). This Contract shall be effective from " + effDte.toUpperCase() ;
 

					}
					agentContract.setNameAndId(agentName);	
//					agentContract.setAddress1(agentContract.getAddress1().toUpperCase()+"  "+agentContract.getAddress2().toUpperCase());
					agentContract.setAddr1(agentContract.getAddress1().toUpperCase()+" ,"+agentContract.getAddress2().toUpperCase());
   				    agentContract.setAddr2(agentContract.getAddress3().toUpperCase());
 					agentContract.setAddr3(agentContract.getPostcode().toUpperCase()+" ,"+agentContract.getState().toUpperCase());
//					agentContract.setAddress3(agentContract.getAddress3().toUpperCase()+"  "+agentContract.getPostcode().toUpperCase());
					agentContract.setState(agentContract.getCity().toUpperCase()+"  "+agentContract.getState().toUpperCase());
					agentContract.setAgentName(agentContract.getAgentName().toUpperCase());
					agentContract.setWitnessName(agentContract.getWitnessName().toUpperCase());
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
					String conDate = sdf.format(agentContract.getContractDate());
					conDate = conDate.substring(0,2) + " "+conDate.substring(3,6)+" "+conDate.substring(7,conDate.length());
					agentContract.setContractDateString(conDate.toUpperCase());
					System.out.println("[GeneratePDF][genAgentManagerPDF] Applicant Sign Date is ..:"+agentContract.getApplicantSignDate());
					System.out.println("[GeneratePDF][genAgentManagerPDF] Processing template is ..:"+templCode);
					 pdfBaos = populatePDF(templHome, templCode, "CON", agentContract);
					 if(pdfBaos != null) 
							pdfBaosMap.put(templCode, pdfBaos);
					 
			}
			
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.genPolicyPDF] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return pdfBaosMap;
	}
	
	public Map<String, ByteArrayOutputStream> genWebFormPolicyPDF(PolWebForm polWebFormDb, String companyCode, String 
			templateCode, String language ) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		Map<String, ByteArrayOutputStream> pdfBaosMap = new LinkedHashMap<String, ByteArrayOutputStream>();
		
		try {
			HashMap<String, String> templMap = dc.getTemplates(templateCode);
			
			// get templates path
			String templCompCode = cu.getTemplCompCode(companyCode);
			String templHome = cu.getTemplatePath() + "/" + templCompCode + "/" + language;
			
			Iterator<Map.Entry<String, String>> it = templMap.entrySet().iterator();
			
			while(it.hasNext()) {
				Map.Entry<String, String> pair = (Map.Entry<String, String>)it.next();
				String templCode = pair.getKey();
				String templType = pair.getValue();
				
				// process template
				ByteArrayOutputStream pdfBaos = null;
				
				if(CommonFileUtil.CON.equalsIgnoreCase(templType)) {
					if("".equalsIgnoreCase(polWebFormDb.getAppDetails()) || null == polWebFormDb.getAppDetails() ){
						//do nothing;
					}else{
						templCode = "T00041a";
					}
					pdfBaos = populatePDF(templHome, templCode, templType, polWebFormDb);
				}
				
				if(pdfBaos != null) 
					pdfBaosMap.put(templType, pdfBaos);
				
				it.remove(); // avoids a ConcurrentModificationException
			}
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.genWebFormPolicyPDF] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return pdfBaosMap;
	}

	private ByteArrayOutputStream populatePDF(String srcPath, String templCode, String templType, Object obj) {
		ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
		CommonFileUtil cu = new CommonFileUtil();
		
		String srcPDF = srcPath + "/" + templCode + ".pdf";
		String srcXML = srcPath + "/" + templCode + ".xml";
		
		try {
			String xmlStr = new Scanner(new File(srcXML)).useDelimiter("\\A").next();
			
			org.dom4j.Document docRoot = DocumentHelper.parseText(xmlStr);
			Node templNode = docRoot.selectSingleNode("//template");
			
			if(!validateTemplate(templNode, templCode, templType))
				return null;
			
			PdfReader reader = new PdfReader(srcPDF);
			PdfStamper stamper = new PdfStamper(reader, pdfBaos);
			
			Node fontNode = docRoot.selectSingleNode("//template/font");
			int fontSize = Integer.parseInt(fontNode.selectSingleNode("size").getText());
			String fontStyle = fontNode.selectSingleNode("style").getText();
			
			Font defaultFont = new Font(BaseFont.createFont(), fontSize);
			defaultFont.setStyle(fontStyle);
			
			String defaultDateFormat = docRoot.selectSingleNode("//template/dateformat").getText();
			
			@SuppressWarnings("unchecked")
			List<Node> pages = docRoot.selectNodes("//template/pages/*");
			
			for(Node page: pages) {
				int pageNumber = Integer.parseInt(page.selectSingleNode("number").getText());
				PdfContentByte canvas = stamper.getOverContent(pageNumber);
				
				@SuppressWarnings("unchecked")
				List<Node> coordinates = page.selectNodes("coordinates/*");
				
				for(Node node: coordinates) {
					org.dom4j.Element element = (org.dom4j.Element) node;
					
					if("coordinate".equalsIgnoreCase(element.getName())) {
						processCanvas(canvas, element, defaultDateFormat, defaultFont, obj, 0, 0, stamper);
						
					} else if("list".equalsIgnoreCase(element.getName())) {
						String methodName = element.attributeValue("method");
						
						float yIncrement = (!cu.isBlank(element.attributeValue("y-increment")))? 
								Float.parseFloat(element.attributeValue("y-increment")): 0;
						float yCurrent = 0;
						
						float xIncrement = (!cu.isBlank(element.attributeValue("x-increment")))? 
								Float.parseFloat(element.attributeValue("x-increment")): 0;
						float xCurrent = 0;
						
						@SuppressWarnings("unchecked")
						List<Node> nodes = node.selectNodes("coordinate");
						
						for(Method method: obj.getClass().getDeclaredMethods()) {
							if(methodName.equalsIgnoreCase(method.getName())) {
								@SuppressWarnings("unchecked")
								List<Object> objects = (List<Object>) method.invoke(obj);
								
								if(objects != null && objects.size() > 0) {
									int repeat = !cu.isBlank(element.attributeValue("repeat"))? 
											Integer.parseInt(element.attributeValue("repeat")): objects.size();
									
									for(int i = 0; i < repeat; i++) {
										Object object = objects.get(i);
										
										for(Node inNode: nodes) {
											org.dom4j.Element inElement = (org.dom4j.Element) inNode;
											processCanvas(canvas, inElement, defaultDateFormat, defaultFont, object, 
													yCurrent, xCurrent, stamper);
										}
										
										yCurrent += yIncrement;
										xCurrent += xIncrement;
									}
								}
								
								/*for(Object object: objects) {
									for(Node inNode: nodes) {
										org.dom4j.Element inElement = (org.dom4j.Element) inNode;
										processCanvas(canvas, inElement, defaultDateFormat, defaultFont, object, 
												yCurrent, xCurrent);
									}
									
									yCurrent += yIncrement;
									xCurrent += xIncrement;
								}*/
								
								break;
							}
						}
					}
				}
			}
			
			stamper.close();
			reader.close();
			
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.populatePDF] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return pdfBaos;
	}
	
	private void processCanvas(PdfContentByte canvas, org.dom4j.Element element, String defaultDateFormat,
			Font defaultFont, Object obj, float yIncrement, float xIncrement, PdfStamper stamper) {
		CommonFileUtil cu = new CommonFileUtil();
		
		try {
			float x = Float.parseFloat(element.attributeValue("x"));
			float y = Float.parseFloat(element.attributeValue("y"));
			
			float x2 = (!cu.isBlank(element.attributeValue("x2")))?Float.parseFloat(element.attributeValue("x2")): 0;
			float y2 = (!cu.isBlank(element.attributeValue("y2")))?Float.parseFloat(element.attributeValue("y2")): 0;
			
			float x3 = (!cu.isBlank(element.attributeValue("x3")))?Float.parseFloat(element.attributeValue("x3")): 0;
			float y3 = (!cu.isBlank(element.attributeValue("y3")))?Float.parseFloat(element.attributeValue("y3")): 0;
			
			float x4 = (!cu.isBlank(element.attributeValue("x4")))?Float.parseFloat(element.attributeValue("x4")): 0;
			float y4 = (!cu.isBlank(element.attributeValue("y4")))?Float.parseFloat(element.attributeValue("y4")): 0;
			
			float x5 = (!cu.isBlank(element.attributeValue("x5")))?Float.parseFloat(element.attributeValue("x5")): 0;
			float y5 = (!cu.isBlank(element.attributeValue("y5")))?Float.parseFloat(element.attributeValue("y5")): 0;
			
			float x6 = (!cu.isBlank(element.attributeValue("x6")))?Float.parseFloat(element.attributeValue("x6")): 0;
			float y6 = (!cu.isBlank(element.attributeValue("y6")))?Float.parseFloat(element.attributeValue("y6")): 0;
			
			String methodName = element.attributeValue("method");
			String returnType = element.attributeValue("type");
			String addText = !cu.isBlank(element.attributeValue("add-text"))? element.attributeValue("add-text"): "";
			
			String dateFormat = (!cu.isBlank(element.attributeValue("format")))? element.attributeValue("format"): null;
			if(dateFormat == null) dateFormat = defaultDateFormat;
			
			Font innerFont = new Font(BaseFont.createFont(), defaultFont.getSize());
			innerFont.setStyle(defaultFont.getStyle());
			
			String fontStyle = (!cu.isBlank(element.attributeValue("style")))? element.attributeValue("style"): null;
			if("BOLD".equalsIgnoreCase(fontStyle)){
				innerFont.setStyle(Font.BOLD);
			}
			if("ITALIC".equalsIgnoreCase(fontStyle)){
				innerFont.setStyle(Font.ITALIC);
			}
			String fontSize = (!cu.isBlank(element.attributeValue("size")))? element.attributeValue("size"): null;
			if(!cu.isBlank(fontSize)) innerFont.setSize(Float.parseFloat(fontSize));
			
			int maxLength = (!cu.isBlank(element.attributeValue("maxlength")))? 
								Integer.parseInt(element.attributeValue("maxlength")): 0;
			float yOverflow = (!cu.isBlank(element.attributeValue("y-overflow")))? 
								Float.parseFloat(element.attributeValue("y-overflow")): 0;
								
			for(Method method: obj.getClass().getDeclaredMethods()) {
				if(methodName.equalsIgnoreCase(method.getName())) {
					Object objValue = method.invoke(obj);
					y = y + yIncrement;
					x = x + xIncrement;
					
					if(objValue == null) {
						if("date".equalsIgnoreCase(returnType) || "decimal".equalsIgnoreCase(returnType)) {
							ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
									new Phrase("N/A" + addText, innerFont), x, y, 0);
						}
						if("blankdate".equalsIgnoreCase(returnType)) {
							ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, new Phrase("", innerFont), x, y, 0);
						}
					} else if(objValue != null) {
						if("string".equalsIgnoreCase(returnType)) {
							if("getAppDetails".equalsIgnoreCase(method.getName())) {
								String[] lines = objValue.toString().split("\n|\r");
								for(String line: lines) {
									System.out.println("GenPDF - Carriage Rturn line :"+line);
									maxLength = (maxLength > 0) ? maxLength: line.length();
									List<String> objList = cu.getTextList(line, maxLength);
									for(String text: objList) {
										ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
												new Phrase(text + addText, innerFont), x, y, 0);
										y += yOverflow;
									}
								}
							}else{
								maxLength = (maxLength > 0) ? maxLength: objValue.toString().length();
								List<String> objList = cu.getTextList(objValue.toString(), maxLength);
								
								for(String text: objList) {
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(text + addText, innerFont), x, y, 0);
									y += yOverflow;
								}
							}
						}
						
						if("date".equalsIgnoreCase(returnType) || "blankdate".equalsIgnoreCase(returnType)) 
							ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
									new Phrase(GenericUtil.dateToStr((Date)objValue, dateFormat).toUpperCase() + addText, 
											innerFont), x, y, 0);
						
						if("decimal".equalsIgnoreCase(returnType)) 
							ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
									new Phrase(cu.getNumberFormat((BigDecimal)objValue) + addText, innerFont), x, y, 0);
						
						if("boolean".equalsIgnoreCase(returnType)) {
							boolean boolVal = ("Y".equalsIgnoreCase(objValue.toString()))? true: false;
							
							if("getModeOfPayment".equalsIgnoreCase(method.getName())) {
								if("01".equalsIgnoreCase(objValue.toString()) || "1".equalsIgnoreCase(objValue.toString())){
									System.out.println("Mode Of Payment :"+objValue.toString());

									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x4, y4, 0);
								}else
								if("03".equalsIgnoreCase(objValue.toString()) || "3".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x3, y3, 0);
								}else
								if("06".equalsIgnoreCase(objValue.toString()) || "6".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x2, y2, 0);
								}else
								if("12".equalsIgnoreCase(objValue.toString()) ){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								}
							}else if("getAppq2".equalsIgnoreCase(method.getName())){
//								System.out.println("WebForm Question 1 Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if("N".equalsIgnoreCase(objValue.toString())){
									System.out.println("WebForm Question 1 Ans is 'N'");
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}
								
							}else if("getAppq3".equalsIgnoreCase(method.getName())){
								System.out.println("WebForm Question 2 Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if("N".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}
								
							}else if("getAppWasi".equalsIgnoreCase(method.getName())){
								System.out.println("WebForm Wasi Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								}
							}else if("getAppConditionalHibah".equalsIgnoreCase(method.getName())){
								System.out.println("WebForm ConditionalHibah Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								}
							}else if("getAppPremiumFinanced".equalsIgnoreCase(method.getName())){
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if("N".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}
							}else if("getAppOptin".equalsIgnoreCase(method.getName())){
						//		System.out.println("WebForm Wasi Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								}
							}else if("getAppFATCAUSPersonCircumstances".equalsIgnoreCase(method.getName())){
						//		System.out.println("WebForm Wasi Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								}
							}else if("getAppFATCAUSPersonDataWaiver".equalsIgnoreCase(method.getName())){
//								System.out.println("WebForm getAppFATCAUSPersonDataWaiver Ans :"+objValue.toString());
								if("Y".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								}
							}else if("getAppFOREIGNERCLF".equalsIgnoreCase(method.getName())){
//								System.out.println("WebForm getAppFOREIGNERCLF Ans :"+objValue.toString());
								if("W".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if("I".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}else {
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x3, y3, 0);
								}
							}
							else if("getNonCRSReasonoptj3".equalsIgnoreCase(method.getName())){
								if("A".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if("B".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}else if("C".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x3, y3, 0);
								}
								else if("D".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x4, y4, 0);
								}
								else if("E".equalsIgnoreCase(objValue.toString())){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x5, y5, 0);
								}
								else {
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x6, y6, 0);
								}
							}
							else if("getAppLASumAssured".equalsIgnoreCase(method.getName())){
								
								double laSumAssured=Double.parseDouble(objValue.toString());
								
								if(laSumAssured==50000){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if(laSumAssured==100000){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}
								else if(laSumAssured==200000) {
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x3, y3, 0);
								}
							}
                            else if("getAppCoverageTerm".equalsIgnoreCase(method.getName())){
								
								int appAge=Integer.parseInt(objValue.toString());
								
								if(appAge >=18 && appAge<=44){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x, y, 0);
								}else if(appAge >=45 && appAge<=55){
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase(".", innerFont), x2, y2, 0);
								}
							}
                            
							else {
								if("EN".equalsIgnoreCase(objValue.toString()) || "MS".equalsIgnoreCase(objValue.toString()))
									boolVal = ("EN".equalsIgnoreCase(objValue.toString()))? true: false;
								
								if(boolVal)
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x, y, 0);
								else
									ColumnText.showTextAligned(canvas, Element.ALIGN_LEFT, 
											new Phrase("X", innerFont), x2, y2, 0);
							}
							
							
						} else if("image".equalsIgnoreCase(returnType)) {
//							System.out.println("Image String .."+objValue.toString());
							
							String[] dbText = objValue.toString().split(",");
							System.out.println(dbText[1]);
							BufferedImage imgBuffer = GenericUtil.decodeToImage(dbText[1]);
							ByteArrayOutputStream baos = new ByteArrayOutputStream();
							
							String[] dbImgType = objValue.toString().split(";");
							String imgType = dbImgType[0].split("/")[1];
							System.out.println(imgType);
							ImageIO.write(imgBuffer, imgType, baos);
							
							baos.flush();
							byte[] imageInByte = baos.toByteArray();
							baos.close();
							
							Image image = Image.getInstance(imageInByte);
							//PdfImage imgStream = new PdfImage(image, "", null);
							//imgStream.put(new PdfName("ITXT_SpecialId"), new PdfName("123456789"));
							
							//PdfIndirectObject ref = stamper.getWriter().addToBody(imgStream);
							//image.setDirectReference(ref.getIndirectReference());
						//	image.setTransparency(new int[]{0x00, 0x10});
							image.setAbsolutePosition(x, y);
							image.scalePercent(25, 25);
							//canvas.addImage(image, 100, 0, 0, 50, x, y);
							canvas.addImage(image);
							
							// To position an image at (x,y) use 
							// addImage(image, image_width, 0, 0, image_height, x, y). 
							// The image can be placed inline.
							// example: addImage(image, width, 0, 0, height, x, y, true)
							//canvas.addImage(image, 0, 0, 0, 0, x,  y, true);
						}
					}
					
					break;
				}
			}
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.processCanvas] Exception: " + ex.toString());
			ex.printStackTrace();
		}
	}

	private boolean validateTemplate(Node templNode, String templCode, String templType) {
		boolean validated = false;
		
		if(templCode.equalsIgnoreCase(templNode.selectSingleNode("name").getText()) && 
				templType.equalsIgnoreCase(templNode.selectSingleNode("type").getText()))
			validated = true;
		
		return validated;
	}
	
	public String getPDFCoordinates(String pdfPath, int pageNo) {
		String pdfContent = null;
		
		try {
			PdfReader reader = new PdfReader(pdfPath);
			
	    	PdfDictionary dict = reader.getPageN(pageNo);
	    	PdfObject object = dict.getDirectObject(PdfName.CONTENTS);
	    	
	    	if (object instanceof PRStream) {
	    		PRStream stream = (PRStream)object;
	    		byte[] data = PdfReader.getStreamBytes(stream);
	    		
	    		pdfContent = new String(data);
	    		//stream.setData(new String(data).replace("{INSURED}", "THE INSURED").getBytes());
	    	}
	    	
	    	reader.close();
			
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.getPDFCoordinates] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return pdfContent;
	}

	public ByteArrayOutputStream encryptPDF(ByteArrayOutputStream pdfFile, String password) {
		ByteArrayOutputStream encryptedPDF = new ByteArrayOutputStream();
		
		try {
			InputStream fis = new ByteArrayInputStream(pdfFile.toByteArray());
			
			PdfReader reader = new PdfReader(fis);
			
			PdfStamper stamper = new PdfStamper(reader, encryptedPDF);
			
			// remove unnecessary characters
			password = password.trim().replace(" ", "").replace("-", "");
			
			stamper.setEncryption(password.getBytes(), "AIA_2017".getBytes(), 
					PdfWriter.ALLOW_PRINTING, PdfWriter.ENCRYPTION_AES_128);
			
			stamper.close();
			reader.close();
			
			System.out.println("PDF has been encrypted.");
		
		} catch(Exception ex) {
			System.out.println("[GeneratePDF.getPDFCoordinates] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return encryptedPDF;
	}
}
