/**
 * 
 */
package com.aia.service;

import ho.aia.utility.host.PasswordFile;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import com.aia.pdfGenerator.model.Reports;
import com.aia.pdfGenerator.util.GenericGeneratorMB;
import com.ibm.as400.access.AS400;
import com.ibm.as400.access.IFSFile;
import com.ibm.as400.access.IFSFileInputStream;

/**
 * @author ITT0121
 *
 */
public class MasterBilling extends Thread {

	/**
	 * @param args
	 */
	
	private Thread t;
	public MasterBilling() {
		System.out.println("MasterBilling..Creating thread " );
	}
	
	public void run() {
		System.out.println("MasterBilling Start....");
//		connectWindow();
		HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> rowsMBDetails = getBillingDetails();
		int noFiles;
		noFiles = rowsMBDetails.size();
		//SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
			
		for (int i=0 ; i< noFiles-1 ; i++) {
			//System.out.println("noFiles size inside for loop:"+noFiles);
			HashMap<Integer, HashMap<String, String>> rowMBDtls = rowsMBDetails.get(i);
			ByteArrayOutputStream baos = genMasterBillingMY(rowMBDtls);
			String date = rowMBDtls.get(0).get("monthYear");
			//System.out.println("date---------->:" + date);
			
			if(date.contains("January")){
				date =date.substring(date.length()-4) +"01";
			}else if(date.contains("February")){
				date =date.substring(date.length()-4) +"02";
			}else if(date.contains("March")){
				date =date.substring(date.length()-4) +"03";
			}else if(date.contains("April")){
				date =date.substring(date.length()-4) +"04";
			}else if(date.contains("May")){
				date =date.substring(date.length()-4) +"05";
			}else if(date.contains("June")){
				date =date.substring(date.length()-4) +"06";
			}else if(date.contains("July")){
				date =date.substring(date.length()-4) +"07";
			}else if(date.contains("August")){
				date =date.substring(date.length()-4) +"08";
			}else if(date.contains("September")){
				date =date.substring(date.length()-4) +"09";
			}else if(date.contains("October")){
				date =date.substring(date.length()-4) +"10";
			}else if(date.contains("November")){
				date =date.substring(date.length()-4) +"11";
			}else if(date.contains("December")){
				date =date.substring(date.length()-4) +"12";;
			}
			
			String Adjfilenam = rowMBDtls.get(0).get("AdjorAfilename").toString().trim();
			/*System.out.println("billNumber------>:"+ rowMBDtls.get(0).get("AdjorAfilename"));
			String mbFile = "D:\\TEST_write\\MasterBilling\\PET."+ date+"_"+ Adjfilenam +"_" + "MasterBilling.pdf";
		    uploadLocalFile(baos,mbFile);*/
		    
		    

			String path = "";
			ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
			path= bundle.getString("WritePathFile");
			
//			String pathFile = path+"//PET." + date+"_"+ billNum +"_" + "CoverLetter.pdf";	
			String mbFile = path+"PET."+ date+"_"+ Adjfilenam +"_" + "MasterBilling.pdf";
			System.out.println("MasterBilling.. mbFile--------->: " + mbFile);
			uploadLocalFile(baos,mbFile);
		}	      
	}

	public static HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> getBillingDetails(){
		   HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> rowsMBDetails=new HashMap<Integer ,HashMap<Integer, HashMap<String, String>>>();
		   HashMap<Integer, HashMap<String, String>> rowMBDetails = new HashMap<Integer, HashMap<String, String>>();

		   try {
			   
	    	   /*String fileName = "D:\\TEST_Read\\Petronas_Mas_Bill_20180601_0011.txt";
	    	   
	   		   FileReader fr = null;
	           fr = new FileReader(fileName);

	   		   BufferedReader br = null;
	           br = new BufferedReader(fr);*/
	           
			   
			   System.out.println("Calling connAS400ReadFile Method");
			   BufferedReader br = connAS400ReadFile();
	    	   
			   if(br == null || br.equals("")){
				   System.out.println("No Cover Letter Flat file ");
			   }else{
				   
				   System.out.println("END connAS400ReadFile Method");
	           
	           String sCurrentLineData = "";
	           int curline = -1;
	           int pdfgenCount = -1;

	           while ((sCurrentLineData = br.readLine()) != null) {
	           HashMap<String, String> cellMBDetails = new HashMap<String, String>();

					if(curline == -1 || sCurrentLineData.contains("****")) {
						rowMBDetails = new HashMap<Integer, HashMap<String, String>>();
						cellMBDetails = new HashMap<String, String>();
						pdfgenCount++;
						curline=-1;
					}
					
					/*if(pdfgenCount == 7){
						break;
					}*/
					
					
					String[] data = sCurrentLineData.split("\\|");
					
					for(int i=0; i<data.length; i++){
						/*if(data[0].equalsIgnoreCase("9999")){
							 break;
						 }*/
						if(curline == -1 || sCurrentLineData.contains("****")) {
						} else if(i == 2 && data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")) {
		       				cellMBDetails.put("monthYear", data[i] != null && data[i].length()>0 ?data[i].toString().trim() : "");
		       				System.out.println(data[i] != null && data[i].length()>0 ?data[i].toString().trim() : "");
						} else if(i == 3 && data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")) {
		       				cellMBDetails.put("AdjorAfilename", data[i] != null && data[i].length()>0 ?data[i] : "");
						}else if(i == 2 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
			       			cellMBDetails.put("refGrouping", data[i] != null && data[i].length()>0 ?data[i] : "");
		       			} else if(i == 3 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		       				cellMBDetails.put("policyNumber", data[i] != null && data[i].length()>0 ?data[i] : "");
		       			} else if(i == 4 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		       				cellMBDetails.put("opuSubCode", data[i] != null && data[i].length()>0 ?data[i] : "");
		       			} else if(i == 5 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		       				cellMBDetails.put("subsidiaryName", data[i] != null && data[i].length()>0 ?data[i] : "");
		       			} else if(i == 6 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		       				cellMBDetails.put("billNumber", data[i] != null && data[i].length()>0 ?data[i] : "");
		       			} else if(i == 7 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		       				cellMBDetails.put("billDate", data[i] != null && data[i].length()>0 ?data[i] : "");
		       			} else if(i == 8 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		       				cellMBDetails.put("adminFee", data[i] != null && data[i].length()>0 ?data[i] : "");
		       				
		            	} else if(i == 9 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		            		cellMBDetails.put("gst", data[i] != null && data[i].length()>0 ?data[i] : "");
		            	} else if(i == 10 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
		            		cellMBDetails.put("st", data[i] != null && data[i].length()>0 ?data[i] : "");	
		            	} else if(i == 2 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("2D")) {
			            	cellMBDetails.put("totalAdminFee", data[i] != null && data[i].length()>0 ?data[i] : "");
						} else if(i == 3 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("2D")) {
				            cellMBDetails.put("totalGST", data[i] != null && data[i].length()>0 ?data[i] : "");
			     		}
						else if(i == 4 && data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("2D")) {
				            cellMBDetails.put("totalST", data[i] != null && data[i].length()>0 ?data[i] : "");
			     		}
						
					}
					
					/*System.out.println("Curline Before:"+curline);
					System.out.println("BillingDetails Size Before:"+cellMBDetails.size());
					System.out.println("BillingDetails Before:"+cellMBDetails);*/
					if(curline == -1 || sCurrentLineData.contains("****")){
						curline++;
					} else{
						rowMBDetails.put(curline++, cellMBDetails);
						rowsMBDetails.put(pdfgenCount, rowMBDetails);
					}
					/*System.out.println("Curline After:"+curline);
					System.out.println("BillingDetails Size After:"+cellMBDetails.size());*/
				//	System.out.println("BillingDetails After:"+cellMBDetails);
				}	
			   }
	          } catch(Exception ex) {
	                 System.out.println("[MasterBilling.getBillingDetails] Exception: " + ex.toString());
	                 ex.printStackTrace();
	          }
	       	  return rowsMBDetails;  
	   }
	   
	   public static synchronized void uploadLocalFile(ByteArrayOutputStream baos, String mbFile){
		   System.out.println("MasterBilling uploadLocalFile--------->: ");
			SmbFileOutputStream sfos = null;
	       try {
				ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
				PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONASWIN", "USER", "PASSWD");
	  	   NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", pwdFile.getUserId(), pwdFile.getPassword());
     // 	 NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", "KAPPUSON", "Welcome@1");
	    	        System.out.println("File Path :"+mbFile);
	    	        System.out.println("Auth connect done----->");
	    	        SmbFile smbfile = new SmbFile(mbFile, auth);
	    	        System.out.println("smbfile...:"+smbfile);
	    	     //   String pathnew =  pathFile +"//PET." + "CoverLetter.pdf";
	    	        sfos = new SmbFileOutputStream(smbfile);
	                 
	                  baos.writeTo(sfos);
	                  sfos.close();
	   //     System.out.println(" Uploaded to PFV: " + pathFile);
	       } catch(Exception ex){
	              System.out.println("[MasterBilling.uploadLocalFile] Exception: " + ex.toString());
	              ex.printStackTrace();
	       }
	   }
	   
	   public void startBatch() {
			System.out.println("Starting thread ");
			
			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}
	   
	   public static  BufferedReader connAS400ReadFile(){
			  System.out.println(" In connAS400ReadFile");
			  String processFile = "";
			  String totPath = "";
			  String ipAdd = "";
			  String folPath ="";
			  SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
			  Date datee = new Date();
			  String date = sdfDate.format(datee);
			  IFSFileInputStream inputStream = null;
//			  IFSFileInputStream inputStream_ = new IFSFileInputStream(file);
			  BufferedReader reader = null;
				   FileReader fr = null;
					try {
						ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
						PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONAS", "USER", "PASSWD");
						totPath = bundle.getString("FileReadPath");
						ipAdd = totPath.substring(0, totPath.indexOf("/"));
						folPath = totPath.substring(totPath.indexOf("/"));
						System.out.println("IP :"+ipAdd +", Path:"+folPath);
/*						System.out.println("UserID:"+bundle.getString("UserID"));
						System.out.println("Password:"+bundle.getString("Password"));
						System.out.println("DATE:---->"+  date);*/
						AS400 as400 = new AS400(ipAdd, pwdFile.getUserId(), pwdFile.getPassword());
			              IFSFile path = new IFSFile(as400, folPath);
			              if (path.isDirectory()) {
			                     IFSFile[] files = path.listFiles();
			                     
			                     for (IFSFile file : files) {
			                           System.out.println(file.getName());
			                           if(!file.getName().contains("Adhoc") && file.isFile() && file.getName().contains("Mas_Bill") && file.getName().contains(date) && file.getName().endsWith(".txt")){
			                        	   inputStream = new IFSFileInputStream(file);
			                        	    reader = new BufferedReader(new InputStreamReader(inputStream));
			                        	    IFSFile file1 = new IFSFile(as400, folPath+"/"+file.getName()+".bak");
			                        	    System.out.println("File1 Path :"+file1.getParent());
			                        	    System.out.println("File1 Name :"+file1.getName());
			                        	    file.renameTo(file1);
			                        	    System.out.println("File Name after Rename:"+file.getName()); 
			                           }
			                           
			                     }
			              }

						
					}catch(Exception e){
						System.out.println("[MasterBilling][connAS400ReadFile] Exception -- " + e.toString());
					}
					
					return reader;
				}

	            
	   public static ByteArrayOutputStream genMasterBillingMY(HashMap<Integer, HashMap<String, String>> rowMBDtls) {
			GenericGeneratorMB pdfGenerator = new GenericGeneratorMB();
			ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
	
			try 
			{
					//String path = "D:\\TEST_write\\MasterBilling.xml";
					
				String path = "";
				ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
				path= bundle.getString("FileXmlPath");
				path = path+"MasterBilling.xml";	
				System.out.println("path:"+path);
				
					// Read XML to Java object
			    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
			        Unmarshaller um = jc.createUnmarshaller();
			        Reports rpt = (Reports) um.unmarshal(new File(path));
					
		            pdfGenerator.setReportDefinition(rpt);
		            pdfGenerator.setDbData(rowMBDtls);
		            pdfGenerator.setCurrRowDBData(null);
		            crBaos = pdfGenerator.runReport();
		           
		            return crBaos;
			} 
			catch (JAXBException jex) {
	       	System.out.println("[MasterBilling.java] [genMasterBillingMY] JAXBException --> " + jex.toString());
			} catch (Exception ex) {
	       	ex.printStackTrace();
			}
			return null;
	   }
	   	   
		public static void main(String args[]){
			MasterBilling mb = new MasterBilling();
			mb.run();
		} 
	   

}
