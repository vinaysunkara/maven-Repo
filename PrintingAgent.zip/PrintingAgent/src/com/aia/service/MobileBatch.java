package com.aia.service;

import java.util.HashMap;

import com.aia.common.db.DBCommon;
import com.aia.common.model.ClaimsData;
import com.aia.common.model.NBAgentContact;
import com.aia.common.model.Notification;
import com.aia.common.model.POSServiceRequest;
import com.aia.pdfGenerator.util.CommonFileUtil;

public class MobileBatch {
	private Notification notification;
	private POSServiceRequest serviceRequest;
	private NBAgentContact agentContact;
	private ClaimsData claimsData;
	
	public MobileBatch(Notification notification, POSServiceRequest serviceRequest, NBAgentContact agentContact, 
			ClaimsData claimsData) {
		this.notification = notification;
		this.serviceRequest = serviceRequest;
		this.agentContact = agentContact;
		this.claimsData = claimsData;
	}
	
	public boolean execute() throws InterruptedException, Exception {
		boolean success = false;
		DBCommon db = new DBCommon();
		CommonFileUtil cfu = new CommonFileUtil();
		
		if(!cfu.isBlank(notification)) {
			success = db.updateNotificationRow(notification.getGuid(), "PROCESS", notification.getTryCount(), null);
			
			// process the notification by calling ESB
			ESBService service = new ESBService();
			HashMap<String, String> jsonMap = service.callService(service.getNotificationJsonString(notification), 1);
			
			int tryCount = notification.getTryCount() + 1;
			
			// if got error, increase TryCount and log error
			// if success or TryCount = 3, archive it
			if(service.isESBSuccess(jsonMap)) {
				success = db.updateNotificationRow(notification.getGuid(), "SUCCESS", -1, null);
				success = db.archiveNotificationRow(notification.getGuid());
				
			} else {
				success = db.updateNotificationRow(notification.getGuid(), "FAILED", tryCount, jsonMap.get("errorDescription"));
				
				if(tryCount >= 3)
					success = db.archiveNotificationRow(notification.getGuid());
			}
		}
		
		if(!cfu.isBlank(serviceRequest)) {
			success = db.updateServiceRequestRow(serviceRequest.getPolicyNo(), serviceRequest.getRequestNo(), 
					serviceRequest.getReqType(), "PROCESS", serviceRequest.getTryCount(), null);
			
			// process the service request by calling ESB
			ESBService service = new ESBService();
			HashMap<String, String> jsonMap = service.callService(service.getServiceRequestJsonString(serviceRequest), 2);
			
			int tryCount = serviceRequest.getTryCount() + 1;
			
			if(service.isESBSuccess(jsonMap)) {
				success = db.updateServiceRequestRow(serviceRequest.getPolicyNo(), serviceRequest.getRequestNo(), 
						serviceRequest.getReqType(), "SUCCESS", -1, null);
				success = db.archiveServiceRequestRow(serviceRequest.getPolicyNo(), serviceRequest.getRequestNo(), 
						serviceRequest.getReqType());
				
			} else {
				success = db.updateServiceRequestRow(serviceRequest.getPolicyNo(), serviceRequest.getRequestNo(), 
						serviceRequest.getReqType(), "FAILED", tryCount, jsonMap.get("errorDescription"));
				
				if(tryCount >= 3)
					success = db.archiveServiceRequestRow(serviceRequest.getPolicyNo(), serviceRequest.getRequestNo(), 
							serviceRequest.getReqType());
			}
		}
		
		if(!cfu.isBlank(agentContact)) {
			success = db.updateNBAgentContactRow(agentContact.getGuid(), "PROCESS", agentContact.getTryCount(), null);
			
			// process the NB POLA agent update by calling ESB
			ESBService service = new ESBService();
			HashMap<String, String> jsonMap = service.callService(service.getNBUpdateContactJsonString(agentContact), 3);
			
			int tryCount = agentContact.getTryCount() + 1;
			
			if(service.isESBSuccess(jsonMap)) {
				success = db.updateNBAgentContactRow(agentContact.getGuid(), "SUCCESS", -1, null);
				success = db.archiveNBAgentContactRow(agentContact.getGuid());
				
			} else {
				success = db.updateNBAgentContactRow(agentContact.getGuid(), "FAILED", tryCount, 
						jsonMap.get("errorDescription"));
				
				if(tryCount >= 3) 
					success = db.archiveNBAgentContactRow(agentContact.getGuid());
			}
		}
		
		if(!cfu.isBlank(claimsData)) {
			success = db.updateClaimsDataRow(claimsData.getClaimNo(), claimsData.getOccurrence(), "PROCESS", 
					claimsData.getTryCount(), null);
			
			// process the service request by calling ESB
			ESBService service = new ESBService();
			HashMap<String, String> jsonMap = service.callService(service.getClaimsDataJsonString(claimsData), 4);
			
			int tryCount = claimsData.getTryCount() + 1;
			
			if(service.isESBSuccess(jsonMap)) {
				success = db.updateClaimsDataRow(claimsData.getClaimNo(), claimsData.getOccurrence(), "SUCCESS", -1, null);
				success = db.archiveClaimsDataRow(claimsData.getClaimNo(), claimsData.getOccurrence());
				
			} else {
				success = db.updateClaimsDataRow(claimsData.getClaimNo(), claimsData.getOccurrence(), "FAILED", tryCount, 
						jsonMap.get("errorDescription"));
				
				if(tryCount >= 3)
					success = db.archiveClaimsDataRow(claimsData.getClaimNo(), claimsData.getOccurrence());
			}
		}
		
		return success;
	}

	public Notification getNotification() {
		return notification;
	}
}
