package com.aia.service;

import ho.aia.utility.host.PasswordFile;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import com.aia.pdfGenerator.model.Reports;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericGenerator;
import com.ibm.as400.access.AS400;
import com.ibm.as400.access.IFSFile;
import com.ibm.as400.access.IFSFileInputStream;

/**
 * @author ITT0152
 *
 */
public class CoverLetter extends Thread{
	
	/**
	 * @param args
	 */
	
	private Thread t;
	public CoverLetter() {
		System.out.println("Creating thread CoverLetter.." );
	}
	public void run() {
//		connectWindow();
		HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> ListOfFiles = getCvrLttrdetails();
		int noFiles;
		noFiles = ListOfFiles.size();
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
			
		for (int i=0 ; i< noFiles ; i++){
			HashMap<Integer, HashMap<String, String>> cvrLttrRS = ListOfFiles.get(i);
			ByteArrayOutputStream baos = genCvrLetterFile(cvrLttrRS);
			String billNum = cvrLttrRS.get(0).get("BillNum").substring(11,cvrLttrRS.get(0).get("BillNum").length());
			String date = cvrLttrRS.get(0).get("BillNum").substring(4,10);
			System.out.println(" calling conn to SMB--------->: " + date);

			String path = "";
			ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
			path= bundle.getString("WritePathFile");
			String pathFile = path+"PET." + date+"_"+ billNum +"_" + "CoverLetter.pdf";	
			uploadLocalFile(baos,pathFile,cvrLttrRS);
		}
		System.out.println("CoverLetter Stopped....");
		//}catch(){
		System.out.println("Thread stopped.");
		//}
	}

 	   
	   public static HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> getCvrLttrdetails(){
		   HashMap<Integer, HashMap<String, String>> cvrLttrRS = new HashMap<Integer, HashMap<String, String>>();
		   HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> ListcvrLttrdetails = new HashMap<Integer ,HashMap<Integer, HashMap<String, String>>>();
		   try {
	    	  
			   Connection conn = null;
			   System.out.println("Calling connAS400ReadFile Method");
			   BufferedReader br = connAS400ReadFile();
	    	   
			   if(br == null || br.equals("")){
				   System.out.println("No Cover Letter Flat file ");
			   }else{
				   System.out.println("END connAS400ReadFile Method");
					String sCurrentLine;
					int cuurline = 0,pdfgenCount = -1;
					int runline = 0;
					
					HashMap<String, String> cvrlttrdetails = null;
					
					while ((sCurrentLine = br.readLine()) != null) {
						 System.out.println("sCurrentLine" +sCurrentLine);
						 
						if(cuurline == 0 || sCurrentLine.contains("****")){
							cvrlttrdetails = new HashMap<String, String>();
							cvrLttrRS = new HashMap<Integer, HashMap<String, String>>(); 
							pdfgenCount++;
							runline = 0;
							//cuurline=1;
						}
						
						if(pdfgenCount == 10){
							break;
						}
						
						 String[] data = sCurrentLine.split("\\|");
						 
						for(int i=0; i<data.length; i++){
							
							 /*if(data[0].equalsIgnoreCase("9999")&& runline == 1){
								 break;
							 }*/
							 
							if(sCurrentLine != null && cuurline > 0){
								if(data.length == 3 && runline == 1){
									if(i == 2){
						     			 cvrlttrdetails.put("Date", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
								}
								if(runline == 2){
								if(i == 2){
						     			 cvrlttrdetails.put("Name", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     			 System.out.println(" Cvr ltrr inside data");
						     			 System.out.println(data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
									if(i == 3){
						     			 cvrlttrdetails.put("address1", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
									if(i == 4){
						     			 cvrlttrdetails.put("address2", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
									if(i == 5){
						     			 cvrlttrdetails.put("address3", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
									if(i == 6){
						     			 cvrlttrdetails.put("address4", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
									if(i == 7){
						     			 cvrlttrdetails.put("address5", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
									if(i == 8){
						     			 cvrlttrdetails.put("PersonName", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						     		}
								}
								if(runline == 3){
									if(i == 2){
										cvrlttrdetails.put("MnthYr", data[i] != null && data[i].length()>0 ?data[i].trim(): "");
					     			      }
									}
								if(runline == 4){
									if(i == 2){
										cvrlttrdetails.put("BillNum", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					     			      }
									if(i == 3){
										cvrlttrdetails.put("DateIssued", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					     			      }
									if(i == 4){
										cvrlttrdetails.put("TotGstIncAmt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					     			      }
									if(i == 5){
										cvrlttrdetails.put("Description", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					     			      }
									if(i == 6){
										cvrlttrdetails.put("Remarks", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					     			      }
									  }
							     } 
						     }
						
						cvrLttrRS.put(runline++,cvrlttrdetails);
						cuurline++;
						ListcvrLttrdetails.put(pdfgenCount,cvrLttrRS);
					}
				   
			   }
			  
	       } catch(Exception ex) {
	           System.out.println("[CoverLetter.getCvrLttrdetails] Exception: " + ex.toString());
	           ex.printStackTrace();
	         }
		 //  System.out.println("ListcvrLttrdetails ........."+ListcvrLttrdetails);
	                return ListcvrLttrdetails;  
	       }
	   
	   public static synchronized void uploadLocalFile(ByteArrayOutputStream baos, String pathFile,HashMap<Integer, HashMap<String, String>> cvrLttrRS){
			System.out.println(" calling conn to SMB--------->: ");
			SmbFileOutputStream sfos = null;
	       try {
				ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
				PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONASWIN", "USER", "PASSWD");
	    	   NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", pwdFile.getUserId(), pwdFile.getPassword());
//	    	   NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", "KAPPUSON", "Welcome@1");
	    	        System.out.println("File Path :"+pathFile);
	    	        System.out.println("Auth connect done----->");
	    	        SmbFile smbfile = new SmbFile(pathFile, auth);
	    	        System.out.println("smbfile...:"+smbfile);
	    	     //   String pathnew =  pathFile +"//PET." + "CoverLetter.pdf";
	    	        sfos = new SmbFileOutputStream(smbfile);
	                 
	                  baos.writeTo(sfos);
	                  sfos.close();
	   //     System.out.println(" Uploaded to PFV: " + pathFile);
	       } catch(Exception ex){
	              System.out.println("[CoverLetter.uploadLocalFile] Exception: " + ex.toString());
	              ex.printStackTrace();
	       }
	    }
	   
	   public static ByteArrayOutputStream genCvrLetterFile(HashMap<Integer, HashMap<String, String>> cvrLttrRS){
			GenericGenerator pdfGenerator = new GenericGenerator();
			
			ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
			CommonFileUtil cu = new CommonFileUtil();
	       
			try {
				String path = "";
				ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
				path= bundle.getString("FileXmlPath");
				path = path+"CoverLetter.xml";	
				System.out.println("path:"+path);
								
				// Read XML to Java object
		    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
		
		        Unmarshaller um = jc.createUnmarshaller();
		        Reports rpt = (Reports) um.unmarshal(new File(path));
				
	           pdfGenerator.setReportDefinition(rpt);
	           
	           pdfGenerator.setDbData(cvrLttrRS);
	           pdfGenerator.setCurrRowDBData(null);
	           
	           crBaos = pdfGenerator.runReport();
	           
	           return crBaos;
	       } catch (JAXBException jex) {
	       	System.out.println("[CoverLetter.java] [genCvrLetterFile] JAXBException --> " + jex.toString());
	       } catch (Exception ex) {
	       	ex.printStackTrace();
	       }
			
			return null;
	   }
	   	   
  public static  BufferedReader connAS400ReadFile(){
	  System.out.println(" In connAS400ReadFile");
	  String processFile = "";
	  String totPath = "";
	  String ipAdd = "";
	  String folPath ="";
	  SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
	  Date datee = new Date();
	  String date = sdfDate.format(datee);
	  IFSFileInputStream inputStream = null;
//	  IFSFileInputStream inputStream_ = new IFSFileInputStream(file);
	  BufferedReader reader = null;
		   FileReader fr = null;
			try {
				ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
				PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONAS", "USER", "PASSWD");
				totPath = bundle.getString("FileReadPath");
				ipAdd = totPath.substring(0, totPath.indexOf("/"));
				folPath = totPath.substring(totPath.indexOf("/"));
				System.out.println("IP :"+ipAdd +", Path:"+folPath);
				System.out.println("UserID:"+pwdFile.getUserId());
				System.out.println("Password:"+pwdFile.getPassword());
				System.out.println("DATE:---->"+  date);
				AS400 as400 = new AS400(ipAdd, pwdFile.getUserId(), pwdFile.getPassword());
				System.out.println("<------------------------->");
	              IFSFile path = new IFSFile(as400, folPath);
	              if (path.isDirectory()) {
	            	  System.out.println("In Directory");
	                     IFSFile[] files = path.listFiles();
	                     System.out.println("<------------------------->");
	                     for (IFSFile file : files) {
	                           System.out.println(file.getName());
	                           if(file.isFile() && file.getName().contains("Cover_Letter") && !file.getName().contains("Adhoc") && file.getName().contains(date) && file.getName().endsWith(".txt")){
	                        	   inputStream = new IFSFileInputStream(file);
	                        	    reader = new BufferedReader(new InputStreamReader(inputStream));
	                        	    IFSFile file1 = new IFSFile(as400, folPath+"/"+file.getName()+".bak");
	                        	    System.out.println("File1 Path :"+file1.getParent());
	                        	    System.out.println("File1 Name :"+file1.getName());
	                        	    file.renameTo(file1);
	                        	    System.out.println("File Name after Rename:"+file.getName());
	                        	    System.out.println("<------------------------->");
	                           }
	                           
	                     }
	              }

			}catch(Exception e){
				System.out.println("[CoverLetter][connAS400ReadFile] Exception -- " + e.toString());
			}
			
			return reader;
		} 
		
  
	public void startBatch() {
		System.out.println("Starting thread ");
		
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}
		
	/*public void connectWindow(){

		 String writeFolder = "smb://10.49.197.43/UAT/PETRONAS/OUT/MONTHLY_BILLING/";
			try {	
				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", "KAPPUSON", "Welcome@1");
				System.out.println(" Auth inside cover letter");
               SmbFile depDir = new SmbFile(writeFolder, auth);
               for (SmbFile f : depDir.listFiles())
               {
                   System.out.println(f.getName());
               }
			}catch(Exception e){
				System.out.println("[CoverLetter][connAS400ReadFile] Exception -- " + e.toString());
			}
	}*/
	
	public static void main(String args[]){
		CoverLetter cl = new CoverLetter();
		cl.run();
	}
	}
	   
	   
	   