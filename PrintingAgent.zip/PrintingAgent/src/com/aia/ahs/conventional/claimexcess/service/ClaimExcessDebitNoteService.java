package com.aia.ahs.conventional.claimexcess.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.HashMap;
import org.apache.commons.io.FilenameUtils;


import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class ClaimExcessDebitNoteService extends Thread{
	private Thread t;

	public void run() {
		
		genReport();
	}
	
	public void	genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> ceDebitNoteRSDetails=getCEDebitNoteDetails();
			
		int noFiles=ceDebitNoteRSDetails.size();
		    for(int i=0; i<noFiles;i++){
		    	HashMap<Integer, HashMap<String, Object>> ceDebitNoteRS=ceDebitNoteRSDetails.get(i);
		    	 		
		       HashMap<String, Object> dataSource=new HashMap<String, Object>();
		    	for(int a=0;a<ceDebitNoteRS.size();a++){
		    	        dataSource.putAll(ceDebitNoteRS.get(a));
		    	}
		    	String billmonth=""+dataSource.get("billMonth");
		    	String billperiod=billmonth.replace("/", "");
		    	
		    	String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\";
		    	
		    	String pdfname=dataSource.get("policyNum")+"_"+billperiod+"_"+dataSource.get("billNum")+"_CEDN";
		    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		    	
		    	uploadReport(dataSource,pdfFullOutputPath);
		    	
		    }
		
		}
		public  void uploadReport(HashMap<String, Object> datasource, String pdfFullOutputPath) {
			try {
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\CE\\debitNote\\ClaimExcessDebitNote.jasper";
				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			  String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			   String image= FilenameUtils.normalize(imgpath, true); 
			   datasource.put("image",image);	
			  
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,datasource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getCEDebitNoteDetails(){
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\ce\\debitNote.txt";
		
			BufferedReader br = null;
			FileReader fr = null;
			HashMap<Integer, HashMap<String, Object>> ceDebitNotetRS = new HashMap<Integer, HashMap<String, Object>>();
			HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> ceDebitNotetRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No Claim Excess DebitNote Flat file ");
				} else {
					String sCurrentLine;
					int cuurline = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						
						Boolean add = false;

						HashMap<String, Object> ceDebitNote = new HashMap<String, Object>();

						if (cuurline == 0 || sCurrentLine.contains("****")) {
							ceDebitNote = new HashMap<String, Object>();
							ceDebitNotetRS = new HashMap<Integer, HashMap<String, Object>>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							cuurline = 0;
						}
						String[] data = sCurrentLine.split("\\|");
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1H")) {
								ceDebitNote.put("companyName", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
								ceDebitNote.put("companySurname", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
								ceDebitNote.put("addressLine1", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								ceDebitNote.put("addressLine2", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								ceDebitNote.put("addressLine3", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								ceDebitNote.put("addressLine4", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
								ceDebitNote.put("addressLine5", data[8] != null && data[8].length() > 0 ? data[8].trim(): "");
								ceDebitNote.put("billNum", data[9] != null && data[9].length() > 0 ? data[9].trim(): "");
								ceDebitNote.put("dateOfIssue", data[10] != null && data[10].length() > 0 ? data[10].trim(): "");
								ceDebitNote.put("billMonth", data[11] != null && data[11].length() > 0 ? data[11].trim(): "");
								ceDebitNote.put("paymentDueDate", data[12] != null && data[12].length() > 0 ? data[12].trim(): "");
								ceDebitNote.put("bankAcNo","Citibank Account No. 0111279063 ");
							} 	
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("2H")) {
								ceDebitNote.put("policyHolder", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
								ceDebitNote.put("subsidiary", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
								ceDebitNote.put("policyNum", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								ceDebitNote.put("poNum", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								ceDebitNote.put("amnt", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1T")) {
								ceDebitNote.put("totalAmnt", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
							}
						
						if (data[0].equalsIgnoreCase("0001")) {
							ceDebitNotetRS.put(cuurline, ceDebitNote);
							cuurline++;
							ceDebitNotetRSDetails.put(pdfgencount, ceDebitNotetRS);
							
						}
					}
					
				}

			} catch (Exception e) {
				System.out.println("[ceDebitNoteService.getCEDebitNoteeDetails] Exception: "
						+ e.toString());
				e.printStackTrace();
			}
			return ceDebitNotetRSDetails;
		}
		
		
		
		public void startBatch() {
			System.out.println("Starting thread ");

			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}

		public static void main(String args[]) {
			ClaimExcessDebitNoteService sbs = new ClaimExcessDebitNoteService();
			sbs.startBatch();
			System.out.println("startedd.....");
		}
	
}
