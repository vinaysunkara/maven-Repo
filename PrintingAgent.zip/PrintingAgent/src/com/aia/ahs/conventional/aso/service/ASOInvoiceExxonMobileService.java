package com.aia.ahs.conventional.aso.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.common.claimexcess.invoiceexxonmobil.model.InvoiceExxonMobileTable;
import com.aia.premiumandbilling.common.creditnote.model.CreditTabledata;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

public class ASOInvoiceExxonMobileService extends Thread {

	private Thread t;

	public void run() {
		
		genReport();
	}
	
	public void	genReport(){
		/*HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoCreditNoteRSDetails=getAsoInvoiceExxonMobileDetails();
		HashMap<Integer,List<InvoiceExxonMobileTable>> invoiceExxonMobileTableDetails=  getASoInvoiceExxonMobileTableDetails();
		*/
/*		HashMap<String, Object> dataSource=new HashMap<String, Object>();
		
		dataSource.put("companyName",  "ExxonMobil Sdn Bhd");
		dataSource.put("addressLine1",  "JALAN ABC");
		dataSource.put("addressLine2", "ABC INDUSTRIAL PARK");
		dataSource.put("addressLine3","");
		dataSource.put("addressLine4", "50450 WILAYAH PERSEKUTUAN");
		dataSource.put("addressLine5", "KUALA LUMPUR");
		dataSource.put("printHardCp", "");
		dataSource.put("templetType", "");
		dataSource.put("billNum","P778589");
		dataSource.put("dateOfIssue",  "15/12/2018");
		dataSource.put("billingPeriod", "01/12/2018 - 30/11/2019");
		dataSource.put("paymentDueDate","15/02/2019");
		dataSource.put("policyHolder",  "ExxonMobil Sdn Bhd");
		dataSource.put("subsidiary", "ExxonMobil Sdn Bhd");
		dataSource.put("policyNum", "30000770");
		dataSource.put("policyPeriod", "01/12/2018 - 30/11/2019");
		dataSource.put("poNum","866567");
		
		dataSource.put("totalAmtExSt",  "16,081.58");
		dataSource.put("totalAmtSt", "964.89");
		dataSource.put("totalAmountInclSt",  "17,046.47");
		
		List<InvoiceExxonMobileTable> invoiceExxonMobileTablList= new ArrayList<InvoiceExxonMobileTable>();
		InvoiceExxonMobileTable invoiceExxonMobile=null;
		for(int i=0; i<1;i++){
			 invoiceExxonMobile=new InvoiceExxonMobileTable("GMEX CLAIMS: OCCUPATIONAL HEALTH RELATED EXAMINATIONS","160,815.75","16,081.58","964.89","17,046.47");
			 invoiceExxonMobileTablList.add(invoiceExxonMobile);
		}
		
		for(InvoiceExxonMobileTable list:invoiceExxonMobileTablList){
			System.out.println(list.getDsc()+"    "+list.getAdminFeeExclSt()+"    "+list.getAmntInclSt());
		}
         dataSource.put("invoicExxonMobilTableList", invoiceExxonMobileTablList);
		    	
		  this.uploadReport(dataSource);*/
		    	
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoSummaryBillingStatementExonmobilDetails=getAsoInvoiceExxonMobileDetails();
		
		int noFiles=asoSummaryBillingStatementExonmobilDetails.size();
		    for(int i=0; i<noFiles;i++){
		    	HashMap<Integer, HashMap<String, Object>> asoSummaryBillingStatementExonmobilRS=asoSummaryBillingStatementExonmobilDetails.get(i);
		    	 		
		       HashMap<String, Object> dataSource=new HashMap<String, Object>();
		       for(int a=0;a<asoSummaryBillingStatementExonmobilRS.size();a++){
		    	        dataSource.putAll(asoSummaryBillingStatementExonmobilRS.get(a));
		    	}
		       
		    	String billmonth=""+dataSource.get("billMonth");
		    	String billperiod=billmonth.replace("/", "");
		    	
		    	String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\";
		    	
		    	String pdfname=dataSource.get("policyNum")+"_"+billperiod+"_"+dataSource.get("billNum")+"_ASOSBSEbs";
		    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		    	
		    	uploadReport(dataSource,pdfFullOutputPath);
		    }  
		
		}
		
		
		public  void uploadReport(HashMap<String, Object> dataSource,String pdfFullOutputPath) {
			try {
				//String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\ASO\\";

		    	//String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_ASOIncoiceExxonMobile";
		    	//String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		    	
				
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\ASO\\invoicExxonMobil\\AsoInvoiceExxonMobile.jasper";
				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo", logo);
			   
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		
		
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>  getAsoInvoiceExxonMobileDetails(){
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\SummaryBillingStatementExonmobil.txt";

			BufferedReader br = null;
			FileReader fr = null;
			HashMap<Integer, HashMap<String, Object>> asoSummaryBillingStatementExonmobilRS = new HashMap<Integer, HashMap<String, Object>>();
			HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoSummaryBillingStatementExonmobilRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No asoSummaryBillingStatementExonmobil Flat file ");
				} else {
					String sCurrentLine;
					int cuurline = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						HashMap<String, Object> asoDebitNote = new HashMap<String, Object>();
						if (cuurline == 0 || sCurrentLine.contains("****")) {
							asoDebitNote = new HashMap<String, Object>();
							asoSummaryBillingStatementExonmobilRS = new HashMap<Integer, HashMap<String, Object>>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							cuurline = 0;
						}
						String[] data = sCurrentLine.split("\\|");
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1H")) {
									asoDebitNote.put("companyName", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
									asoDebitNote.put("companySurname", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
									asoDebitNote.put("addressLine1", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
									asoDebitNote.put("addressLine2", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
									asoDebitNote.put("addressLine3", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
									asoDebitNote.put("addressLine4", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
									asoDebitNote.put("addressLine5", data[8] != null && data[8].length() > 0 ? data[8].trim(): "");
									asoDebitNote.put("billNum", data[9] != null && data[9].length() > 0 ? data[9].trim(): "");
									asoDebitNote.put("dateOfIssue", data[10] != null && data[10].length() > 0 ? data[10].trim(): "");
									asoDebitNote.put("billMonth", data[11] != null && data[11].length() > 0 ? data[11].trim(): "");
									asoDebitNote.put("paymentDueDate", data[12] != null && data[12].length() > 0 ? data[12].trim(): "");
									asoDebitNote.put("bankAcNo","Citibank Account No. 0111279063 ");
							} 	
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("2H")) {
									asoDebitNote.put("policyHolder", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
									asoDebitNote.put("subsidiary", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
									asoDebitNote.put("policyNum", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
									asoDebitNote.put("poNum", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
									asoDebitNote.put("amnt", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1T")) {
									asoDebitNote.put("totalAmnt", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
							}
						  if (data[0].equalsIgnoreCase("0001")) {
							      asoDebitNotetRS.put(cuurline, asoDebitNote);
							      cuurline++;
							      asoDebitNotetRSDetails.put(pdfgencount, asoDebitNotetRS);
						}
					}
					
				}
			
			} catch (Exception e) {
				System.out.println("[AsoDebitNoteService.getAsoDebitNoteeDetails] Exception: "
						+ e.toString());
				e.printStackTrace();
			}
			return asoDebitNotetRSDetails;
		}
		public  HashMap<Integer, List<InvoiceExxonMobileTable>> getASoInvoiceExxonMobileTableDetails() {
		 
		
			return null;	
		}
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		ASOInvoiceExxonMobileService ces = new ASOInvoiceExxonMobileService();
		ces.startBatch();
		System.out.println("startedd.....");
	}
}
