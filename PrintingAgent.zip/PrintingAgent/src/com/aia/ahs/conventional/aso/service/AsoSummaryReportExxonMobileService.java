package com.aia.ahs.conventional.aso.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.common.claimexcess.invoiceexxonmobil.model.InvoiceExxonMobileTable;
import com.aia.ahs.common.claimexcess.summaryreportexxonmobileteble.model.SummaryReportExxonmobilTable;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class AsoSummaryReportExxonMobileService extends Thread {

	private Thread t;
    public void run() {
		
		genReport();
	}
	
	public void	genReport(){
		/*HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoCreditNoteRSDetails=getSummaryReportExxonMobilePolicyDetails();
		HashMap<Integer,List<InvoiceExxonMobileTable>> invoiceExxonMobileTableDetails=  getSummaryReportExxonMobileTableDetails();
		*/
		HashMap<String, Object> dataSource=new HashMap<String, Object>();
	
		dataSource.put("policyHolder",  "ExxonMobil Sdn Bhd");
		dataSource.put("billingPeriod", "JUNE 2019");
		dataSource.put("billType", "ASO & CLAIM EXCESS");
		
		
		dataSource.put("totalAmtAsoPaid",  "160,815.75");
		dataSource.put("totalAmtAsoExcess", "");
		dataSource.put("totalGrandTtl",  "160815.75");
		
		
		
		List<SummaryReportExxonmobilTable> summaryReportExxonmobilTableList= new ArrayList<SummaryReportExxonmobilTable>();//getSummaryReportExxonMobileTableDetails()
		 
		    SummaryReportExxonmobilTable	summaryReportExxonmobilTable=new SummaryReportExxonmobilTable("30000770","EXXONMOBIL EXPLORATION AND PRODUCTION MALAYSIA INC","A996607","75,884.10","","75,884.10");
			summaryReportExxonmobilTableList.add(summaryReportExxonmobilTable);
			SummaryReportExxonmobilTable summaryReportExxonmobilTable2=new SummaryReportExxonmobilTable("30000770","EXXONMOBIL BUSINESS SUPPORT CENTRE MALAYSIA SDN. BHD.","A966609","84,971.65","","84,971.65");
			summaryReportExxonmobilTableList.add(summaryReportExxonmobilTable2);
			SummaryReportExxonmobilTable summaryReportExxonmobilTable3=new SummaryReportExxonmobilTable("30000770","EXXONMOBIL CHEMICAL MALAYSIA SDN. BHD.","A966612","","","");
			summaryReportExxonmobilTableList.add(summaryReportExxonmobilTable3);		
			SummaryReportExxonmobilTable summaryReportExxonmobilTable4=new SummaryReportExxonmobilTable("3000773","EXXONMOBIL EXPLORATION AND PRODUCTION MALAYSIA INC","A996607","","","");

			summaryReportExxonmobilTableList.add(summaryReportExxonmobilTable4);
			SummaryReportExxonmobilTable summaryReportExxonmobilTable5=new SummaryReportExxonmobilTable("3000773","EXXONMOBIL EXPLORATION AND PRODUCTION MALAYSIA INC","A966617","","","");
			summaryReportExxonmobilTableList.add(summaryReportExxonmobilTable5);
			SummaryReportExxonmobilTable summaryReportExxonmobilTable6=new SummaryReportExxonmobilTable("3000773","EXXONMOBIL EXPLORATION AND PRODUCTION MALAYSIA INC","A966620","","","");
			summaryReportExxonmobilTableList.add(summaryReportExxonmobilTable6);
			
		/*for(InvoiceExxonMobileTable list:invoiceExxonMobileTablList){
			System.out.println(list.getDsc()+"    "+list.getAdminFeeExclSt()+"    "+list.getAmntInclSt());
		}*/
         dataSource.put("summaryReportExxonmobilTableList", summaryReportExxonmobilTableList);
		    	
		  this.uploadReport(dataSource);
		    	
		    
		
		}
		
		
		public  void uploadReport(HashMap<String, Object> dataSource) {
			try {
String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\ASO\\";

		    	//String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_CESummaryReportExxonmobil";
		    	String pdfname="_AsoSummaryReportExxonMobile";
		    	
		    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		    	
				
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\ASO\\SummaryReportExxonMobile\\AsoSummaryReportExxonMobile.jasper";

				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo", logo);
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>  getSummaryReportExxonMobilePolicyDetails(){
			HashMap<Integer, HashMap<String, Object>> invoiceRS=new HashMap<Integer, HashMap<String, Object>>();
			
			
			return null;
		}
		public  HashMap<Integer, List<SummaryReportExxonmobilTable>> getSummaryReportExxonMobileTableDetails() {
		 
		
			return null;	
		}
	
		public void startBatch() {
			System.out.println("Starting thread ");

			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}

		public static void main(String args[]) {
			AsoSummaryReportExxonMobileService ces = new AsoSummaryReportExxonMobileService();
			ces.startBatch();
			System.out.println("startedd.....");
		}
}
