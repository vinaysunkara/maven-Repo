package com.aia.ahs.conventional.aso.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmm;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmClaimExcessTable;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmMainTable;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmPayeeTable;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmSummaryTable;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class AsoClaimStatementGmmService extends Thread  {
	private Thread t;

	public void run() {
		genReport();
		 
	}
	public void	genReport(){
		HashMap<Integer,ClaimStatementGmm> claimStatementGmmDetails=getClaimStatementGmmDetails();
		HashMap<Integer,List<ClaimStatementGmmMainTable>> claimStatementGmmMainTableDetails=getClaimStatementGmmMainTableDetails();
		HashMap<Integer, List<ClaimStatementGmmClaimExcessTable>> claimStatementGmmClaimExcessTableDetails= getClaimStatementGmmClaimExcessTableDetails();
		HashMap<Integer, List<ClaimStatementGmmPayeeTable>> ClaimStatementGmmPayeeTableDetails=getClaimStatementGmmPayeeTableDetails();
				
		int noFiles=claimStatementGmmDetails.size();
		for(int i=0; i<noFiles;i++){
			List<ClaimStatementGmm> listClaimStatementGmm=new ArrayList<ClaimStatementGmm>();
			
			      ClaimStatementGmm claimStatementGmm=claimStatementGmmDetails.get(i);
			      claimStatementGmm.setClaimStatementGmmMainTable(claimStatementGmmMainTableDetails.get(i));
			      claimStatementGmm.setClaimStatementGmmClaimExcessTableDetails(claimStatementGmmClaimExcessTableDetails.get(i));
			      claimStatementGmm.setClaimStatementGmmPayeeTable(ClaimStatementGmmPayeeTableDetails.get(i));
			      
			      
			      listClaimStatementGmm.add(claimStatementGmm);
			String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\";
	    	
	    	String pdfname="ClaimStatement";
	    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
	    	
	    	uploadReport(listClaimStatementGmm,pdfFullOutputPath);
	    	
		   }	
	}
		
		
	
	public  void uploadReport(List<ClaimStatementGmm> listClaimStatementGmm, String pdfFullOutputPath) {
		try {
		    JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(listClaimStatementGmm);
			String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\ASO\\claimStatementGmm\\AsoClaimStatementGmm.jasper";
			// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
			FileInputStream inputStream = new FileInputStream(jrFullReadpath);
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
		   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
		   String image= FilenameUtils.normalize(imgpath, true); 
		   HashMap<String, Object> param=new HashMap<String, Object>();
		   param.put("image",image);	
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,param, dataSource);
			
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println("PDF Generated..."+pdfFullOutputPath);
		
			outputStream.close();
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} 
	}
	
	public HashMap<Integer,ClaimStatementGmm> getClaimStatementGmmDetails(){
		HashMap<Integer,ClaimStatementGmm> claimStatementGmmDetails=new HashMap<Integer,ClaimStatementGmm>();
		ClaimStatementGmm claimStatementGmm=new ClaimStatementGmm();
		claimStatementGmm.setClaimNum("11427597-01");
		claimStatementGmm.setAdmissionOrDischarge("24/01/2019 � 27/01/2019");
		claimStatementGmm.setPaymentAuth("16/04/2019"); 
		
		claimStatementGmm.setMedicalProvider("PENANG ADVENTIST HOSPITAL");
		claimStatementGmm.setMedicalProviderInvoiceNo("MH19029700/64775091C");
		
		//maintable subtotall
		claimStatementGmm.setSubMajorMedicalAmnt("12,086.11");
		claimStatementGmm.setSubEligibleAmnt("21,208.61");
		claimStatementGmm.setSubIncurredAmnt("21,208.61");
		claimStatementGmm.setSubInEligibleAmnt("0.00");
		
		// summary table 
		claimStatementGmm.setSummary_IneligibleAmnt("0.00");
		claimStatementGmm.setSummary_DeductibleAmnt("0.00");
		claimStatementGmm.setSummary_co_InsurenceAmnt("1,208.61");
		claimStatementGmm.setSummary_TtlInEligibleAmnt("1,208.61");
		claimStatementGmm.setSummary_LMGHDCashAllowancePayableClaimant("0.00");
		claimStatementGmm.setSummary_LessMemberDeposit("1,208.61");
		claimStatementGmm.setSummary_AmntDue("0.00");
		
		claimStatementGmmDetails.put(0,claimStatementGmm);
		return claimStatementGmmDetails;
	}
	
	public HashMap<Integer,List<ClaimStatementGmmMainTable>> getClaimStatementGmmMainTableDetails(){
		HashMap<Integer,List<ClaimStatementGmmMainTable>> claimStatementGmmMainTableDetails=new HashMap<Integer,List<ClaimStatementGmmMainTable>>();
		List<ClaimStatementGmmMainTable>  listClaimStatementGmmMainTable=new ArrayList<ClaimStatementGmmMainTable>();
		ClaimStatementGmmMainTable claimStatementGmmMainTable=null;
		
		for(int i=0; i<=5;i++){
			claimStatementGmmMainTable=new ClaimStatementGmmMainTable();
			claimStatementGmmMainTable.setDsrc("Hospital Room & Board � Normal Room & Board");
			claimStatementGmmMainTable.setNoOfDays("4.00");
			claimStatementGmmMainTable.setEblAmnt("250.00");
			claimStatementGmmMainTable.setEblMaximumLimit("per day (Max. 180 days per disability)");
			claimStatementGmmMainTable.setMajorMedicalAmnt("12,086.11");
			claimStatementGmmMainTable.setIncurredAmnt("315.00");
			claimStatementGmmMainTable.setEligibleAmnt("315.00");
			claimStatementGmmMainTable.setInEligibleAmnt("0.00");
			listClaimStatementGmmMainTable.add(claimStatementGmmMainTable);
			}
		
		claimStatementGmmMainTableDetails.put(0, listClaimStatementGmmMainTable);
		return claimStatementGmmMainTableDetails;
	}

	public HashMap<Integer, List<ClaimStatementGmmClaimExcessTable>> getClaimStatementGmmClaimExcessTableDetails() {
		
		HashMap<Integer, List<ClaimStatementGmmClaimExcessTable>> claimStatementGmmClaimExcessTableDetails=new HashMap<Integer, List<ClaimStatementGmmClaimExcessTable>>();
		List<ClaimStatementGmmClaimExcessTable> listClaimStatementGmmClaimExcessTable=new ArrayList<ClaimStatementGmmClaimExcessTable>();
		ClaimStatementGmmClaimExcessTable claimStatementGmmClaimExcessTable=new ClaimStatementGmmClaimExcessTable();
		claimStatementGmmClaimExcessTable.setAmnt("Nil");
		claimStatementGmmClaimExcessTable.setDsrc("Nil");
		
		listClaimStatementGmmClaimExcessTable.add(claimStatementGmmClaimExcessTable);
		claimStatementGmmClaimExcessTableDetails.put(0, listClaimStatementGmmClaimExcessTable);
		return claimStatementGmmClaimExcessTableDetails;
	}

	public HashMap<Integer, List<ClaimStatementGmmPayeeTable>> getClaimStatementGmmPayeeTableDetails() {
		HashMap<Integer, List<ClaimStatementGmmPayeeTable>> ClaimStatementGmmPayeeTableDetails=new HashMap<Integer, List<ClaimStatementGmmPayeeTable>>();
		List<ClaimStatementGmmPayeeTable> listclaimStatementGmmPayeeTable=new ArrayList<ClaimStatementGmmPayeeTable>();
		ClaimStatementGmmPayeeTable claimStatementGmmPayeeTable=new ClaimStatementGmmPayeeTable();
		
		claimStatementGmmPayeeTable.setAmnt("20,000.00");
		
		listclaimStatementGmmPayeeTable.add(claimStatementGmmPayeeTable);
		ClaimStatementGmmPayeeTableDetails.put(0, listclaimStatementGmmPayeeTable);
		return ClaimStatementGmmPayeeTableDetails;
	}

	
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		AsoClaimStatementGmmService csg = new AsoClaimStatementGmmService();
		csg.startBatch();
		System.out.println("startedd.....");
	}
	
}
