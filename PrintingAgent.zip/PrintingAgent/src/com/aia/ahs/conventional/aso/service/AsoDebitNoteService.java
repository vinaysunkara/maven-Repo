package com.aia.ahs.conventional.aso.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.HashMap;
import org.apache.commons.io.FilenameUtils;


import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class AsoDebitNoteService extends Thread{
	private Thread t;

	public void run() {
		
		genReport();
	}
	
	public void	genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoDebitNoteRSDetails=getAsoDebitNoteDetails();
			
		int noFiles=asoDebitNoteRSDetails.size();
		    for(int i=0; i<noFiles;i++){
		    	HashMap<Integer, HashMap<String, Object>> asoDebitNoteRS=asoDebitNoteRSDetails.get(i);
		    	 		
		       HashMap<String, Object> dataSource=new HashMap<String, Object>();
		       for(int a=0;a<asoDebitNoteRS.size();a++){
		    	        dataSource.putAll(asoDebitNoteRS.get(a));
		    	}
		       
		    	String billmonth=""+dataSource.get("billMonth");
		    	String billperiod=billmonth.replace("/", "");
		    	
		    	String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\";
		    	
		    	String pdfname=dataSource.get("policyNum")+"_"+billperiod+"_"+dataSource.get("billNum")+"_ASODN";
		    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		    	
		    	uploadReport(dataSource,pdfFullOutputPath);
		    }
		
		}
		public  void uploadReport(HashMap<String, Object> datasource, String pdfFullOutputPath) {
			try {
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\ASO\\debitNote\\AsoDebitNote.jasper";
				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			  String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			   String image= FilenameUtils.normalize(imgpath, true); 
			   datasource.put("image",image);	
			  
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,datasource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getAsoDebitNoteDetails(){
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\debitNote.txt";

			BufferedReader br = null;
			FileReader fr = null;
			HashMap<Integer, HashMap<String, Object>> asoDebitNotetRS = new HashMap<Integer, HashMap<String, Object>>();
			HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoDebitNotetRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No AsoDebitNote Flat file ");
				} else {
					String sCurrentLine;
					int cuurline = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						HashMap<String, Object> asoDebitNote = new HashMap<String, Object>();
						if (cuurline == 0 || sCurrentLine.contains("****")) {
							asoDebitNote = new HashMap<String, Object>();
							asoDebitNotetRS = new HashMap<Integer, HashMap<String, Object>>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							cuurline = 0;
						}
						String[] data = sCurrentLine.split("\\|");
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1H")) {
									asoDebitNote.put("companyName", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
									asoDebitNote.put("companySurname", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
									asoDebitNote.put("addressLine1", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
									asoDebitNote.put("addressLine2", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
									asoDebitNote.put("addressLine3", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
									asoDebitNote.put("addressLine4", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
									asoDebitNote.put("addressLine5", data[8] != null && data[8].length() > 0 ? data[8].trim(): "");
									asoDebitNote.put("billNum", data[9] != null && data[9].length() > 0 ? data[9].trim(): "");
									asoDebitNote.put("dateOfIssue", data[10] != null && data[10].length() > 0 ? data[10].trim(): "");
									asoDebitNote.put("billMonth", data[11] != null && data[11].length() > 0 ? data[11].trim(): "");
									asoDebitNote.put("paymentDueDate", data[12] != null && data[12].length() > 0 ? data[12].trim(): "");
									asoDebitNote.put("bankAcNo","Citibank Account No. 0111279063 ");
							} 	
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("2H")) {
									asoDebitNote.put("policyHolder", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
									asoDebitNote.put("subsidiary", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
									asoDebitNote.put("policyNum", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
									asoDebitNote.put("poNum", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
									asoDebitNote.put("amnt", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1T")) {
									asoDebitNote.put("totalAmnt", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
							}
						  if (data[0].equalsIgnoreCase("0001")) {
							      asoDebitNotetRS.put(cuurline, asoDebitNote);
							      cuurline++;
							      asoDebitNotetRSDetails.put(pdfgencount, asoDebitNotetRS);
						}
					}
					
				}
			
			} catch (Exception e) {
				System.out.println("[AsoDebitNoteService.getAsoDebitNoteeDetails] Exception: "
						+ e.toString());
				e.printStackTrace();
			}
			return asoDebitNotetRSDetails;
		}
		
		
		
		public void startBatch() {
			System.out.println("Starting thread ");

			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}

		public static void main(String args[]) {
			AsoDebitNoteService sbs = new AsoDebitNoteService();
			sbs.startBatch();
			System.out.println("startedd.....");
		}
	
}
