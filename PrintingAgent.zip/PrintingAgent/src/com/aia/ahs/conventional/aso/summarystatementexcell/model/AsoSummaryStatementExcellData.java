package com.aia.ahs.conventional.aso.summarystatementexcell.model;

import java.util.Date;

public class AsoSummaryStatementExcellData {
private String policyNum;;
private String companyName;
private String billMonth;
private String billNum;
private String claimNum;
private String empName;
private String empNricPassportNum;
private String empId;
private String claimantName;
private String membershipNum;
private String relationship;
private String planNum;
private String planDsrc;
private String prodCode;
private String prodDsrc;
private String branch;
private String costCenter;
private String visitDate;
private String hospitalSpecialist;
private String claimType;
private String asoPaid;
private String asoExcess;
private String gst;
private String ttlAmnt;
private String reson1;
private String excessAmnt1;
private String reson2;
private String excessAmnt2;
private String reson3;
private String excessAmnt3;
private String reson4;
private String excessAmnt4;


public String getPolicyNum() {
	return policyNum;
}
public void setPolicyNum(String policyNum) {
	this.policyNum = policyNum;
}
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}
public String getBillMonth() {
	return billMonth;
}
public void setBillMonth(String billMonth) {
	this.billMonth = billMonth;
}
public String getBillNum() {
	return billNum;
}
public void setBillNum(String billNum) {
	this.billNum = billNum;
}
public String getClaimNum() {
	return claimNum;
}
public void setClaimNum(String claimNum) {
	this.claimNum = claimNum;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getEmpNricPassportNum() {
	return empNricPassportNum;
}
public void setEmpNricPassportNum(String empNricPassportNum) {
	this.empNricPassportNum = empNricPassportNum;
}
public String getEmpId() {
	return empId;
}
public void setEmpId(String empId) {
	this.empId = empId;
}
public String getClaimantName() {
	return claimantName;
}
public void setClaimantName(String claimantName) {
	this.claimantName = claimantName;
}
public String getMembershipNum() {
	return membershipNum;
}
public void setMembershipNum(String membershipNum) {
	this.membershipNum = membershipNum;
}
public String getRelationship() {
	return relationship;
}
public void setRelationship(String relationship) {
	this.relationship = relationship;
}
public String getPlanNum() {
	return planNum;
}
public void setPlanNum(String planNum) {
	this.planNum = planNum;
}
public String getPlanDsrc() {
	return planDsrc;
}
public void setPlanDsrc(String planDsrc) {
	this.planDsrc = planDsrc;
}
public String getProdCode() {
	return prodCode;
}
public void setProdCode(String prodCode) {
	this.prodCode = prodCode;
}
public String getProdDsrc() {
	return prodDsrc;
}
public void setProdDsrc(String prodDsrc) {
	this.prodDsrc = prodDsrc;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getCostCenter() {
	return costCenter;
}
public void setCostCenter(String costCenter) {
	this.costCenter = costCenter;
}
public String getVisitDate() {
	return visitDate;
}
public void setVisitDate(String visitDate) {
	this.visitDate = visitDate;
}
public String getHospitalSpecialist() {
	return hospitalSpecialist;
}
public void setHospitalSpecialist(String hospitalSpecialist) {
	this.hospitalSpecialist = hospitalSpecialist;
}
public String getClaimType() {
	return claimType;
}
public void setClaimType(String claimType) {
	this.claimType = claimType;
}
public String getAsoPaid() {
	return asoPaid;
}
public void setAsoPaid(String asoPaid) {
	this.asoPaid = asoPaid;
}
public String getAsoExcess() {
	return asoExcess;
}
public void setAsoExcess(String asoExcess) {
	this.asoExcess = asoExcess;
}
public String getGst() {
	return gst;
}
public void setGst(String gst) {
	this.gst = gst;
}
public String getTtlAmnt() {
	return ttlAmnt;
}
public void setTtlAmnt(String ttlAmnt) {
	this.ttlAmnt = ttlAmnt;
}
public String getReson1() {
	return reson1;
}
public void setReson1(String reson1) {
	this.reson1 = reson1;
}
public String getExcessAmnt1() {
	return excessAmnt1;
}
public void setExcessAmnt1(String excessAmnt1) {
	this.excessAmnt1 = excessAmnt1;
}
public String getReson2() {
	return reson2;
}
public void setReson2(String reson2) {
	this.reson2 = reson2;
}
public String getExcessAmnt2() {
	return excessAmnt2;
}
public void setExcessAmnt2(String excessAmnt2) {
	this.excessAmnt2 = excessAmnt2;
}
public String getReson3() {
	return reson3;
}
public void setReson3(String reson3) {
	this.reson3 = reson3;
}
public String getExcessAmnt3() {
	return excessAmnt3;
}
public void setExcessAmnt3(String excessAmnt3) {
	this.excessAmnt3 = excessAmnt3;
}
public String getReson4() {
	return reson4;
}
public void setReson4(String reson4) {
	this.reson4 = reson4;
}
public String getExcessAmnt4() {
	return excessAmnt4;
}
public void setExcessAmnt4(String excessAmnt4) {
	this.excessAmnt4 = excessAmnt4;
}


}
