package com.aia.ahs.conventional.aso.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.common.aso.claimstatement_no_gmm.model.ClaimStatementNo_Gmm;
import com.aia.ahs.common.aso.claimstatement_no_gmm.model.ClaimStatementNo_GmmClaimExcessTable;
import com.aia.ahs.common.aso.claimstatement_no_gmm.model.ClaimStatementNo_GmmMainTable;
import com.aia.ahs.common.aso.claimstatement_no_gmm.model.ClaimStatementNo_GmmPayeeTable;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmm;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmClaimExcessTable;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmMainTable;
import com.aia.ahs.common.aso.claimstatementgmm.model.ClaimStatementGmmPayeeTable;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class AsoClaimStatementNo_GmmService extends Thread  {
	private Thread t;

	public void run() {
		genReport();
		 
	}
	public void	genReport(){
		HashMap<Integer,ClaimStatementNo_Gmm> claimStatementGmmDetails=getClaimStatementNo_GmmDetails();
		HashMap<Integer,List<ClaimStatementNo_GmmMainTable>> claimStatementGmmMainTableDetails=getClaimStatementNo_GmmMainTableDetails();
		HashMap<Integer, List<ClaimStatementNo_GmmClaimExcessTable>> claimStatementGmmClaimExcessTableDetails= getClaimStatementNo_GmmClaimExcessTableDetails();
		HashMap<Integer, List<ClaimStatementNo_GmmPayeeTable>> ClaimStatementGmmPayeeTableDetails=getClaimStatementNo_GmmPayeeTableDetails();
				
		int noFiles=claimStatementGmmDetails.size();
		for(int i=0; i<noFiles;i++){
			List<ClaimStatementNo_Gmm> listClaimStatementGmm=new ArrayList<ClaimStatementNo_Gmm>();
			
			      ClaimStatementNo_Gmm claimStatementGmm=claimStatementGmmDetails.get(i);
			      claimStatementGmm.setClaimStatementNo_GmmMainTable(claimStatementGmmMainTableDetails.get(i));
			      claimStatementGmm.setClaimStatementNo_GmmClaimExcessTableDetails(claimStatementGmmClaimExcessTableDetails.get(i));
			      claimStatementGmm.setClaimStatementNo_GmmPayeeTable(ClaimStatementGmmPayeeTableDetails.get(i));
			      
			      
			      listClaimStatementGmm.add(claimStatementGmm);
			String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\";
	    	
	    	String pdfname="ClaimStatementNo_Gmm";
	    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
	    	
	    	uploadReport(listClaimStatementGmm,pdfFullOutputPath);
	    	
		   }	
	}
		
		
	
	public  void uploadReport(List<ClaimStatementNo_Gmm> listClaimStatementNo_Gmm, String pdfFullOutputPath) {
		try {
		    JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(listClaimStatementNo_Gmm);
		  	
		    String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\ASO\\claimStatement_NoGmm\\AsoClaimStatementNo_Gmm.jasper";
			

			
			// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
			FileInputStream inputStream = new FileInputStream(jrFullReadpath);
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
		   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
		   String logo= FilenameUtils.normalize(imgpath, true); 
		   HashMap<String, Object> param=new HashMap<String, Object>();
		   param.put("logo",logo);	
		  
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,param, dataSource);
			
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println("PDF Generated..."+pdfFullOutputPath);
		    outputStream.close();
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} 
	}
	
	
	public HashMap<Integer, ClaimStatementNo_Gmm> getClaimStatementNo_GmmDetails() {
		
		HashMap<Integer,ClaimStatementNo_Gmm> claimStatementNo_GmmDetails=new HashMap<Integer,ClaimStatementNo_Gmm>();
		ClaimStatementNo_Gmm claimStatementNo_Gmm=new ClaimStatementNo_Gmm();
		claimStatementNo_Gmm.setClaimNum("11427597-01");
		claimStatementNo_Gmm.setAdmissionOrDischarge("24/01/2019 � 27/01/2019");
		claimStatementNo_Gmm.setPaymentAuth("16/04/2019"); 
		
		claimStatementNo_Gmm.setMedicalProvider("PENANG ADVENTIST HOSPITAL");
		claimStatementNo_Gmm.setMedicalProviderInvoiceNo("MH19029700/64775091C");
		
		//subTotal of main table
		claimStatementNo_Gmm.setSubEligibleAmnt("21,208.61");
		claimStatementNo_Gmm.setSubIncurredAmnt("21,208.61");
		claimStatementNo_Gmm.setSubInEligibleAmnt("0.00");
		
		// summary table 
		claimStatementNo_Gmm.setSummary_IneligibleAmnt("0.00");
		claimStatementNo_Gmm.setSummary_DeductibleAmnt("0.00");
		claimStatementNo_Gmm.setSummary_co_InsurenceAmnt("1,208.61");
		claimStatementNo_Gmm.setSummary_TtlInEligibleAmnt("1,208.61");
		claimStatementNo_Gmm.setSummary_LMGHDCashAllowancePayableClaimant("0.00");
		claimStatementNo_Gmm.setSummary_LessMemberDeposit("1,208.61");
		claimStatementNo_Gmm.setSummary_AmntDue("0.00");
		
		
		claimStatementNo_GmmDetails.put(0, claimStatementNo_Gmm);
		return claimStatementNo_GmmDetails;
	}
	public HashMap<Integer, List<ClaimStatementNo_GmmMainTable>> getClaimStatementNo_GmmMainTableDetails() {
		HashMap<Integer,List<ClaimStatementNo_GmmMainTable>> claimStatementNo_GmmMainTableDetails=new HashMap<Integer,List<ClaimStatementNo_GmmMainTable>>();
		List<ClaimStatementNo_GmmMainTable>  listClaimStatementGmmMainTable=new ArrayList<ClaimStatementNo_GmmMainTable>();
		
		ClaimStatementNo_GmmMainTable claimStatementNo_GmmMainTable=null;
		
		for(int i=0; i<=4;i++){
			claimStatementNo_GmmMainTable=new ClaimStatementNo_GmmMainTable();
			claimStatementNo_GmmMainTable.setDsrc("Hospital Room & Board � Normal Room & Board");
			claimStatementNo_GmmMainTable.setNoOfDays("4.00");
			claimStatementNo_GmmMainTable.setEblAmnt("250.00");
			claimStatementNo_GmmMainTable.setEblMaximumLimit("per day (Max. 180 days per disability)");
			claimStatementNo_GmmMainTable.setIncurredAmnt("315.00");
			claimStatementNo_GmmMainTable.setEligibleAmnt("315.00");
			claimStatementNo_GmmMainTable.setInEligibleAmnt("0.00");
			listClaimStatementGmmMainTable.add(claimStatementNo_GmmMainTable);
			}
		
		claimStatementNo_GmmMainTableDetails.put(0, listClaimStatementGmmMainTable);
		return claimStatementNo_GmmMainTableDetails;
	}
	public HashMap<Integer, List<ClaimStatementNo_GmmPayeeTable>> getClaimStatementNo_GmmPayeeTableDetails() {
		HashMap<Integer, List<ClaimStatementNo_GmmPayeeTable>> claimStatementNo_GmmPayeeTableDetails=new HashMap<Integer, List<ClaimStatementNo_GmmPayeeTable>>();
		List<ClaimStatementNo_GmmPayeeTable> listclaimStatementNo_GmmPayeeTable=new ArrayList<ClaimStatementNo_GmmPayeeTable>();
		ClaimStatementNo_GmmPayeeTable claimStatementNo_GmmPayeeTable=new ClaimStatementNo_GmmPayeeTable();
		
		claimStatementNo_GmmPayeeTable.setAmnt("20,000.00");
		
		listclaimStatementNo_GmmPayeeTable.add(claimStatementNo_GmmPayeeTable);
		claimStatementNo_GmmPayeeTableDetails.put(0, listclaimStatementNo_GmmPayeeTable);
		return claimStatementNo_GmmPayeeTableDetails;
	}
	
	public HashMap<Integer, List<ClaimStatementNo_GmmClaimExcessTable>> getClaimStatementNo_GmmClaimExcessTableDetails() {
		HashMap<Integer, List<ClaimStatementNo_GmmClaimExcessTable>> claimStatementNo_GmmClaimExcessTableDetails=new HashMap<Integer, List<ClaimStatementNo_GmmClaimExcessTable>>();
		List<ClaimStatementNo_GmmClaimExcessTable> listClaimStatementNo_GmmClaimExcessTable=new ArrayList<ClaimStatementNo_GmmClaimExcessTable>();
		ClaimStatementNo_GmmClaimExcessTable claimStatementNo_GmmClaimExcessTable=new ClaimStatementNo_GmmClaimExcessTable();
		claimStatementNo_GmmClaimExcessTable.setAmnt("Nil");
		claimStatementNo_GmmClaimExcessTable.setDsrc("Nil");
		
		listClaimStatementNo_GmmClaimExcessTable.add(claimStatementNo_GmmClaimExcessTable);
		claimStatementNo_GmmClaimExcessTableDetails.put(0, listClaimStatementNo_GmmClaimExcessTable);
		return claimStatementNo_GmmClaimExcessTableDetails;
		
	}
	
	

	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		AsoClaimStatementNo_GmmService csg = new AsoClaimStatementNo_GmmService();
		csg.startBatch();
		System.out.println("startedd.....");
	}
}
