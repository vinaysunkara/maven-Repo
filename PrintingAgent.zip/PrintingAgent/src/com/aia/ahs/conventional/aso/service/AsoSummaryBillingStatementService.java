package com.aia.ahs.conventional.aso.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.common.aso.summarystatement.model.AsoSummaryBillingStatementTableData;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class AsoSummaryBillingStatementService extends Thread{
	private Thread t;

	public void run() {
		
		genReport(); 
	}
	
	public void	genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoSummaryStatementRSDetails=getAsoSummaryStatementDetails();
		HashMap<Integer, List<AsoSummaryBillingStatementTableData>> asoSummaryStatementListDetails=getAsoSummaryStatementTableData();
		int noFiles=asoSummaryStatementRSDetails.size();
		    for(int i=0; i<noFiles;i++){
		    	HashMap<Integer, HashMap<String, Object>> asoSummaryStatementRS=asoSummaryStatementRSDetails.get(i);
		    	List<AsoSummaryBillingStatementTableData> asoSummaryStatementList=asoSummaryStatementListDetails.get(i);
		       HashMap<String, Object> dataSource=new HashMap<String, Object>();
		    	for(int a=0;a<asoSummaryStatementRS.size();a++){
		    	        dataSource.putAll(asoSummaryStatementRS.get(a));
		    	}
		    	
		    	dataSource.put("asoSummaryStatementList", asoSummaryStatementList);
		    	
		    	String billmonth=""+dataSource.get("billMonth");
		    	String billperiod=billmonth.replace("/", "");
		    	
		    	String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\conventional\\";
		    	
		    	String pdfname=dataSource.get("policyNum")+"_"+billperiod+"_"+dataSource.get("billNum")+"_ASOSummaryStmt";
		    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		    	
		    	uploadReport(dataSource,pdfFullOutputPath);
		    	
		    }
		
		}
		
		
		public  void uploadReport(HashMap<String, Object> datasource, String pdfFullOutputPath) {
			try {
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\conventional\\ASO\\summaryBillingStatement\\AsoSummaryStatement.jasper";
				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			  String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			   String image= FilenameUtils.normalize(imgpath, true); 
			   datasource.put("image",image);	
			  
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,datasource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getAsoSummaryStatementDetails(){
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\AHS_Conv_ASO_SummaryStatementPDF.txt";

			BufferedReader br = null;
			FileReader fr = null;
			HashMap<Integer, HashMap<String, Object>> asoSummaryStatementtRS = new HashMap<Integer, HashMap<String, Object>>();
			HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoSummaryStatementtRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No AsoSummaryStatement Flat file ");
				} else {
					String sCurrentLine;
					int cuurline = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						
						Boolean add = false;

						HashMap<String, Object> asoSummaryStatement = new HashMap<String, Object>();

						if (cuurline == 0 || sCurrentLine.contains("****")) {
							asoSummaryStatement = new HashMap<String, Object>();
							asoSummaryStatementtRS = new HashMap<Integer, HashMap<String, Object>>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							cuurline = 0;
						}
						String[] data = sCurrentLine.split("\\|");
						for (int i = 0; i < data.length; i++) {

							if (data[0].equalsIgnoreCase("0001")||data[0].equalsIgnoreCase("0004")) {
								add = true;
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1H")) {
								if(i==2){
									asoSummaryStatement.put("policyHolder", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==3){
									asoSummaryStatement.put("subsidiary", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==4){
									asoSummaryStatement.put("policyNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==5){
									asoSummaryStatement.put("billNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==6){
									asoSummaryStatement.put("dateOfIssue", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==7){
									asoSummaryStatement.put("billMonth", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								
							} 		
							if (data[0].equalsIgnoreCase("0004")) {
								if(i==2){
									asoSummaryStatement.put("grandTttlAmntAsoPaid", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==3){
									asoSummaryStatement.put("grandTttlAmntAsoExcess", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==4){
									asoSummaryStatement.put("grandTttlAmntGst", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==5){
									asoSummaryStatement.put("grandTttlAndTtlAmnt", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								
							} 
							
						}
						if (add) {
							asoSummaryStatementtRS.put(cuurline, asoSummaryStatement);
							cuurline++;
							asoSummaryStatementtRSDetails.put(pdfgencount, asoSummaryStatementtRS);
							
						}
					}
					
				}

			} catch (Exception e) {
				System.out.println("[AsoSummaryBillingStatementService.getAsoSummaryStatementeDetails] Exception: "
						+ e.toString());
				e.printStackTrace();
			}
			return asoSummaryStatementtRSDetails;
		}
		
	public static HashMap<Integer, List<AsoSummaryBillingStatementTableData>> getAsoSummaryStatementTableData() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\AHS_Conv_ASO_SummaryStatementPDF.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<AsoSummaryBillingStatementTableData> asoSummaryStatementList = new ArrayList<AsoSummaryBillingStatementTableData>();
		HashMap<Integer, List<AsoSummaryBillingStatementTableData>> asoSummaryStatementListDetails = new HashMap<Integer, List<AsoSummaryBillingStatementTableData>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No AsoSummaryStatement Flat file ");
			} else {
				String sCurrentLine;
				int currentLint = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					AsoSummaryBillingStatementTableData asoSummaryStatement = new AsoSummaryBillingStatementTableData();

					boolean add = false;
					if (currentLint == 0 || sCurrentLine.contains("****")) {
						asoSummaryStatement = new AsoSummaryBillingStatementTableData();
						asoSummaryStatementList = new ArrayList<AsoSummaryBillingStatementTableData>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						currentLint = 0;
					}

					String data[] = sCurrentLine.split("\\|");
					for (int i = 0; i < data.length; i++) {
						if (data[0].equalsIgnoreCase("0001")) {
							add = true;
						
						}
						if (data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")) {
							if (i == 2) {
								asoSummaryStatement.setClaimNum(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
                            }
							if (i == 3) { 
								asoSummaryStatement.setEmpName(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");

							}
							if (i == 4) {
								asoSummaryStatement.setEmpNricPassportNum(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 5) {
								asoSummaryStatement.setClaimantName(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 6) {
								asoSummaryStatement.setRelationship(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 7) {
								asoSummaryStatement.setVisitDate(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 8) {
								asoSummaryStatement.setAsoPaid(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 9) {
								asoSummaryStatement.setAsoExcess(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 10) {
								asoSummaryStatement.setGst(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}
							if (i == 11) {
								asoSummaryStatement.setTtlAmnt(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
							}

						}

					}
					if (add) {
						if (data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")) {
							asoSummaryStatementList.add(asoSummaryStatement);
						}
					}
					currentLint++;
					asoSummaryStatementListDetails.put(pdfgencount, asoSummaryStatementList);
				}

			}
                     
		} catch (Exception e) {
			System.out.println(
					"[SummaryBillingStatementService.getAsoSummaryStatementTableData] Exception: " + e.toString());
			e.printStackTrace();
		}
		return asoSummaryStatementListDetails;
	}
		
		public void startBatch() {
			System.out.println("Starting thread ");

			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}

		public static void main(String args[]) {
			AsoSummaryBillingStatementService sbs = new AsoSummaryBillingStatementService();
			sbs.startBatch();
			System.out.println("startedd.....");
		}
	
}
