package com.aia.ahs.common.claimexcess.summarystatement.model;

public class ClaimExcessAsoSummaryStatementTableData {
	private String claimNum;
	private String empName;
	private String empNricPassportNum;
	private String claimantName;
	private String relationship;
	private String visitDate;
	private String claimExcess;
	public String getClaimNum() {
		return claimNum;
	}
	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpNricPassportNum() {
		return empNricPassportNum;
	}
	public void setEmpNricPassportNum(String empNricPassportNum) {
		this.empNricPassportNum = empNricPassportNum;
	}
	public String getClaimantName() {
		return claimantName;
	}
	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}
	public String getClaimExcess() {
		return claimExcess;
	}
	public void setClaimExcess(String claimExcess) {
		this.claimExcess = claimExcess;
	}
	
	
}
