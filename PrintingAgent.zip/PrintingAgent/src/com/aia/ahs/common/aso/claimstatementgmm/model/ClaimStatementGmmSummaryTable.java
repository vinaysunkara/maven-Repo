package com.aia.ahs.common.aso.claimstatementgmm.model;

public class ClaimStatementGmmSummaryTable {

	
	
}
