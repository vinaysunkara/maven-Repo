package com.aia.ahs.common.aso.claimstatementgmm.model;

public class ClaimStatementGmmPayeeTable {
	private String payee;
	private String paymentreferenceNo;
	private String date;
	private String amnt;
	
	public String getPayee() {
		return payee;
	}
	public void setPayee(String payee) {
		this.payee = payee;
	}
	public String getPaymentreferenceNo() {
		return paymentreferenceNo;
	}
	public void setPaymentreferenceNo(String paymentreferenceNo) {
		this.paymentreferenceNo = paymentreferenceNo;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAmnt() {
		return amnt;
	}
	public void setAmnt(String amnt) {
		this.amnt = amnt;
	}

}
