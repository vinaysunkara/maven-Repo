package com.aia.ahs.common.aso.claimstatementgmm.model;

public class ClaimStatementGmmClaimExcessTable {
	private String dsrc;
	private String amnt;
	public String getDsrc() {
		return dsrc;
	}
	public void setDsrc(String dsrc) {
		this.dsrc = dsrc;
	}
	public String getAmnt() {
		return amnt;
	}
	public void setAmnt(String amnt) {
		this.amnt = amnt;
	}
	

}
