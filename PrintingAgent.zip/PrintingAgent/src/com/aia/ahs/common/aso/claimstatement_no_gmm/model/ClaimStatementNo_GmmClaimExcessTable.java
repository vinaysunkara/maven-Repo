package com.aia.ahs.common.aso.claimstatement_no_gmm.model;

public class ClaimStatementNo_GmmClaimExcessTable {
	private String dsrc;
	private String amnt;
	public String getDsrc() {
		return dsrc;
	}
	public void setDsrc(String dsrc) {
		this.dsrc = dsrc;
	}
	public String getAmnt() {
		return amnt;
	}
	public void setAmnt(String amnt) {
		this.amnt = amnt;
	}
	
}
