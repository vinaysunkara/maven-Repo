package com.aia.ahs.common.aso.claimstatementgmm.model;

public class ClaimStatementGmmMainTable {
private String dsrc;
private String noOfDays;
private String eblAmnt;
private String eblMaximumLimit;
private String majorMedicalAmnt;
private String incurredAmnt;
private String eligibleAmnt;
private String inEligibleAmnt;
public String getDsrc() {
	return dsrc;
}
public void setDsrc(String dsrc) {
	this.dsrc = dsrc;
}
public String getNoOfDays() {
	return noOfDays;
}
public void setNoOfDays(String noOfDays) {
	this.noOfDays = noOfDays;
}
public String getEblAmnt() {
	return eblAmnt;
}
public void setEblAmnt(String eblAmnt) {
	this.eblAmnt = eblAmnt;
}
public String getEblMaximumLimit() {
	return eblMaximumLimit;
}
public void setEblMaximumLimit(String eblMaximumLimit) {
	this.eblMaximumLimit = eblMaximumLimit;
}
public String getMajorMedicalAmnt() {
	return majorMedicalAmnt;
}
public void setMajorMedicalAmnt(String majorMedicalAmnt) {
	this.majorMedicalAmnt = majorMedicalAmnt;
}
public String getIncurredAmnt() {
	return incurredAmnt;
}
public void setIncurredAmnt(String incurredAmnt) {
	this.incurredAmnt = incurredAmnt;
}
public String getEligibleAmnt() {
	return eligibleAmnt;
}
public void setEligibleAmnt(String eligibleAmnt) {
	this.eligibleAmnt = eligibleAmnt;
}
public String getInEligibleAmnt() {
	return inEligibleAmnt;
}
public void setInEligibleAmnt(String inEligibleAmnt) {
	this.inEligibleAmnt = inEligibleAmnt;
}

}
