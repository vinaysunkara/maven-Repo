package com.aia.ahs.takaful.aso.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.HashMap;
import org.apache.commons.io.FilenameUtils;


import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class AhsTkAsoDebitNoteService extends Thread{
	private Thread t;

	public void run() {
		
		genReport();
	}
	
	public void	genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoDebitNoteRSDetails=getAsoDebitNoteDetails();
			
		int noFiles=asoDebitNoteRSDetails.size();
		    for(int i=0; i<noFiles;i++){
		    	HashMap<Integer, HashMap<String, Object>> asoDebitNoteRS=asoDebitNoteRSDetails.get(i);
		    	 		
		       HashMap<String, Object> dataSource=new HashMap<String, Object>();
		    	for(int a=0;a<asoDebitNoteRS.size();a++){
		    	        dataSource.putAll(asoDebitNoteRS.get(a));
		    	}
		    	
		    	
		    	uploadReport(dataSource);
		    }
		
		}
		public  void uploadReport(HashMap<String, Object> dataSource) {
			String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\takaful\\";
		
			String billmonth=""+dataSource.get("billMonth");
	    	String billperiod=billmonth.replace("/", "");
	    	String pdfname=dataSource.get("policyNum")+"_"+billperiod+"_"+dataSource.get("billNum")+"_ASODN";
	    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
	    	
			try {
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\takaful\\ASO\\debitNote\\AhsTkAsoDebitNote.jasper";
				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			  String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo",logo);	
			  
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getAsoDebitNoteDetails(){
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\debitNote.txt";

			BufferedReader br = null;
			FileReader fr = null;
			HashMap<Integer, HashMap<String, Object>> asoDebitNotetRS = new HashMap<Integer, HashMap<String, Object>>();
			HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoDebitNotetRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No AsoDebitNote Flat file ");
				} else {
					String sCurrentLine;
					int cuurline = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						
						Boolean add = false;

						HashMap<String, Object> asoDebitNote = new HashMap<String, Object>();

						if (cuurline == 0 || sCurrentLine.contains("****")) {
							asoDebitNote = new HashMap<String, Object>();
							asoDebitNotetRS = new HashMap<Integer, HashMap<String, Object>>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							cuurline = 0;
						}
						String[] data = sCurrentLine.split("\\|");
						for (int i = 0; i < data.length; i++) {

							if (data[0].equalsIgnoreCase("0001")) {
								add = true;
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1H")) {
								if(i==2){
									asoDebitNote.put("companyName", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==3){
									asoDebitNote.put("companySurname", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==4){
									asoDebitNote.put("addressLine1", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==5){
									asoDebitNote.put("addressLine2", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==6){
									asoDebitNote.put("addressLine3", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==7){
									asoDebitNote.put("addressLine4", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==8){
									asoDebitNote.put("addressLine5", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==9){
									asoDebitNote.put("billNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==10){
									asoDebitNote.put("dateOfIssue", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
									
								}
								if(i==11){
									asoDebitNote.put("billMonth", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
							
								}
								if(i==12){
									asoDebitNote.put("paymentDueDate", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
							} 	
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("2H")) {
								if(i==2){
									asoDebitNote.put("policyHolder", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==3){
									asoDebitNote.put("subsidiary", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==4){
									asoDebitNote.put("policyNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==5){
									asoDebitNote.put("poNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==6){
									asoDebitNote.put("amnt", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1T")) {
								if(i==2){
									asoDebitNote.put("totalAmnt", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}

							}
						}
						if (add) {
							asoDebitNotetRS.put(cuurline, asoDebitNote);
							cuurline++;
							asoDebitNotetRSDetails.put(pdfgencount, asoDebitNotetRS);
							
						}
					}
					
				}

			} catch (Exception e) {
				System.out.println("[AsoDebitNoteService.getAsoDebitNoteeDetails] Exception: "
						+ e.toString());
				e.printStackTrace();
			}
			return asoDebitNotetRSDetails;
		}
		
		
		
		public void startBatch() {
			System.out.println("Starting thread ");

			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}

		public static void main(String args[]) {
			AhsTkAsoDebitNoteService sbs = new AhsTkAsoDebitNoteService();
			sbs.startBatch();
			System.out.println("startedd.....");
		}
	
}
