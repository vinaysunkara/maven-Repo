package com.aia.ahs.takaful.claimexcess.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.common.claimexcess.summarystatement.model.ClaimExcessAsoSummaryStatementTableData;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class AhsTkClaimExcessSummaryStatementService extends Thread {
	private Thread t;

	public void run() {
		genReport();
	}
	public void	genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> ceSummaryStatementRSDetails=getCESummaryStatementDetails();
		HashMap<Integer, List<ClaimExcessAsoSummaryStatementTableData>> ceSummaryStatementListDetails=getCESummaryStatementTableData();
		int noFiles=ceSummaryStatementRSDetails.size();
		    for(int i=0; i<noFiles;i++){
		    	HashMap<Integer, HashMap<String, Object>> ceSummaryStatementRS=ceSummaryStatementRSDetails.get(i);
		    	List<ClaimExcessAsoSummaryStatementTableData> ceSummaryStatementList=ceSummaryStatementListDetails.get(i);
		       HashMap<String, Object> dataSource=new HashMap<String, Object>();
		    	for(int a=0;a<ceSummaryStatementRS.size();a++){
		    	        dataSource.putAll(ceSummaryStatementRS.get(a));
		    	}
		    	dataSource.put("ceSummaryStatementList", ceSummaryStatementList);
		    	uploadReport(dataSource);
		    	
		    }
		
		}
		public  void uploadReport(HashMap<String, Object> dataSource) {
			String billmonth=""+dataSource.get("billMonth");
	    	String billperiod=billmonth.replace("/", "").replace(" ", "");
	    	
	    	String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ahs\\takaful\\";
	    	
	    	String pdfname=dataSource.get("policyNum")+"_"+billperiod+"_"+dataSource.get("billNum")+"_CESummaryStmt";
	    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
	    	
			try {
				//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
				String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				String jrFullReadpath = path+"PrintingAgentReports\\AHS\\takaful\\CE\\summaryBillingStatement\\AhsTkClaimExcessSummaryStatement.jasper";
				// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
				FileInputStream inputStream = new FileInputStream(jrFullReadpath);
				//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			  String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo",logo);	
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
				
				FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
				JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
				System.out.println("PDF Generated..."+pdfFullOutputPath);
			} catch (Exception e) {
				System.out.println("Exception occurred : " + e);
			} finally {

			}
		}
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getCESummaryStatementDetails(){
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\ce\\ClaimExcessSummarybillingPdf.txt";
		
			BufferedReader br = null;
			FileReader fr = null;
			HashMap<Integer, HashMap<String, Object>> ceSummaryStatementtRS = new HashMap<Integer, HashMap<String, Object>>();
			HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> ceSummaryStatementtRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No AHS takaful  Claim Excess SummaryStatement Flat file ");
				} else {
					String sCurrentLine;
					int cuurline = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						
						Boolean add = false;

						HashMap<String, Object> ceSummaryStatement = new HashMap<String, Object>();

						if (cuurline == 0 || sCurrentLine.contains("****")) {
							ceSummaryStatement = new HashMap<String, Object>();
							ceSummaryStatementtRS = new HashMap<Integer, HashMap<String, Object>>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							cuurline = 0;
						}
						String[] data = sCurrentLine.split("\\|");
						for (int i = 0; i < data.length; i++) {

							if (data[0].equalsIgnoreCase("0001")) {
								add = true;
							} 
							if (data[0].equalsIgnoreCase("0001")&&data[1].equalsIgnoreCase("1H")) {
								if(i==2){
									ceSummaryStatement.put("policyHolder", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==3){
									ceSummaryStatement.put("subsidiary", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==4){
									ceSummaryStatement.put("policyNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==5){
									ceSummaryStatement.put("billNum", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==6){
									ceSummaryStatement.put("dateOfIssue", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==7){
									ceSummaryStatement.put("billMonth", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}
								
							} 	
							
							if (data[0].equalsIgnoreCase("0001")) {
								if(i==2){
									ceSummaryStatement.put("totalAmnt", data[i] != null && data[i].length() > 0 ? data[i].trim(): "");
								}

							}
						}
						if (add) {
							ceSummaryStatementtRS.put(cuurline, ceSummaryStatement);
							cuurline++;
							ceSummaryStatementtRSDetails.put(pdfgencount, ceSummaryStatementtRS);
							
						}
					}
					
				}

			} catch (Exception e) {
				System.out.println("[AhsTkClaimExcessSummaryStatementService.getCESummaryStatementeDetails] Exception: "
						+ e.toString());
				e.printStackTrace();
			}
			return ceSummaryStatementtRSDetails;
		}
		
		
		public static HashMap<Integer, List<ClaimExcessAsoSummaryStatementTableData>> getCESummaryStatementTableData() {
			String FILENAME = "D:\\Test_Read\\txtFiles\\ahs\\conventional\\ce\\ClaimExcessSummarybillingPdf.txt";
		

			BufferedReader br = null;
			FileReader fr = null;
			List<ClaimExcessAsoSummaryStatementTableData> ceSummaryStatementList = new ArrayList<ClaimExcessAsoSummaryStatementTableData>();
			HashMap<Integer, List<ClaimExcessAsoSummaryStatementTableData>> ceSummaryStatementListDetails = new HashMap<Integer, List<ClaimExcessAsoSummaryStatementTableData>>();

			try {
				fr = new FileReader(FILENAME);
				br = new BufferedReader(fr);
				if (br == null || br.equals("")) {
					System.out.println("No AHS takaful Claim Excess SummaryStatement Flat file ");
				} else {
					String sCurrentLine;
					int currentLint = 0, pdfgencount = 0;

					while ((sCurrentLine = br.readLine()) != null) {
						ClaimExcessAsoSummaryStatementTableData ceSummaryStatement = new ClaimExcessAsoSummaryStatementTableData();

						boolean add = false;
						if (currentLint == 0 || sCurrentLine.contains("****")) {
							ceSummaryStatement = new ClaimExcessAsoSummaryStatementTableData();
							ceSummaryStatementList = new ArrayList<ClaimExcessAsoSummaryStatementTableData>();

							if (sCurrentLine.contains("****")) {
								pdfgencount++;
							}
							currentLint = 0;
						}

						String data[] = sCurrentLine.split("\\|");
						for (int i = 0; i < data.length; i++) {
							if (data[0].equalsIgnoreCase("0001")) {
								add = true;
							
							}
							if (data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")) {
								if (i == 2) {
									ceSummaryStatement.setClaimNum(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
	                            }
								if (i == 3) { 
									ceSummaryStatement.setEmpName(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");

								}
								if (i == 4) {
									ceSummaryStatement.setEmpNricPassportNum(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
								}
								if (i == 5) {
									ceSummaryStatement.setClaimantName(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
								}
								if (i == 6) {
									ceSummaryStatement.setRelationship(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
								}
								if (i == 7) {
									ceSummaryStatement.setVisitDate(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
								}
								if (i == 8) {
									ceSummaryStatement.setClaimExcess(data[i]!= null&& data[i].length() > 0 ?data[i].trim(): "");
								}

							}

						}
						if (add) {
							if (data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")) {
								ceSummaryStatementList.add(ceSummaryStatement);
							}
						}
						currentLint++;
						ceSummaryStatementListDetails.put(pdfgencount, ceSummaryStatementList);
					}
				}
	                     
			} catch (Exception e) {
				System.out.println(
						"[AhsTkClaimExcessSummaryStatementService.getCESummaryStatementTableData] Exception: " + e.toString());
				e.printStackTrace();
			}
			return ceSummaryStatementListDetails;
		}
			
		
		
		
		public void startBatch() {
			System.out.println("Starting thread ");

			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}

		public static void main(String args[]) {
			AhsTkClaimExcessSummaryStatementService sbs = new AhsTkClaimExcessSummaryStatementService();
			
			sbs.startBatch();
			System.out.println("startedd.....");
		}
	
}
