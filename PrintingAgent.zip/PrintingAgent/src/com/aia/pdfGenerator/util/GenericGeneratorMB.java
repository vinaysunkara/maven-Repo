package com.aia.pdfGenerator.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.ParseException;

import com.aia.pdfGenerator.model.Body;
import com.aia.pdfGenerator.model.Table;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class GenericGeneratorMB extends GenericHeaderFooterMB {
	private Document doc = null;
	int pageNum;
	PdfTemplate total; 
	
	public GenericGeneratorMB() {
		super();
	}
	
	/**
	 * start generate PDF report 
	 */
//	public void runReport() {
	public ByteArrayOutputStream runReport() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		try {
			doc = initDoc();
			
			writer = PdfWriter.getInstance(doc, baos);
			
			// print report header and sub header
			writer.setPageEvent(new EndPageEvent());
			doc.open();
            
			printBody(doc);
            
			doc.close();
			printFooter(doc, baos);
			
		} catch(Exception e) {
			System.out.println("[GenericGeneratorMB.java] [runReport] Exception --> " + e.toString());
		} finally {
			doc = null;
		}
		
		return baos;
	}
		
	/**
	 * print PDF body
	 * @param document
	 * @throws DocumentException
	 * @throws ParseException
	 */
	public void printBody(Document document) throws DocumentException, ParseException, IOException {
		Body body = getReportDefinition().getBody();
		
		if (body != null) {
			for (Table table : body.getTable()) {
				if(table.isNewPage()) {
					document.newPage();
				}
				
				PdfPTable bodyTable = null;
				
				bodyTable = genPDFPTable(doc, bodyTable, table);
				
				document.add(bodyTable);
			}			
		}		
	}
		
	
	 public void onStartPage(PdfWriter writer, Document document) { 
         pageNum++; 
     }  
	 
	/**
	 * when PDF file page end, write the header to that PDF file page.
	 */
	public class EndPageEvent extends PdfPageEventHelper {
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			try{
				if (getReportDefinition().getHeader().isRepeat() || writer.getPageNumber() == 1) {
					printHeader(document, getReportDefinition());
				}
			} catch(Exception e) {
				System.out.println("[EndPageEvent.java] [runReport] Exception --> " + e.toString());
			}
		}
	}
}
