package com.aia.pdfGenerator.util;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import com.aia.pdfGenerator.model.Column;
import com.aia.pdfGenerator.model.Reports;
import com.aia.pdfGenerator.model.Row;
import com.aia.pdfGenerator.model.Table;
//import com.ibm.misc.BASE64Decoder;
//import com.ibm.misc.BASE64Encoder;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.Barcode39;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfGState;
import com.lowagie.text.pdf.PdfLayer;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class GenericUtil {
	protected PdfWriter writer = null;
	private Reports reportDefinition;
	
	private CommonFileUtil cu = new CommonFileUtil();
	
	final String defaultPaperSize = "LETTER";
	final String defaultPageLayout = "PORTRAIT";
	final float tableWidthPercentage = 100;
	final int colTotalChar = 152;
	
	private int totalPageNo;
	private int pageNo;
	
	private HashMap<Integer, HashMap<String, String>> dbData = new HashMap<Integer, HashMap<String, String>>();
	private HashMap<Integer, HashMap<String, String>> gstSummary = new HashMap<Integer, HashMap<String, String>>();
//	private HashMap<Integer, HashMap<String, String>> nbCOI = new HashMap<Integer, HashMap<String, String>>();
//	private HashMap<Integer, HashMap<String, String>> excl = new HashMap<Integer, HashMap<String, String>>();
	private HashMap<String, String> currRowDBData = new HashMap<String, String>();
	private HashMap<String, Integer> alignment = new HashMap<String, Integer>();
	private HashMap<String, Integer> fontStyle = new HashMap<String, Integer>();
	private List<Integer> pagePerTaxInv = new ArrayList<Integer>();
	
	/**
	 * get DB Data HashMap
	 * @return
	 */
	public HashMap<Integer, HashMap<String, String>> getDbData() {
		return dbData;
	}

	/**
	 * set DB Data to HashMap
	 * @param dbData
	 */
	public void setDbData(HashMap<Integer, HashMap<String, String>> dbData) {
		this.dbData = dbData;
	}
	
	/*public HashMap<Integer, HashMap<String, String>> getLaCovDet() {
		return laCovDet;
	}

	public void setLaCovDet(HashMap<Integer, HashMap<String, String>> laCovDet) {
		this.laCovDet = laCovDet;
	}

	public HashMap<Integer, HashMap<String, String>> getNbCOI() {
		return nbCOI;
	}

	public void setNbCOI(HashMap<Integer, HashMap<String, String>> nbCOI) {
		this.nbCOI = nbCOI;
	}

	public HashMap<Integer, HashMap<String, String>> getExcl() {
		return excl;
	}

	public void setExcl(HashMap<Integer, HashMap<String, String>> excl) {
		this.excl = excl;
	}*/

	public HashMap<String, String> getCurrRowDBData() {
		return currRowDBData;
	}

	public void setCurrRowDBData(HashMap<String, String> currRowDBData) {
		this.currRowDBData = currRowDBData;
	}

	/**
	 * get report definition (xml report template file value) object
	 * @return
	 */
	public Reports getReportDefinition() {
		return reportDefinition;
	}

	/**
	 * set report definition (xml report template file) to object
	 * @param reportDefinition
	 */
	public void setReportDefinition(Reports reportDefinition) {
		this.reportDefinition = reportDefinition;
	}
	
	/**
	 * get font
	 * @return Font
	 */
	public Font getFont(String fontStr, float fontSize, int fontSytle, Color fontColor) {
		if (fontStr == null || fontStr.length() == 0) {
			return FontFactory.getFont("Arial", 10, Font.NORMAL);
		} else if ("Courier".equalsIgnoreCase(fontStr)) {
			return FontFactory.getFont("Courier", fontSize, fontSytle, fontColor);
		} else {
			fontStr = cu.getRootPath(fontStr);
		}
		
		if (fontColor == null) {
			fontColor = Color.BLACK;
		}
		
		return FontFactory.getFont(fontStr, fontSize, fontSytle, fontColor);
	}
	
	/**
	 * convert String array to Integer array
	 * @param strArray
	 * @return int[]
	 */
	protected int[] conStrArrToIntArr(String[] strArray) {
		if (strArray != null) {
			int intArray[] = new int[strArray.length];  
			for (int i = 0; i < strArray.length; i++) {
				intArray[i] = Integer.parseInt(strArray[i]);
			}
			return intArray;
		}
		return null;		
	}
	
	/**
	 * Create PDF Table object
	 * @param totalColumns
	 * @param colWidth
	 * @return
	 * @throws DocumentException
	 */
	protected PdfPTable createTable(Integer totalColumns, int[] colWidth) throws DocumentException {
		PdfPTable table = new PdfPTable(totalColumns);
		table.setWidthPercentage(tableWidthPercentage);
		table.setWidths(colWidth);
		
		return table;
	}
	
	/**
	 * print the PDF file dotted line
	 * @param docWidth
	 * @return
	 */
	protected String printColumnLine(int docWidth) {
		String value = "";
		for(int a = 0; a < docWidth; a++) {
			value += "-";
		}
		
		return value;
	}
	
	/**
	 * print empty row in the PDF file
	 * @param columnSpan
	 * @return
	 */
	
	
	protected PdfPCell printEmptyRow(int columnSpan) {
		Phrase phrase = new Phrase("");
		PdfPCell cell = new PdfPCell(phrase);
		cell.setBorder(0);
		cell.setColspan(columnSpan);
		        
		return cell;
	}
	
	/**
	 * print the PDF file line separator 
	 * @return
	 */
	protected PdfPCell printSeparator (Integer columnSpan, Integer rowSpan, int horizontalAlignment, int verticalAlignment, 
			Integer borderTop, Integer borderBottom, Integer borderRight, Integer borderLeft) {
		PdfPCell cell = new PdfPCell();
		cell.setVerticalAlignment(verticalAlignment);
		
		if (borderTop != null && borderTop > 0) {
			cell.setBorderWidthTop(borderTop);
		} else {
			cell.setBorderWidthTop(0);
		}
		
		if (borderBottom != null && borderBottom > 0) {
			cell.setBorderWidthBottom(borderBottom);
		}else {
			cell.setBorderWidthBottom(0);
		}
		
		if (borderRight != null && borderRight > 0) {
			cell.setBorderWidthRight(borderRight);
		}else {
			cell.setBorderWidthRight(0);
		}
		
		if (borderLeft != null && borderLeft > 0) {
			cell.setBorderWidthLeft(borderLeft);
		}else {
			cell.setBorderWidthLeft(0);
		}
		
		if (columnSpan != null && columnSpan > 0) {
			cell.setColspan(columnSpan);
		}
		
		if (rowSpan != null && rowSpan > 0) {
			cell.setRowspan(rowSpan);
		}
		cell.addElement(new LineSeparator());
		
		return cell;
	}
	
	
	/**
	 * create a PDF phrase & Cell
	 * @param value
	 * @param font
	 * @param border
	 * @param horizontalAlignment
	 * @param verticalAlignment
	 * @param columnSpan
	 * @return PdfPCell
	 */
	protected PdfPCell createCellText(String value, Font font, Integer borderTop, Integer borderBottom, Integer borderRight, 
			Integer borderLeft, int horizontalAlignment, int verticalAlignment, Integer columnSpan, Integer rowSpan, float leading, 
			float relLeading, Integer rotation, Color bgColor) {
		Phrase phrase = new Phrase(value, font);
		PdfPCell cell = new PdfPCell(phrase);
		cell.setHorizontalAlignment(horizontalAlignment);
		cell.setVerticalAlignment(verticalAlignment);
//		cell.setBorder(border);
		cell.setLeading(leading, relLeading);
		
		if (borderTop != null && borderTop > 0) {
			cell.setBorderWidthTop(borderTop);
		} else {
			cell.setBorderWidthTop(0);
		}
		
		if (borderBottom != null && borderBottom > 0) {
			cell.setBorderWidthBottom(borderBottom);
		}else {
			cell.setBorderWidthBottom(0);
		}
		
		if (borderRight != null && borderRight > 0) {
			cell.setBorderWidthRight(borderRight);
		}else {
			cell.setBorderWidthRight(0);
		}
		
		if (borderLeft != null && borderLeft > 0) {
			cell.setBorderWidthLeft(borderLeft);
		}else {
			cell.setBorderWidthLeft(0);
		}
		
		if (rotation != null && rotation > 0){
			cell.setRotation(rotation);
		}
		
		if (columnSpan != null && columnSpan > 0) {
			cell.setColspan(columnSpan);
		}
		
		if (rowSpan != null && rowSpan > 0) {
			cell.setRowspan(rowSpan);
		}
		
		if (bgColor != null) {
			cell.setBackgroundColor(bgColor);
		}
        
		return cell;
	}
	
	/**
	 * create a PDF phrase & Cell
	 * @param Image
	 * @param horizontalAlignment
	 * @param verticalAlignment
	 * @param columnSpan
	 * @return PdfPCell
	 */
	protected PdfPCell createCellImg(Image img, int border, int horizontalAlignment, int verticalAlignment, Integer borderTop,  
			Integer borderBottom, Integer borderRight, Integer borderLeft, Integer colSpan, Integer rowSpan, Integer rotation) {
		PdfPCell cell;
		
		cell = new PdfPCell(img);
		cell.setBorder(border);
//		cell.setRotation(270);
		cell.setHorizontalAlignment(horizontalAlignment);
		cell.setVerticalAlignment(verticalAlignment);
		
		if (borderTop != null && borderTop > 0) {
			cell.setBorderWidthTop(borderTop);
		} else {
			cell.setBorderWidthTop(0);
		}
		
		if (borderBottom != null && borderBottom > 0) {
			cell.setBorderWidthBottom(borderBottom);
		}else {
			cell.setBorderWidthBottom(0);
		}
		
		if (borderRight != null && borderRight > 0) {
			cell.setBorderWidthRight(borderRight);
		}else {
			cell.setBorderWidthRight(0);
		}
		
		if (borderLeft != null && borderLeft > 0) {
			cell.setBorderWidthLeft(borderLeft);
		}else {
			cell.setBorderWidthLeft(0);
		}
		
		if(colSpan != null && colSpan > 0) {
			cell.setColspan(colSpan);
		}
		
		if (rowSpan != null && rowSpan > 0) {
			cell.setRowspan(rowSpan);
		}
		
		if (rotation != null && rotation > 0){
			cell.setRotation(rotation);
		}

		return cell;
	}
	
	/**
	 * convert the alignment word to Java alignment types
	 * @param passAlign
	 * @return integer
	 */
	protected int getAlignment(String passAlign) {
		int returnVal = 0;
		if (alignment.size() == 0) {
			alignment.put("LEFT", Element.ALIGN_LEFT);
			alignment.put("CENTER", Element.ALIGN_CENTER);
			alignment.put("RIGHT", Element.ALIGN_RIGHT);
			alignment.put("TOP", Element.ALIGN_TOP);
			alignment.put("BOTTOM", Element.ALIGN_BOTTOM);
			alignment.put("JUSTIFIED", Element.ALIGN_JUSTIFIED);
			alignment.put("MIDDLE", Element.ALIGN_MIDDLE);			
		}
		
		if (passAlign != null && alignment.get(passAlign.toUpperCase()) != null) {
			returnVal = alignment.get(passAlign.toUpperCase());
		}
		
		return returnVal;
	}
	
	/**
	 * convert the Font Style word to Java Font Style types
	 * @param passAlign
	 * @return integer
	 */
	protected int getFontStyle(String fontStyleStr) {
		int returnVal = 0;
		if (fontStyle.size() == 0) {
			fontStyle.put("BOLD", Font.BOLD);
			fontStyle.put("ITALIC", Font.ITALIC);
			fontStyle.put("BOLDITALIC", Font.BOLDITALIC);
			fontStyle.put("UNDERLINE", Font.UNDERLINE);			
		}
		
		if (fontStyleStr != null && fontStyle.get(fontStyleStr.toUpperCase()) != null) {
			returnVal = fontStyle.get(fontStyleStr.toUpperCase());
		}
		
		return returnVal;
	}
	
	protected Color getColor(String colorStr) {
		Color fontColor = null;
		if (colorStr != null && colorStr.trim().length() > 0) {
			String[] colorArr =  colorStr.split(",");
			
			if (colorArr.length != 3) {
				return null;
			} else {
				for (String color : colorArr) {
					if (color == null || color.trim().length() == 0) {
						return null;
					} 
				}
				
				String colorRed = colorArr[0];
				String colorGreen = colorArr[1];
				String colorBlue = colorArr[2];
				
				fontColor = new Color(Integer.parseInt(colorRed), Integer.parseInt(colorGreen), Integer.parseInt(colorBlue));			
			}
		} else {
			return null;
		}
		
		return fontColor;
	}
	
	/**
	 * general function to generate PDFPTable
	 * @param doc
	 * @param pdfPTable
	 * @param table
	 * @return PdfPTable
	 */
	protected PdfPTable genPDFPTable(Document doc, PdfPTable pdfPTable, Table table) throws DocumentException, IOException {
		int loop = 1;
		int displaySeqNo = 1;
		
		int[] colwidth = conStrArrToIntArr(table.getTableWidths().split(","));
		pdfPTable = createTable(table.getTableNoColumns(), colwidth);
		pdfPTable.setTotalWidth((doc.right() - doc.left()));
		HashMap<Integer, HashMap<String, String>> rsData = getDbData();
//try {	
		if (table.getSql() != null && table.getSql().length() > 0) {
			if ("GSTSummary".equalsIgnoreCase(table.getSql())){
				rsData = getGstSummary();
			}
		}
		
		HashMap<String, String> rowDBData = getCurrRowDBData();
		
		for (Row row : table.getRow()) {
			if ("DBTable".equalsIgnoreCase(row.getType())) {
				loop = rsData.size();
			} else if("DBTableNew".equalsIgnoreCase(row.getType())) {
				loop = rsData.size();
			} else {
				loop = 1;
			}
			
			for (int i=0; i<loop; i++) {
				if (rowDBData == null || "DBTableNew".equalsIgnoreCase(row.getType())){
					rowDBData = rsData.get(i);
				}
				
				if (rowDBData == null || "DBTable".equalsIgnoreCase(row.getType())){
					rowDBData = rsData.get(i);
				}
				if (rowDBData == null) {
					System.out.println("rowDBData is null value");
				}
				
				if(rowDBData != null) {
					for (Column column : row.getColumn() ) {
						PdfPCell pdfLabelCell = null;
						
						String content = column.getContent();
						if (content.indexOf("|^") >= 0 && content.indexOf("^|") >= 0 ) {
							content = getOptionalNote(content, getDbData().get(0).get("skipPage"));											
						}
						
						if ("#PAGE".equals(content)) {
	//						content = String.valueOf(writer.getPageNumber());
							content = String.format("Page %d of %d", getPageNo(), getTotalPageNo());
						} else {
	//						List<String> fields = getReplaceFieldName(content);
							List<String> fields = new ArrayList<String>();
							
							if (content.indexOf("$%") >= 0 && content.indexOf("%$") >= 0 ) {
								fields = getReplaceFieldName(content, "$%", "%$");
								
								for (String field : fields) {
									String data = rowDBData.get(field);
									
									String pattern = column.getPattern();
									
									if (pattern != null && pattern.length() > 0) {
										if ("n".equalsIgnoreCase(pattern.substring(0,1))) {
											if (data == null || data.length() == 0) {
												data = "";
											} else {
												if (data.matches("-?\\d+(\\.\\d+)?")) {
													DecimalFormat df = new DecimalFormat(pattern.substring(1));
													data = df.format(Double.parseDouble(data));
												}
											}
											
										} else if ("c".equalsIgnoreCase(pattern.substring(0,1))) {
											if (data == null || data.length() == 0) {
												data = "";
											} else {
													DecimalFormat df = new DecimalFormat(pattern.substring(1));
													data = df.format(Double.parseDouble(data));
											}
											
										} /*else if ("d".equalsIgnoreCase(pattern.substring(0,1))) {
											if (content != null || content.length() > 0) {
												SimpleDateFormat sdf = new SimpleDateFormat(pattern.substring(1));
												
											}
										}*/							
									}
									
									if (!column.getRepeat() && i > 0) {
										if (data == null) {
											data = "";
										} else {
											boolean isSameValue = getSameValue(i, field, data, rsData);
											
											if (isSameValue) {
												data = "";
											}
										}
									} else {
										if (data == null || "null".equalsIgnoreCase(data)) {
											data = "";
										}
									}
									
									content = content.replace("$%" + field + "%$", data.trim());
								}
							}
						}
						
						if (column != null && "FILE".equalsIgnoreCase(column.getType())) {
	//						File realFile = new File(content);
											
							if (content.length() > 0) {
								Image logoImg = Image.getInstance(cu.getRootPath(content));
								if (column.getWidth() != null && column.getHeight() != null) {
									float imgWidth = Float.parseFloat(column.getWidth());
									float imgHeight = Float.parseFloat(column.getHeight());
									
									logoImg.setAbsolutePosition(0, 0);
									logoImg.scaleToFit(imgWidth, imgHeight);
								}	
								
								int pageNo = writer.getPageNumber();
								int borderBottom = 0;
								
								if("DBTableNew".equalsIgnoreCase(row.getType()) && pageNo==1) {
									pdfLabelCell = createCellImg(logoImg, 0, getAlignment(column.getAlign()), getAlignment(column.getValign()), 
											column.getBorderTop(), borderBottom, column.getBorderRight(), column.getBorderLeft(), column.getColspan(), column.getRowspan(), column.getRotation());
								} else {
									pdfLabelCell = createCellImg(logoImg, 0, getAlignment(column.getAlign()), getAlignment(column.getValign()), 
											column.getBorderTop(), column.getBorderBottom(), column.getBorderRight(), column.getBorderLeft(), column.getColspan(), column.getRowspan(), column.getRotation());
								}
							}
						} /*else if ("TEXT".equalsIgnoreCase(column.getType())) {
							pdfLabelCell = createCellText(content, getFont(column.getFont(), column.getFontsize(), getFontStyle(column.getFontstyle()), getColor(column.getFontColor())),
								column.getBorderTop(), column.getBorderBottom(), column.getBorderRight(), column.getBorderLeft(), 
								getAlignment(column.getAlign()), getAlignment(column.getValign()), column.getColspan(), column.getRowspan(), 
								column.getLeading(), column.getRelLeading(), column.getRotation(), getColor(column.getBgColor()));
						}*/ 
						else if("TEXT".equalsIgnoreCase(column.getType()) && !"DBTableNew".equalsIgnoreCase(row.getType())){
		                       pdfLabelCell = createCellText(content, getFont(column.getFont(), column.getFontsize(), getFontStyle(column.getFontstyle()), getColor(column.getFontColor())),
	                           column.getBorderTop(), column.getBorderBottom(), column.getBorderRight(), column.getBorderLeft(), 
				               getAlignment(column.getAlign()), getAlignment(column.getValign()), column.getColspan(), column.getRowspan(), 
				               column.getLeading(), column.getRelLeading(), column.getRotation(), getColor(column.getBgColor()));
		                    }else if("TEXT".equalsIgnoreCase(column.getType())&& "DBTableNew".equalsIgnoreCase(row.getType()) && i!=0){
		                         if (i!=0 && i!=(loop-1)) 
		                       {
			                   pdfLabelCell = createCellText(content, getFont(column.getFont(), column.getFontsize(), getFontStyle(column.getFontstyle()), getColor(column.getFontColor())),
					           column.getBorderTop(), column.getBorderBottom(), column.getBorderRight(), column.getBorderLeft(), 
					           getAlignment(column.getAlign()), getAlignment(column.getValign()), column.getColspan(), column.getRowspan(), 
					           column.getLeading(), column.getRelLeading(), column.getRotation(), getColor(column.getBgColor()));							
		                     }							
	                        } else if ("SEQNO".equalsIgnoreCase(column.getType())) {
							pdfLabelCell = createCellText(String.valueOf(displaySeqNo), getFont(column.getFont(), column.getFontsize(), 
								getFontStyle(column.getFontstyle()), getColor(column.getFontColor())), column.getBorderTop(), column.getBorderBottom(), 
								column.getBorderRight(), column.getBorderLeft(), getAlignment(column.getAlign()), 
								getAlignment(column.getValign()), column.getColspan(), column.getRowspan(), column.getLeading(),
								column.getRelLeading(), column.getRotation(), null);
							displaySeqNo++;
						} else if ("LINE".equalsIgnoreCase(column.getType())) {
							pdfLabelCell = printSeparator(column.getColspan(), column.getRowspan(), getAlignment(column.getAlign()), getAlignment(column.getValign()),
								column.getBorderTop(), column.getBorderBottom(), column.getBorderRight(), column.getBorderLeft());
						}else if ("BARIMG".equalsIgnoreCase(column.getType())) {
//							BarcodeEAN codeEAN = new BarcodeEAN();
							Barcode39 codeEAN = new Barcode39();
//							codeEAN.setCodeType(codeEAN.EAN13);
							codeEAN.setCode(content);
							Image imageEAN = codeEAN.createImageWithBarcode(writer.getDirectContent(), null, null);
							
							pdfLabelCell = createCellImg(imageEAN, 0, getAlignment(column.getAlign()), getAlignment(column.getValign()), 
									column.getBorderTop(), column.getBorderBottom(), column.getBorderRight(), column.getBorderLeft(), column.getColspan(), column.getRowspan(), column.getRotation());
						}
						
						if (pdfLabelCell != null) {
							pdfPTable.addCell(pdfLabelCell);
						}
					}
				}
			}
		}	
//} catch (Exception ex) {
//	ex.printStackTrace();
//}
		return pdfPTable;
	}
	
	protected String getOptionalNote (String content, String skipPage) {
		String returnContent = "";
		
		String[] skipPages =  skipPage.split("!");
		
		List<String> optionalCodes = getReplaceFieldName(content, "|^", "^|");
		Set<String> set = new HashSet<String>();
		set.addAll(optionalCodes);
		optionalCodes.clear();
		optionalCodes.addAll(set);
				
		for (int i=0; i<optionalCodes.size(); i++) {
			boolean isFound = false;
			for (String spage : skipPages) {
				if (optionalCodes.get(i).equals(spage)) {
					isFound = true;
					break;
				}
			}
			
			if (!isFound) {
				String optionalCode = "|^" + optionalCodes.get(i) + "^|";
				returnContent += content.replace(optionalCode, "");
			}			
		}
				
		return returnContent;
	}
	
	protected boolean getSameValue(int currIndx, String fieldName, String fieldVal, HashMap<Integer, HashMap<String, String>> rsData) {
//		HashMap<Integer, HashMap<String, String>> rsData = getDbData();
		
		HashMap<String, String> rowDBData = rsData.get(currIndx-1);
		
		String preVal = rowDBData.get(fieldName);
		
		if (fieldVal != null && preVal != null && preVal.equalsIgnoreCase(fieldVal)) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * general function to get field name that need to replace by
	 * @param doc
	 * @param pdfPTable
	 * @param table
	 * @return PdfPTable
	 */
	protected List<String> getReplaceFieldName (String strValue, String startWith, String endWith) {
		List<String> returnFields = new ArrayList<String>();
//		String startWith = "$%";
//		String endWith = "%$";
				
		while (true) {
			int startIndx = strValue.indexOf(startWith);
			if (startIndx < 0) {
				break;
			}
			int endIndx = strValue.indexOf(endWith);
			
			returnFields.add(strValue.substring(startIndx + 2, endIndx));
			strValue = strValue.substring(endIndx+2);
		}
		
		return returnFields;
	}
	
	public ByteArrayOutputStream mergePDF(ByteArrayOutputStream MasterBaos, ByteArrayOutputStream tempBaos) {
		ByteArrayOutputStream finalBaos = null;
		try {
			finalBaos = new ByteArrayOutputStream();
			Document PDFCombineUsingJava = new Document();
			Rectangle rectangle = PageSize.A4;
			
			PdfCopy MasterCopy = new PdfCopy(PDFCombineUsingJava, finalBaos);
			PDFCombineUsingJava.open();
			PdfReader ReadInputPDF;
			int masterTotalPage = 0;
			int tempTotalPage = 0;
			
			if (MasterBaos != null && MasterBaos.toByteArray().length > 0) {
				ReadInputPDF = new PdfReader(MasterBaos.toByteArray());
				masterTotalPage = ReadInputPDF.getNumberOfPages();
				for (int page = 0; page < masterTotalPage; ) {
					MasterCopy.addPage(MasterCopy.getImportedPage(ReadInputPDF, ++page));
				}
				
				if (masterTotalPage%2 != 0) {
					MasterCopy.addPage(rectangle, 0);
					masterTotalPage++;
				}
			}
			
			if (tempBaos != null && tempBaos.toByteArray().length > 0) {
				ReadInputPDF = new PdfReader(tempBaos.toByteArray());
				tempTotalPage = ReadInputPDF.getNumberOfPages();
				
				//Start Calculate which page should print OMR Group
				if (tempTotalPage % 2 == 0) {
					pagePerTaxInv.add(masterTotalPage + (tempTotalPage - 1));
				} else {
					pagePerTaxInv.add(masterTotalPage + tempTotalPage);
				}
				//End Calculate which page should print OMR Group
								
				for (int page = 0; page < tempTotalPage; ) {
					MasterCopy.addPage(MasterCopy.getImportedPage(ReadInputPDF, ++page));
				}
			}
			
			PDFCombineUsingJava.close();
			
        } catch (Exception ex) {
            System.out.println("[mergePDF] " + ex.toString());
            return null;
        }
		
		return finalBaos;
	}
	
	public ByteArrayOutputStream combinePDF(ByteArrayOutputStream masterBaos, ByteArrayOutputStream tempBaos) {
		ByteArrayOutputStream finalBaos = null;
		
		try {
			finalBaos = new ByteArrayOutputStream();
			Document pdfCombine = new Document();
			
			PdfCopy masterCopy = new PdfCopy(pdfCombine, finalBaos);
			pdfCombine.open();
			
			PdfReader readInputPDF;
			int masterTotalPage = 0;
			int tempTotalPage = 0;
			
			if (masterBaos != null && masterBaos.toByteArray().length > 0) {
				readInputPDF = new PdfReader(masterBaos.toByteArray());
				masterTotalPage = readInputPDF.getNumberOfPages();
				for(int page = 0; page < masterTotalPage; ) {
					masterCopy.addPage(masterCopy.getImportedPage(readInputPDF, ++page));
				}
			}
			
			if (tempBaos != null && tempBaos.toByteArray().length > 0) {
				readInputPDF = new PdfReader(tempBaos.toByteArray());
				tempTotalPage = readInputPDF.getNumberOfPages();
												
				for(int page = 0; page < tempTotalPage; ) {
					masterCopy.addPage(masterCopy.getImportedPage(readInputPDF, ++page));
				}
			}
			
			pdfCombine.close();
			
		} catch(Exception ex) {
			System.out.println("[combinePDF] " + ex.toString());
			return null;
		}
		
		return finalBaos;
	}
	
	public ByteArrayOutputStream addWaterMark(ByteArrayOutputStream masterBaos) {
		ByteArrayOutputStream waterMarkBaos = new ByteArrayOutputStream();
		
		try {
			InputStream fis = new ByteArrayInputStream(masterBaos.toByteArray());
			
			PdfStamper stamper = new PdfStamper(new PdfReader(fis), waterMarkBaos);
			Image watermarkImage = Image.getInstance(cu.getRootPath("img/watermark.jpg"));
			
			PdfLayer wmLayer = new PdfLayer("watermark", stamper.getWriter());
	
			wmLayer.setOnPanel(true);
			// set layer parameters
			wmLayer.setOn(false);
			wmLayer.setView(true);
			wmLayer.setPrint("Watermark", true);
			wmLayer.setExport(true);
						
			// Prepare transperancy
			PdfGState transparent = new PdfGState();
			transparent.setStrokeOpacity(1f);
			transparent.setFillOpacity(1f);
			PdfContentByte cb;
			int toPage = stamper.getReader().getNumberOfPages();
			
			for (int i = 1; i <= toPage; i++) {
			    cb = stamper.getUnderContent(i);
//			 	Rectangle rectangle = stamper.getReader().getPageSizeWithRotation(i);
		 	    
		 	    cb.beginLayer(wmLayer);
		 	    cb.setGState(transparent); // set block trasparency properties		
		 	    
		 	    //position relative to top
		 	    watermarkImage.scaleAbsoluteHeight(250);
		 	    watermarkImage.scaleAbsoluteWidth(380);
		 	    
		 	    watermarkImage.setAbsolutePosition(130, 300);
		 	    cb.addImage(watermarkImage);
		 	    cb.endLayer();
			}
	
			stamper.close();
			
			fis = new ByteArrayInputStream(waterMarkBaos.toByteArray());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return waterMarkBaos;
	}	
	
	public ByteArrayOutputStream addOMRnIntNo(ByteArrayOutputStream masterBaos) {
		int seqRestartAt = 16;
		int matchRestartAt = 8;
		int sheetSeq = 0;
		int matchSeq = 0;
		
		float marginFrom = 10f;
		float marginTo = 39.4f;
		float parity = 638.0f;
		float group = 650.0f;
		float startBit = 662.0f;
		float[] match = {602.0f, 614.0f, 626.0f};
		float[] runningNo = {482.0f, 494.0f, 506.0f, 518.0f};
		ByteArrayOutputStream finalBaos = null;
		
		try {
//			System.out.println("-------------------------------- [" + new java.util.Date() + "] Add OMR Start --------------------------------");
			finalBaos = new ByteArrayOutputStream();
			
			PdfReader Read_PDF_To_OMR = new PdfReader(masterBaos.toByteArray());
			int totalPage = Read_PDF_To_OMR.getNumberOfPages();
			PdfStamper stamp = new PdfStamper(Read_PDF_To_OMR, finalBaos);
			
			PdfContentByte add_omr;
			
			for (int i = 1; i <= totalPage; i++) {
				if (i%2 == 1) {
					sheetSeq++;
					matchSeq++;
					
					int totalOMRLine = 1;
					add_omr = stamp.getUnderContent(i);
					add_omr.setLineWidth(1.45f);
					
					//OMR Start Bit
					add_omr.moveTo(marginFrom, startBit);
					add_omr.lineTo(marginTo, startBit);
					add_omr.stroke();
					
					//------------------------------------ Start Print Match ------------------------------------
					List<Float> printMatchLoc = printOMRLoc(matchSeq, matchRestartAt, match);
					
					for (Float loc : printMatchLoc){
						totalOMRLine++;
						add_omr.moveTo(marginFrom, loc);
						add_omr.lineTo(marginTo, loc);
						add_omr.stroke();
					}
					//------------------------------------ End Print Match ------------------------------------
					
					//------------------------------------ Start Print Sheet Seq ------------------------------------
					List<Float> printSeqLoc = printOMRLoc(sheetSeq, seqRestartAt, runningNo);
					
					for (Float loc : printSeqLoc){
						totalOMRLine++;						
						add_omr.moveTo(marginFrom, loc);
						add_omr.lineTo(marginTo, loc);
						add_omr.stroke();
					}
					//------------------------------------ End Print Sheet Seq ------------------------------------
					
					//OMR Group
					for (Integer pageOMRGroup : getPagePerTaxInv()) {
						if (pageOMRGroup == i) {
							totalOMRLine++;						
							add_omr.moveTo(marginFrom, group);
							add_omr.lineTo(marginTo, group);
							add_omr.stroke();
							
							matchSeq = 0;
							
							break;
						}
					}
					
					//OMR parity
					if (totalOMRLine % 2 == 0) {
						add_omr.moveTo(marginFrom, parity);
						add_omr.lineTo(marginTo, parity);
						add_omr.stroke();
						
						totalOMRLine = 1;
					}
										
					// ----------------------------------------- Start Internal No print on left bottom corner -----------------------------------------
					String intNo = "";
					
					if (i < 10) {
						intNo = "000" + i;
					} else if (i < 100) {
						intNo = "00" + i;
					} else if (i < 1000) {
						intNo = "0" + i;
					} else {
						intNo = String.valueOf(i);
					}
					
					BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.EMBEDDED);
					stamp.getUnderContent(i);
					add_omr.beginText();
					add_omr.setFontAndSize(bf, 6);
					add_omr.showTextAligned(PdfContentByte.ALIGN_LEFT, intNo, 20, 18, 0);
					add_omr.endText();
					
					// ----------------------------------------- End Internal No print on left bottom corner -----------------------------------------
				}
			}
			
			stamp.close();
		       
//			System.out.println("-------------------------------- [" + new java.util.Date() + "] Add OMR End --------------------------------");			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return finalBaos;
	}
	
	private List<Float> printOMRLoc(int currpage, int RestartAt, float[] match) {
		List<Float> printLoc = new ArrayList<Float>();
		
		while (currpage > (RestartAt - 1)) {
			currpage = currpage - (RestartAt - 1);
		}
		
		String printMatch = Integer.toBinaryString(currpage % RestartAt);
		
		for (int j = printMatch.length(); j < match.length; j++) {
			printMatch = "0" + printMatch;
		}
		
		String[] printMatchNoArr = printMatch.split("(?!^)");
		
		for (int y = 0; y < printMatchNoArr.length; y++) {
			if ("1".equals(printMatchNoArr[y])) {
				printLoc.add(match[y]);
			}
		}
				
		return printLoc;
	}
		
	public int getTotalPageNo() {
		return totalPageNo;
	}

	public void setTotalPageNo(int totalPageNo) {
		this.totalPageNo = totalPageNo;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public List<Integer> getPagePerTaxInv() {
		return pagePerTaxInv;
	}

	public HashMap<Integer, HashMap<String, String>> getGstSummary() {
		return gstSummary;
	}

	public void setGstSummary(HashMap<Integer, HashMap<String, String>> gstSummary) {
		this.gstSummary = gstSummary;
	}
	
	public static String formatNumber(double number) {
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);
		nf.setGroupingUsed(false);
		
		return nf.format(number);
	}
	
	public static String calculateTime(long start) {
		return formatNumber(((double)System.currentTimeMillis() - (double)start)/1000);
	}
	
	public static String dateToStr(Date date, String format) {
		String dataString = "";
		if (date != null) {
			String DATE_FORMAT = format;
			java.text.SimpleDateFormat sdf =
				new java.text.SimpleDateFormat(DATE_FORMAT);
			dataString = sdf.format(date);
		}

		return dataString;
	}
	
	public static String dateToStrDb(Date date) {
		return dateToStr(date, "yyyy-MM-dd");
	}
	
	public static Date parseDate(String dateString, String format) {
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(format);
		
		try {
			if(dateString != null)
				return sdf.parse(dateString);
			
	    } catch (ParseException e) {
	    	e.printStackTrace();
	    }
		
		return null;
	}
	
	public static BufferedImage decodeToImage(String imageString) {
		BufferedImage image = null;
        byte[] imageByte;
        
        try {
            BASE64Decoder decoder = new BASE64Decoder();
            imageByte = decoder.decodeBuffer(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return image;
	}
	
	public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
 
        try {
            ImageIO.write(image, type, bos);
            byte[] imageBytes = bos.toByteArray();
 
            BASE64Encoder encoder = new BASE64Encoder();
            imageString = encoder.encode(imageBytes);
 
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
}
