package com.aia.pdfGenerator.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.UUID;

import org.json.simple.JSONObject;

import com.aia.common.model.AppForm;
import com.aia.common.model.PolicyInfo;

public class ESBUtil {

	private static final String PROPERTIES_ESB_RETRIEVE_CUST_INFO = "RETRIEVECUSTINFO";
	private static final String PROPERTIES_ESB_GET_DUMMYPROFILE = "GETDUMMYPROFILE";
	private static final String PROPERTIES_ESB_CREATE_REGISTRATION = "CREATEREGISTRATION";

public static boolean isRegistered(PolicyInfo policyInfo, AppForm appForm , String trxno){
	boolean isReg = false;
	
	//To retrieve the Customer info
	String requestCustomerInfo = createCustomerInfoJSON(policyInfo, appForm ,trxno);
	String retInfo = esbService(requestCustomerInfo , 2);
	
	if("success".equalsIgnoreCase(retInfo)){
		isReg = true;
	}else if(retInfo.contains("No Record Found")){
		isReg = false;
	}
	
	if(!isReg){
		String dummyProfileJSON = createDummyProfileJSON(policyInfo, appForm , trxno);
		String dummyInfo =  esbService(dummyProfileJSON,3);
		if("success".equalsIgnoreCase(dummyInfo)){
			isReg = true;
		}else if(dummyInfo.contains("No Record Found")){
			isReg = false;
		}
				
	}
	return isReg;
}
	
public static String createPreRegKey(PolicyInfo policyInfo, AppForm appForm , String trxno){
	String preRegKey = "";
	String requestPreRegInfo = createPreRegJSON(policyInfo, appForm, trxno);
	preRegKey =  esbService(requestPreRegInfo,4);
	
	
	return preRegKey;
}

public static String esbService(String json , int type) {
		String respStr = "";
		String result = "";
	    String esbURL = "";
	    boolean esbSuccess = true;	
		URL url;
	    HttpURLConnection conn = null;
	    ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
	    System.out.println("[ESBUtil][esbService] Json String ["+type+"] : "+json);
		 switch(type) {
	    	case 2:
	    		//esbURL = "http://kuldculwis01a:8255/rest/AIA_Common_FAP21.AetnaI3sdb.retrieveCustomerInfo.restAPI.retrieveCustomerInfo/_post";
	    		esbURL = bundle.getString(PROPERTIES_ESB_RETRIEVE_CUST_INFO);
	    		break;
	    	case 3:
	    		//esbURL = "http://kuldculwis01a:8255/rest/AIA_Common_FAP21.AetnaI3sdb.getDummyProfile.restAPI/_post";
	    		esbURL = bundle.getString(PROPERTIES_ESB_GET_DUMMYPROFILE);
	    		break;
	    	case 4:
	    		//esbURL = "http://kuldculwis01a:8255/rest/AIA_MyAIA_Registration.restAPI.createPreRegistration/_post";
	    		esbURL = bundle.getString(PROPERTIES_ESB_CREATE_REGISTRATION);
	    		break;
	    	case 1:
	        	default:
	        	esbURL = "";
	    }
		
		
		try 
		{
		    url = new URL(esbURL);
		    conn = (HttpURLConnection) url.openConnection();
		    conn.setDoOutput(true);
		    conn.setRequestMethod("POST");
		    conn.setRequestProperty("Content-Type", "application/json");

		    OutputStream os = conn.getOutputStream();
		    os.write(json.getBytes());
		    os.flush();

/*		    if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
		        throw new RuntimeException("Failed : HTTP error code : "
		                + conn.getResponseCode());
		    }
*/
		    BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

		    String output;
		    StringBuilder strPol = new StringBuilder();
		    while ((output = br.readLine()) != null) {
				strPol.append(output);
			}
		    result = strPol.toString();
		    System.out.println("RESULT FROM ESBCALL :"+result);
		    final  org.json.JSONObject obj = new org.json.JSONObject(result);
		    
		    if(type == 4){
		    	System.out.println(" JSON Keys :"+obj.keys());
				Iterator<?> keys = obj.keys();
				  while( keys.hasNext() ) {
						 String key = (String)keys.next();
						    System.out.println(" JSON Key :"+key);
						    if ( "errorDescription".equalsIgnoreCase(key)) {
						    	respStr = "Err From ESB :  "+obj.getString(key);
						    }else if("TokenID".equalsIgnoreCase(key)){
						    	respStr = "TokenID From ESB :  "+obj.getString(key);
						    }
				  }

		    }else{
			    Iterator<?> keys = obj.keys();
			    
			    while( keys.hasNext() ) {
				    String key = (String)keys.next();
				    System.out.println(" JSON Key :"+key);
				    if ( "errorDescription".equalsIgnoreCase(key)) {
				   /* if ( "errorDescription".equalsIgnoreCase(key) && obj.getString(key).contains("No record found")) {
				    	respStr = "No record found";
				    }*/
				    	respStr = "Err From ESB :  "+obj.getString(key);
				    }else if("UserID".equalsIgnoreCase(key)){
				    	 respStr = "success";
				    }
				   
				}
		    }
		    System.out.println("Response  from ESB : "+respStr);
		    conn.disconnect();
		}
		catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
		return respStr;	    
	}
	
public static String createCustomerInfoJSON(PolicyInfo policyInfo, AppForm appForm , String trxno) {
	
	String jsonStr = "";
	JSONObject obj = new JSONObject();
		try
		{
			Date dNow = new Date( );
			SimpleDateFormat ft =  new SimpleDateFormat ("ddMMyyyyhhmmss");
			System.out.println("Current Date: " + ft.format(dNow));
		
			JSONObject headerJSON = new JSONObject();
			headerJSON.put("trxnRefNo", trxno);
			headerJSON.put("channel", "eComm");
			headerJSON.put("reqDateTime", ft.format(dNow));
			headerJSON.put("language", "en");
			obj.put("reqHeader", headerJSON);
			
			JSONObject bodyBlock = new JSONObject();
			bodyBlock.put("userID", "");
			bodyBlock.put("nric", appForm.getMykadNo());
			//bodyBlock.put("userName", appForm.getInsuredName());
			obj.put("reqBody", bodyBlock);
			
			System.out.println("JSON " +obj.toJSONString());
			
			jsonStr = obj.toJSONString();
			
		} 
		catch(Exception jsonEx) {
			System.out.println("Error while creating JSON :"+jsonEx);
		}
		return jsonStr;
}



public static String createPreRegJSON(PolicyInfo policyInfo, AppForm appForm , String trxno) {
	
	String jsonStr = "";
	JSONObject obj = new JSONObject();
	
		try
		{
			Date dNow = new Date( );
			SimpleDateFormat ft =  new SimpleDateFormat ("ddMMyyyyhhmmss");
			System.out.println("Current Date: " + ft.format(dNow));
			
			SimpleDateFormat dobft =  new SimpleDateFormat ("yyyy-MM-dd");
			System.out.println("Current Date: " + dobft.format(appForm.getDateOfBirth()));
			
			JSONObject headerJSON = new JSONObject();
			headerJSON.put("trxnRefNo", trxno);
			headerJSON.put("channel", "eComm");
			headerJSON.put("reqDateTime", ft.format(dNow));
			headerJSON.put("language", "en");
			obj.put("reqHeader", headerJSON);
			
			JSONObject bodyBlock = new JSONObject();
			bodyBlock.put("userId", appForm.getMykadNo());
			bodyBlock.put("userName", appForm.getInsuredName());
			bodyBlock.put("NRICNew", appForm.getMykadNo());
			bodyBlock.put("DOB", dobft.format(appForm.getDateOfBirth()));
			bodyBlock.put("Email", policyInfo.getInsuredEmail());
			bodyBlock.put("PolicyNumber", policyInfo.getPolicyNo());
			bodyBlock.put("LOB", "CV");
			bodyBlock.put("MobileNumber", appForm.getTelNo());
			bodyBlock.put("Portal", "MYAIA");
			bodyBlock.put("Channel", "eComm");
			obj.put("reqBody", bodyBlock);
			
			System.out.println("JSON " +obj.toJSONString());
			
			jsonStr = obj.toJSONString();
			
		} 
		catch(Exception jsonEx) {
			System.out.println("Error while creating JSON :"+jsonEx);
		}
		return jsonStr;
}


public static String createDummyProfileJSON(PolicyInfo policyInfo, AppForm appForm, String trxno) {
	
	String jsonStr = "";
	JSONObject obj = new JSONObject();
	
		try
		{
			Date dNow = new Date( );
			SimpleDateFormat ft =  new SimpleDateFormat ("ddMMyyyyhhmmss");
			System.out.println("Current Date: " + ft.format(dNow));
			
			JSONObject headerJSON = new JSONObject();
			headerJSON.put("trxnRefNo", trxno);
			headerJSON.put("channel", "eComm");
			headerJSON.put("reqDateTime", ft.format(dNow));
			headerJSON.put("language", "en");
			obj.put("reqHeader", headerJSON);
			
			JSONObject bodyBlock = new JSONObject();
//			bodyBlock.put("TokenID", "f18e5235-e270-4f84-8235-6f50614b65f30705201815114972790");
			bodyBlock.put("TokenID", "");
			bodyBlock.put("ActivationStatus", "P");
			bodyBlock.put("Nric", appForm.getMykadNo());
			obj.put("reqBody", bodyBlock);
			
			System.out.println("JSON " +obj.toJSONString());
			
			jsonStr = obj.toJSONString();
			
		} 
		catch(Exception jsonEx) {
			System.out.println("Error while creating JSON :"+jsonEx);
		}
		return jsonStr;
}
	
	public static void main(String args[]) {
		Date dNow = new Date( );
		SimpleDateFormat ft =  new SimpleDateFormat ("ddMMyyyyhhmmss");
		 UUID uuid = UUID.randomUUID();

		 System.out.println("Rest Webservice API Test : "+"eCom"+ft.format(dNow)+uuid.toString().substring(0, 7));
		
		/*boolean isReg = isRegistered(policyInfo,appForm);
		if(!isReg){
			String preRegKey = createPreRegKey();
			System.out.println("Finally..."+preRegKey);
		}*/
//		System.out.println("Finally..."+isReg);
	}
}
