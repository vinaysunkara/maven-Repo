package com.aia.pdfGenerator.util;

import ho.aia.utility.host.PasswordFile;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.metadata.IIOInvalidTreeException;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageOutputStream;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;

import com.aia.common.db.DBCommon;
import com.aia.common.model.AppForm;
import com.aia.common.model.PolicyInfo;
import com.aia.utility.EmailUtility;
import com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet;
import com.sun.media.imageio.plugins.tiff.TIFFDirectory;
import com.sun.media.imageio.plugins.tiff.TIFFField;
import com.sun.media.imageio.plugins.tiff.TIFFTag;

public class CommonFileUtil {
	private final String hardCopy = "H";
	private final String softCopy = "S";
	private final String taxInvoice = "F";
	private final String debitNote = "D";
	private final String creditNote = "C";
	private final String selfBill = "B";
	private final String selfBill_claim = "A";
	private final String adhocPath = "Adhoc";
	private final String batchPath = "Batch";
	private final String fileExt = ".csv";
	private final String logExt = ".log";
	private final int maxTaxInvPerFile = 400;
	
	private final String csvAddInd = "A";
	private final String csvUpdateInd = "U";
	
	private final String t2File = "_EX_";
	private final String t2FileYearly = "_YEARLY_";
	
	private final String polCovType = "P";
	private final String appCovType = "A";
	
	private final String afNominee = "N";
	private final String afTrustee = "T";
	
	public final static String CON = "CON";
	public final static String PDS = "PDS";
	public final static String APF = "APF";
	
	private final String enable = "Y";
	private final String disable = "N";
	
	public List<String> getGAMSTXT(String uniqueID, String processYear, String inputType, String srcFileName) {
		DBCommon dc = new DBCommon();
		List<String> processFile = new ArrayList<String>();
		FileOutputStream out = null;
		InputStream in = null;
		boolean isAdhoc = false;
		boolean isBatch = false;
		boolean isProcess = true;
		
		try {
			System.out.println("--------------------------------[" + new java.util.Date() + "] getGAMSTXT(" + uniqueID + ", " + processYear + ") Start --------------------------------");
			ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
			PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "GAMTXT", "USER", "PASSWD");
			
			
			if ("B".equalsIgnoreCase(inputType)) {
				isBatch = true;
			} else if ("A".equalsIgnoreCase(inputType)) {
				isAdhoc = true;
			}
			
			String srcPath = bundle.getString("CSVFileDirectory");
//			String srcPath = "smb://kuldcqwxcm01/UAT/xcom/Outfile/GAMS/Print/";
//			String srcPath = "smb://kuldcqwxcm01/Test/xcom/outfile/GAMS/Print/";
			String autoBatchDir = bundle.getString("AutoBatchDirectory");
			
			if (isBatch) {
				srcPath += batchPath + autoBatchDir; /* auto batch folder */
			} else if (isAdhoc) {
				srcPath += adhocPath + "/";
			}
			
			String targetPath = getRootPath("invTxt\\" + uniqueID + "\\");
			
//			jcifs.Config.setProperty("jcifs.smb.client.disablePlainTextPasswords", "false");
			
			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", pwdFile.getUserId(), pwdFile.getPassword());
//			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "yapdcom", "ANWeare4");
//			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "kapdcom", "ANWeare4");
			
			SmbFile sFile = new SmbFile(srcPath, auth);
			
			for (SmbFile f : sFile.listFiles()) {
				if (f.isFile()) {
					if (isAdhoc) {
						if (!f.getName().equalsIgnoreCase(srcFileName + fileExt)) {
							isProcess = false;
						} else {
							isProcess = true;
						}
					}
					
					if (isProcess) {
						processFile.add(f.getName());
						in = f.getInputStream();
						
						File outFile = new File(targetPath);
						
						if (!outFile.isDirectory()) {
							outFile.mkdirs();
						}
						
						outFile = new File(targetPath + f.getName());
						
						if (!outFile.exists()) {
							outFile.createNewFile();
							
							out = new FileOutputStream(outFile);
							
			                byte[] b = new byte[8192];
			                int n;
			                while(( n = in.read( b )) > 0 ) {
			                    out.write( b, 0, n );
			                }
			                in.close();
			                
			                out.close();
			                
			                System.out.println("--------------------------------[" + new java.util.Date() + "] getGAMSTXT() addPrintSummary Start --------------------------------");
			                boolean isAdded = dc.addPrintSummary(uniqueID, f.getName(), processYear, isBatch?batchPath:adhocPath);
			                System.out.println("--------------------------------[" + new java.util.Date() + "] getGAMSTXT() addPrintSummary [" + isAdded + "] End --------------------------------");				    
						}
					}
				}
			}
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] getGAMSTXT(" + uniqueID + ", " + processYear + ") End --------------------------------");
		} catch (Exception ex) {
			System.out.println("[CommonFileUtil.java] [getGAMSTXT] Exception --> " + ex.toString());
			ex.printStackTrace();
			
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {}
		}
		
		return processFile;
	}
	
	public boolean archiveTXT(String uniqueID, String processFile, int fileSeqNo, String inputType) {
		FileOutputStream out = null;
		InputStream in = null;
		DBCommon dc = new DBCommon();
		
		try {
			System.out.println("--------------------------------[" + new java.util.Date() + "] archiveTXT Start --------------------------------");
			ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
			PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "GAMTXT", "USER", "PASSWD");
			String path = bundle.getString("CSVFileDirectory");
			String autoBatchDir = bundle.getString("AutoBatchDirectory");
					
//			String path = "smb://kuldcqwxcm01/UAT/xcom/Outfile/GAMS/Print/";
			
			String archivePath = "";
			if ("B".equalsIgnoreCase(inputType)) {
				archivePath += path + batchPath + "/archive/";
			} else if ("A".equalsIgnoreCase(inputType)) {
				archivePath += path + adhocPath + "/archive/";
			}
			
			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", pwdFile.getUserId(), pwdFile.getPassword());
//			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "yapdcom", "ANWeare4");
//			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "kapdcom", "ANWeare4");
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] House keep file Start --------------------------------");
			SmbFile aFile = new SmbFile(archivePath, auth);
			
			if (!aFile.isDirectory()) {
				aFile.mkdir();
			}
			
			for (SmbFile arcFile : aFile.listFiles()) {
				Date txtLastModified = new Date(arcFile.lastModified());
				long diff = new Date().getTime() - txtLastModified.getTime();
			    
				if(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) > 7) {
					System.out.println("--------------------------------[" + new java.util.Date() + "] Delete [" + arcFile.getName() + "][" + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) + "] --------------------------------");
					arcFile.delete();
				}				
			}
			System.out.println("--------------------------------[" + new java.util.Date() + "] House keep file End --------------------------------");
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] Archive file Start --------------------------------");
			
			if ("B".equalsIgnoreCase(inputType)) {
				path += batchPath + autoBatchDir; /* auto batch folder */
			} else if ("A".equalsIgnoreCase(inputType)) {
				path += adhocPath + "/";
			}
			
			SmbFile sFile = new SmbFile(path + processFile, auth);
			
			if (sFile.isFile()) {
				String arcFileName = sFile.getName() + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + fileExt;
				SmbFile archiveFile = new SmbFile(archivePath + arcFileName, auth);
				
				if (archiveFile.isFile()) {
					archiveFile.delete();
				}
				
				SmbFile b = new SmbFile(archivePath, arcFileName, auth);
				sFile.renameTo(b);
				
				int summSeqno = 0;
				if ("B".equalsIgnoreCase(inputType)) {
					summSeqno = ++fileSeqNo;
				} else if ("A".equalsIgnoreCase(inputType)) {
					summSeqno = dc.getPrintSummSeqNo(uniqueID);					
				}
				
				dc.updatePrintSummary(uniqueID, sFile.getName(), arcFileName, summSeqno);				
			}
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] Archive file End --------------------------------");
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] archiveTXT End --------------------------------");
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				
				if (in != null) {
					in.close();
				}
			} catch (Exception e) {}
		}
	}
	
	public void removeWorkingTXT (String uniqueID) {
		try {
			String targetPath = getRootPath("invTxt\\" + uniqueID + "\\");
			
			File directory = new File(targetPath);
			 
	    	//make sure directory exists
	    	if(directory.exists()){
	    		delete(directory);
	        }else{
	        	System.out.println("Directory does not exist.");
	    	//	System.exit(0);
	        }
		} catch (Exception ex) {
			ex.printStackTrace();			
		}
	}
		
	public void AddData2ProcessTbl(String processID, List<String> processFileList, String processYear) {
		DBCommon dc = new DBCommon();
		boolean isProcessSuccess = false;
		
		try {
			for (int i=0; i<processFileList.size(); i++) {
				dc.validateTableByYear(processYear);
				isProcessSuccess = dc.addData2TaxInvTable(processID, i+1, processFileList.get(i), processYear);
				
				if (!isProcessSuccess) {
					dc.updatePrintSummaryStatus(processID, i+1, "E", "Unable to populate data to database table");
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void addXMLData2ProcessTbl(String uniqueId, PolicyInfo policyInfo, AppForm appForm) {
		DBCommon dc = new DBCommon();
		boolean isProcessSuccess = false;
		
		try {
			if(!isBlank(policyInfo) && dc.addData2PolicyTable(uniqueId, policyInfo)) {
				if(!isBlank(policyInfo.getCoverages()) && policyInfo.getCoverages().size() > 0)
					isProcessSuccess = dc.addData2CoverageTable(uniqueId, policyInfo, null);
			}
			
			if(!isBlank(appForm) && dc.addData2AppFormTable(uniqueId, appForm)) {				
				// process related entities
				if(isProcessSuccess) {
					if(!isBlank(appForm.getNominees()) && appForm.getNominees().size() > 0)
						isProcessSuccess = dc.addData2EntityTable(uniqueId, appForm.getNominees(), getAfNominee());
					
					if(!isBlank(appForm.getTrustees()) && appForm.getTrustees().size() > 0)
						isProcessSuccess = dc.addData2EntityTable(uniqueId, appForm.getTrustees(), getAfTrustee());
				}
			}
			
			if (!isProcessSuccess) {
				dc.updatePrintSummaryStatus(uniqueId, 1, "E", "Unable to populate data to database table");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	// for ad-hoc checking for add or update records (mainly for GSTS/GAMS)
	public String getCSVFileIndicator(String processID, List<String> processFileList) {
		Date startDate = new java.util.Date();
		CommonFileUtil cu = new CommonFileUtil();
		Scanner sc = null;
		String csvIndicator = "";
		
		System.out.println("-------------------------------- [" + startDate + "] [CommonUtil] getCSVFileIndicator Start --------------------------------");
		
		try {
			for (int i=0; i<processFileList.size(); i++) {
				sc = new Scanner(new File(cu.getRootPath("invTxt\\" + processID + "\\" + processFileList.get(i))), "UTF-8");
				
				while(sc.hasNextLine()) {
					String lineStr = sc.nextLine();
					
					if(lineStr.endsWith("|A")) {
						csvIndicator = csvAddInd;
						break;
					}
					
					if(lineStr.endsWith("|U")) {
						csvIndicator = csvUpdateInd;
						break;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		System.out.println("-------------------------------- [" + startDate + "][" + new java.util.Date() + "] [CommonUtil] getCSVFileIndicator End --------------------------------");
		
		return csvIndicator;
	}
	
	public String getCurrentClassPath() {
		return this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();  
    }
	
	public String getRootPath(String path) {
		path = getCurrentClassPath() + "../../" + path;
		String normalizedName = FilenameUtils.normalize(path, true); 
		
		return normalizedName;
	}
	
	public static void delete(File file) throws IOException {
		if(file.isDirectory()) {
			//directory is empty, then delete it
	    	if(file.list().length==0){
	    		file.delete();
	    		System.out.println("Directory is deleted : " + file.getAbsolutePath());
	    	}else{
	    		//list all the directory contents
	        	String files[] = file.list();
	 
	        	for (String temp : files) {
	        		//construct the file structure
	        	    File fileDelete = new File(file, temp);
	 
	        	    //recursive delete
	        	    delete(fileDelete);
	        	}
	 
	        	//check the directory again, if empty then delete it
	        	if(file.list().length==0){
	        		file.delete();
//	        	    System.out.println("Directory is deleted : " + file.getAbsolutePath());
	        	}
	    	}
	 
		}else{
			//if file, then delete it
	    	file.delete();
//	    	System.out.println("File is deleted : " + file.getAbsolutePath());
    	}
	}
	
	public String addErrorLogToCSVFolder(String duplicateStr, String processID, String processYear, int seqNo, 
			String processFile, String inputType) {
		
		SmbFileOutputStream sfos = null;
		FileOutputStream out = null;
		InputStream in = null;
		String fullErrorPathAndFilename = "";
		
		try {
			System.out.println("--------------------------------[" + new java.util.Date() + "] addErrorLogToCSVFolder Start --------------------------------");
			ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
			PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "GAMTXT", "USER", "PASSWD");
			String path = bundle.getString("CSVFileDirectory");
			
			String errorPath = "";
			
			if ("B".equalsIgnoreCase(inputType)) {
				errorPath += path + batchPath + "/error/";
				
			} else if ("A".equalsIgnoreCase(inputType)) {
				errorPath += path + adhocPath + "/error/";
			}
			
			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", pwdFile.getUserId(), pwdFile.getPassword());
			
			SmbFile errorFolder = new SmbFile(errorPath, auth);
			
			if(!errorFolder.isDirectory()) {
				errorFolder.mkdir();
			}
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String currentTime = sdf.format(new Date());
			
			SmbFile sFile = new SmbFile(errorPath + "duplicate_" + currentTime + logExt, auth);
			sFile.connect(); //Try to connect
			
			String contents = "ProcessID: " + processID + ", Year: " + processYear + ", SummarySeqNo: " + seqNo + "\r\n";
			contents += "FileName: " + processFile + ", Type: " + inputType + "\r\n";
			contents += duplicateStr;
			
			// get the content in bytes
			byte[] contentInBytes = contents.getBytes();
			
			sfos = new SmbFileOutputStream(sFile, true);
			
			sfos.write(contentInBytes);
			sfos.flush();
			
			// create temporary file for email attachment -- start
			in = sFile.getInputStream();
			
			String targetPath = getRootPath("invTxt/" + processID + "/");
			fullErrorPathAndFilename = targetPath + sFile.getName();
			
			File outFile = new File(targetPath);
			
			if (!outFile.isDirectory()) {
				outFile.mkdirs();
			}
			
			outFile = new File(fullErrorPathAndFilename);
			
			if (!outFile.exists()) {
				outFile.createNewFile();
				
				out = new FileOutputStream(outFile);
				
                byte[] b = new byte[8192];
                int n;
                while(( n = in.read( b )) > 0 ) {
                    out.write( b, 0, n );
                }
                in.close();
                
                out.close();				    
			}
			// create temporary file for email attachment -- end
			
			System.out.println("Error contents: " + contents);
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] addErrorLogToCSVFolder End --------------------------------");
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try {
				if (sfos != null) sfos.close();
				if (out != null) out.close();
				if (in != null) in.close();
				
			} catch (Exception e) {}
		}
		
		return fullErrorPathAndFilename;
	}
	
	public void sendEmailForDuplication(String errorPath) {
		try {
			System.out.println("--------------------------------[" + new java.util.Date() + "] sendEmailForDuplication Start --------------------------------");
			
			EmailUtility email = new EmailUtility();
			
			email.setEmailTitle("Print Agent - Duplicated Tax Invoices Received");
			email.setSendFrom("PrintingAgent");
			email.setSendTo("MuhammadAzfar.Mustafa@aia.com,Ivan-JJ.Wong@aia.com,ChenKhee.Ho@aia.com");
			email.setSendCC("BoonWee.Lim@aia.com,Sindy-HK.Sim@aia.com");
			//email.setSendTo("ChanShi.Chai@aia.com");
			//email.setSendTo("sazarulizam.mdsaad@aia.com");
			//email.setSendCC("sazarulizam.mdsaad@aia.com,sazarulizam.mdsaad@aia.com");
			
			email.setEmailContents("Dear Team," +
					"\n\nDuplicated tax invoices received from Print Agent. Please check attached file." +
					"\n\nSent From," +
					"\nPrint Agent");
			
			email.setAttachmentPath(errorPath);
			
			email.sendEmail();
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] sendEmailForDuplication End --------------------------------");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public boolean isBlank(Object object) {
		if(object == null || "".equals(object.toString().trim()))
			return true;
		else
			return false;
	}
	
	public String getTemplatePath() {
		String path = "";
		
		ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
		path = bundle.getString("TemplateDirectory");
		
		return path;
	}
	
	public String getTemplCompCode(String companyCode) {
		String templCompCode = "";
		
		if("016".equalsIgnoreCase(companyCode)) templCompCode = "BHD";
		else if("072".equalsIgnoreCase(companyCode)) templCompCode = "TKF";
		
		return templCompCode;
	}
	
	public synchronized BigDecimal handleBigDecimal(BigDecimal aNum) {
		if (aNum == null) {
			return new BigDecimal(0);
		} else {
			return aNum;
		}
	}
	
	public BigDecimal formatBigDecimal(BigDecimal value, int scale) {
		return handleBigDecimal(value).setScale(scale, BigDecimal.ROUND_HALF_UP);
	}
	
	public BigDecimal normalFormat(BigDecimal value) {
		return formatBigDecimal(value, 2);
	}
	
	public String getNumberFormat(BigDecimal value) {
		if(isBlank(value)) return "";
		
		DecimalFormat decimalFormat = new DecimalFormat("#.00");
		decimalFormat.setGroupingUsed(true);
		decimalFormat.setGroupingSize(3);
		
		return decimalFormat.format(normalFormat(value));
	}
	
	public List<String> getTextList(String text, int maxLength) {
		List<String> textList = new ArrayList<String>();
		
		String[] parts = text.split(" ");
		StringBuilder sb = new StringBuilder();
		
		for(String part: parts) {
			if(sb.length() + part.length() > maxLength) {
				textList.add(sb.toString().substring(0, sb.toString().length() - 1));
				sb = new StringBuilder();
			}
			
			sb.append(part + " ");
		}
		
		if(sb.length() > 0) {
			textList.add(sb.toString());
		}
		
		return textList;
	}
	
	public List<ByteArrayOutputStream> pdfToTiff(ByteArrayOutputStream pdfBaos) throws Exception {
		PDDocument document = null;
		ImageOutputStream ios = null;
		ImageWriter writer = null;
		
		List<ByteArrayOutputStream> tiffBaosList = new ArrayList<ByteArrayOutputStream>();
		
		try {
			InputStream fis = new ByteArrayInputStream(pdfBaos.toByteArray());
			document = PDDocument.load(fis);
			
			PDFRenderer pdfRenderer = new PDFRenderer(document);
			
			for(int i = 0; i < document.getPages().getCount(); i++) {
				BufferedImage imgPage = pdfRenderer.renderImageWithDPI(i, 250, ImageType.BINARY);
				
				// Get the writer
				Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("tiff");

				if (!writers.hasNext()) {
				    System.out.println("No writer for: tiff, rescanning...");
				    ImageIO.scanForPlugins();
				    writers = ImageIO.getImageWritersByFormatName("tiff");
				}

				writer = writers.next();
				
				//ImageWriter writer = ImageIO.getImageWritersByFormatName("tiff").next();
				
				// Get the default image metadata
				ImageTypeSpecifier imageType = ImageTypeSpecifier.createFromRenderedImage(imgPage);
				IIOMetadata imageMetadata = writer.getDefaultImageMetadata(imageType, null);
				imageMetadata = setDPIViaAPI(imageMetadata);				
				
				ByteArrayOutputStream bytes = new ByteArrayOutputStream();
				ios = ImageIO.createImageOutputStream(bytes);
				writer.setOutput(ios);
				
				ImageWriteParam writeParam = writer.getDefaultWriteParam();
				
				writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
				writeParam.setCompressionType("CCITT T.6");
				
				IIOImage iioImage = new IIOImage(imgPage, null, imageMetadata);
				writer.write(imageMetadata, iioImage, writeParam);
				
				ios.close();
				writer.dispose();
				
				tiffBaosList.add(bytes);
			}
		} finally {
			if(document != null) document.close();
		}
		
		return tiffBaosList;
	}
	
	private static IIOMetadata setDPIViaAPI(IIOMetadata imageMetadata) throws IIOInvalidTreeException {
		long DPI_X = 200;
		long DPI_Y = 200;
		
		// Derive the TIFFDirectory from the metadata
		TIFFDirectory dir = TIFFDirectory.createFromMetadata(imageMetadata);
		
		// Get {X,Y} Resolution tags
		BaselineTIFFTagSet base = BaselineTIFFTagSet.getInstance();
		TIFFTag tagXRes = base.getTag(BaselineTIFFTagSet.TAG_X_RESOLUTION);
		TIFFTag tagYRes = base.getTag(BaselineTIFFTagSet.TAG_Y_RESOLUTION);
		TIFFTag tagPhoto = base.getTag(BaselineTIFFTagSet.TAG_PHOTOMETRIC_INTERPRETATION);
		
		// Create {X,Y} Resolution fields
		TIFFField fieldXRes = new TIFFField(tagXRes, TIFFTag.TIFF_RATIONAL, 1, new long[][] {{DPI_X, 1}});
		TIFFField fieldYRes = new TIFFField(tagYRes, TIFFTag.TIFF_RATIONAL, 1, new long[][] {{DPI_Y, 1}});
		TIFFField fieldPhoto = new TIFFField(tagPhoto, BaselineTIFFTagSet.PHOTOMETRIC_INTERPRETATION_WHITE_IS_ZERO);
		
		// Append {X,Y} Resolution fields to directory
		dir.addTIFFField(fieldXRes);
		dir.addTIFFField(fieldYRes);
		dir.addTIFFField(fieldPhoto);
		
		// Convert to metadata object and return
		return dir.getAsMetadata();
	}
	
	public ByteArrayOutputStream pdfToCombinedTiff(ByteArrayOutputStream pdfBaos) throws Exception {
		PDDocument document = null;
		ByteArrayOutputStream tiffBaos = null;
		
		try {
			/*InputStream fis = new ByteArrayInputStream(pdfBaos.toByteArray());
			document = PDDocument.load(fis);
			
			PDFRenderer pdfRenderer = new PDFRenderer(document);
			
			BufferedImage image[] = new BufferedImage[document.getPages().getCount()-1];
			BufferedImage imgPage0 = null;
			
			for(int i = 0; i < document.getPages().getCount(); i++) {				
				if (i == 0) {
					imgPage0 = pdfRenderer.renderImageWithDPI(i, 200, ImageType.BINARY);
					
				} else {
					BufferedImage imagePDF = pdfRenderer.renderImageWithDPI(i, 200, ImageType.BINARY);
					image[i-1] = imagePDF;
				}
			}
			
			TIFFEncodeParam params = new TIFFEncodeParam();
			tiffBaos = new ByteArrayOutputStream();
			
			ImageEncoder encoder = ImageCodec.createImageEncoder("tiff", tiffBaos, params);
			
			List<BufferedImage> imageList = new ArrayList<BufferedImage>();
			
			for(int i = 0; i < document.getPages().getCount() - 1; i++) {
				imageList.add(image[i]);
			}
			
			TIFFField xRes = new TIFFField(282, TIFFField.TIFF_RATIONAL, 1, new long[][] {{ 200, 1 }});
			TIFFField yRes = new TIFFField(283, TIFFField.TIFF_RATIONAL, 1, new long[][] {{ 200, 1 }});
			
			params.setExtraFields(new TIFFField[] { xRes, yRes });
			
			params.setExtraImages(imageList.iterator());
			params.setCompression(TIFFEncodeParam.COMPRESSION_GROUP4);
			
			encoder.encode(imgPage0);
			tiffBaos.close();*/
			
		} finally {
			if(document != null) document.close();
		}
		
		return tiffBaos;
	}
	
	public void generateFile(ByteArrayOutputStream baos, String filePath) {
		try {
			InputStream fis = new ByteArrayInputStream(baos.toByteArray());
			
			OutputStream debugFile = new FileOutputStream(new File(filePath));
			byte[] bytes = new byte[1024];
			int read = 0;
			
			while ((read = fis.read(bytes)) != -1) {
				debugFile.write(bytes, 0, read);
			}
			
			fis.close();
			
		} catch(Exception ex) {
			System.out.println("[CommonFileUtil.generateFile] Exception: " + ex.toString());
			ex.printStackTrace();
		}
	}

	public String getHardCopy() {
		return hardCopy;
	}

	public String getSoftCopy() {
		return softCopy;
	}

	public String getTaxInvoice() {
		return taxInvoice;
	}

	public String getDebitNote() {
		return debitNote;
	}

	public String getCreditNote() {
		return creditNote;
	}

	public String getSelfBill() {
		return selfBill;
	}

	public String getSelfBill_claim() {
		return selfBill_claim;
	}

	public int getMaxTaxInvPerFile() {
		return maxTaxInvPerFile;
	}
	
	public String getCsvAddIndicator() {
		return csvAddInd;
	}
	
	public String getCsvUpdateIndicator() {
		return csvUpdateInd;
	}

	public String getT2File() {
		return t2File;
	}

	public String getT2FileYearly() {
		return t2FileYearly;
	}

	public String getPolCovType() {
		return polCovType;
	}

	public String getAppCovType() {
		return appCovType;
	}

	public String getAfNominee() {
		return afNominee;
	}

	public String getAfTrustee() {
		return afTrustee;
	}

	public String getEnable() {
		return enable;
	}

	public String getDisable() {
		return disable;
	}
}
