package com.aia.reportsandcorrespondences.experiencerefundletter.model;

public class ExperienceRefundLetter {

	private String empOrPolicyHolder_1;
	private String address_2;
	private String policyNumber_3;
	private String policyPeriodFrom_4;
	private String policyPeriodTo_5;
	private String datePrepared_6;
	private String ergGroup_7;
	private String ttlPremiumHealth_8;
	private String ttlPremiumLife_9;
	private String grandTtl_10;
	private String ttlClaimHealth_11;
	private String ttlClaimLife_12;
	private String lossesBroughtForwardHealth_13;
	private String lossesbroughtForwardLife_14;
	private String refundRateHealth_15;
	private String refundRateLife_16;
	private String retentionRateHealthGreter50Per_17;
	private String retentionRateLifeGreter50Per_18;
	private String retentionRateHealthLess50Per_19;
	private String retentionRateLifeLess50Per_20;
	private String retentionAmntHealth_21;
	private String retentionAmountLife_22;
	private String ttaClaimAndLossesHealth_23;
	private String ttlClaimandLossesLife_24;
	private String amntRefundOrLossesHealth_25;
	private String amntRefundOrLossesLife_26;
	private String ttlAmntRefundOrLosses_27;
	private String cnNo_28;
	private String accountCode_29;

	public String getEmpOrPolicyHolder_1() {
		return empOrPolicyHolder_1;
	}

	public void setEmpOrPolicyHolder_1(String empOrPolicyHolder_1) {
		this.empOrPolicyHolder_1 = empOrPolicyHolder_1;
	}

	public String getAddress_2() {
		return address_2;
	}

	public void setAddress_2(String address_2) {
		this.address_2 = address_2;
	}

	public String getPolicyNumber_3() {
		return policyNumber_3;
	}

	public void setPolicyNumber_3(String policyNumber_3) {
		this.policyNumber_3 = policyNumber_3;
	}

	public String getPolicyPeriodFrom_4() {
		return policyPeriodFrom_4;
	}

	public void setPolicyPeriodFrom_4(String policyPeriodFrom_4) {
		this.policyPeriodFrom_4 = policyPeriodFrom_4;
	}

	public String getPolicyPeriodTo_5() {
		return policyPeriodTo_5;
	}

	public void setPolicyPeriodTo_5(String policyPeriodTo_5) {
		this.policyPeriodTo_5 = policyPeriodTo_5;
	}

	public String getDatePrepared_6() {
		return datePrepared_6;
	}

	public void setDatePrepared_6(String datePrepared_6) {
		this.datePrepared_6 = datePrepared_6;
	}

	public String getErgGroup_7() {
		return ergGroup_7;
	}

	public void setErgGroup_7(String ergGroup_7) {
		this.ergGroup_7 = ergGroup_7;
	}

	public String getTtlPremiumHealth_8() {
		return ttlPremiumHealth_8;
	}

	public void setTtlPremiumHealth_8(String ttlPremiumHealth_8) {
		this.ttlPremiumHealth_8 = ttlPremiumHealth_8;
	}

	public String getTtlPremiumLife_9() {
		return ttlPremiumLife_9;
	}

	public void setTtlPremiumLife_9(String ttlPremiumLife_9) {
		this.ttlPremiumLife_9 = ttlPremiumLife_9;
	}

	public String getGrandTtl_10() {
		return grandTtl_10;
	}

	public void setGrandTtl_10(String grandTtl_10) {
		this.grandTtl_10 = grandTtl_10;
	}

	public String getTtlClaimHealth_11() {
		return ttlClaimHealth_11;
	}

	public void setTtlClaimHealth_11(String ttlClaimHealth_11) {
		this.ttlClaimHealth_11 = ttlClaimHealth_11;
	}

	public String getTtlClaimLife_12() {
		return ttlClaimLife_12;
	}

	public void setTtlClaimLife_12(String ttlClaimLife_12) {
		this.ttlClaimLife_12 = ttlClaimLife_12;
	}

	public String getLossesBroughtForwardHealth_13() {
		return lossesBroughtForwardHealth_13;
	}

	public void setLossesBroughtForwardHealth_13(String lossesBroughtForwardHealth_13) {
		this.lossesBroughtForwardHealth_13 = lossesBroughtForwardHealth_13;
	}

	public String getLossesbroughtForwardLife_14() {
		return lossesbroughtForwardLife_14;
	}

	public void setLossesbroughtForwardLife_14(String lossesbroughtForwardLife_14) {
		this.lossesbroughtForwardLife_14 = lossesbroughtForwardLife_14;
	}

	

	public String getRefundRateHealth_15() {
		return refundRateHealth_15;
	}

	public void setRefundRateHealth_15(String refundRateHealth_15) {
		this.refundRateHealth_15 = refundRateHealth_15;
	}

	public String getRefundRateLife_16() {
		return refundRateLife_16;
	}

	public void setRefundRateLife_16(String refundRateLife_16) {
		this.refundRateLife_16 = refundRateLife_16;
	}

	public String getRetentionRateHealthGreter50Per_17() {
		return retentionRateHealthGreter50Per_17;
	}

	public void setRetentionRateHealthGreter50Per_17(String retentionRateHealthGreter50Per_17) {
		this.retentionRateHealthGreter50Per_17 = retentionRateHealthGreter50Per_17;
	}

	public String getRetentionRateLifeGreter50Per_18() {
		return retentionRateLifeGreter50Per_18;
	}

	public void setRetentionRateLifeGreter50Per_18(String retentionRateLifeGreter50Per_18) {
		this.retentionRateLifeGreter50Per_18 = retentionRateLifeGreter50Per_18;
	}

	public String getRetentionRateHealthLess50Per_19() {
		return retentionRateHealthLess50Per_19;
	}

	public void setRetentionRateHealthLess50Per_19(String retentionRateHealthLess50Per_19) {
		this.retentionRateHealthLess50Per_19 = retentionRateHealthLess50Per_19;
	}

	public String getRetentionRateLifeLess50Per_20() {
		return retentionRateLifeLess50Per_20;
	}

	public void setRetentionRateLifeLess50Per_20(String retentionRateLifeLess50Per_20) {
		this.retentionRateLifeLess50Per_20 = retentionRateLifeLess50Per_20;
	}

	public String getRetentionAmntHealth_21() {
		return retentionAmntHealth_21;
	}

	public void setRetentionAmntHealth_21(String retentionAmntHealth_21) {
		this.retentionAmntHealth_21 = retentionAmntHealth_21;
	}

	public String getRetentionAmountLife_22() {
		return retentionAmountLife_22;
	}

	public void setRetentionAmountLife_22(String retentionAmountLife_22) {
		this.retentionAmountLife_22 = retentionAmountLife_22;
	}

	public String getTtaClaimAndLossesHealth_23() {
		return ttaClaimAndLossesHealth_23;
	}

	public void setTtaClaimAndLossesHealth_23(String ttaClaimAndLossesHealth_23) {
		this.ttaClaimAndLossesHealth_23 = ttaClaimAndLossesHealth_23;
	}

	
	public String getTtlClaimandLossesLife_24() {
		return ttlClaimandLossesLife_24;
	}

	public void setTtlClaimandLossesLife_24(String ttlClaimandLossesLife_24) {
		this.ttlClaimandLossesLife_24 = ttlClaimandLossesLife_24;
	}

	public String getAmntRefundOrLossesHealth_25() {
		return amntRefundOrLossesHealth_25;
	}

	public void setAmntRefundOrLossesHealth_25(String amntRefundOrLossesHealth_25) {
		this.amntRefundOrLossesHealth_25 = amntRefundOrLossesHealth_25;
	}

	public String getAmntRefundOrLossesLife_26() {
		return amntRefundOrLossesLife_26;
	}

	public void setAmntRefundOrLossesLife_26(String amntRefundOrLossesLife_26) {
		this.amntRefundOrLossesLife_26 = amntRefundOrLossesLife_26;
	}

	public String getTtlAmntRefundOrLosses_27() {
		return ttlAmntRefundOrLosses_27;
	}

	public void setTtlAmntRefundOrLosses_27(String ttlAmntRefundOrLosses_27) {
		this.ttlAmntRefundOrLosses_27 = ttlAmntRefundOrLosses_27;
	}

	public String getCnNo_28() {
		return cnNo_28;
	}

	public void setCnNo_28(String cnNo_28) {
		this.cnNo_28 = cnNo_28;
	}

	public String getAccountCode_29() {
		return accountCode_29;
	}

	public void setAccountCode_29(String accountCode_29) {
		this.accountCode_29 = accountCode_29;
	}

}
