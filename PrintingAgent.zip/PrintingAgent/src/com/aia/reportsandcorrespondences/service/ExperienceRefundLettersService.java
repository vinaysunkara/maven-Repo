package com.aia.reportsandcorrespondences.service;



import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.aia.ahs.common.claimexcess.invoiceexxonmobil.model.InvoiceExxonMobileTable;
import com.aia.reportsandcorrespondences.experiencerefundletter.model.ExperienceRefundLetter;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

public class ExperienceRefundLettersService extends Thread {
	
	 private static final String FILE_PATH = "D:\\Test_Read\\excell_ExperienceRefund\\Template_Symphony.xlsx";
		
	
private Thread t;
public void run() {
	//getExperienceRefundLettersDetails();
  genReport();
	}
public void	genReport(){

	List<List<ExperienceRefundLetter>> experienceRefundLetterListRs=getExperienceRefundLettersDetails();
	int nofile=experienceRefundLetterListRs.size();
	for(int i=0; i<nofile;i++){
		List<ExperienceRefundLetter> experienceRefundLetterList=experienceRefundLetterListRs.get(i);
		for(ExperienceRefundLetter l:experienceRefundLetterList){
			 
       uploadReport( experienceRefundLetterList);
	      }
	  }
	}
	
public  void uploadReport(List<ExperienceRefundLetter> experienceRefundLetterList) {
	try {
		FileInputStream inputStream =null;
		 HashMap<String, Object> dataSource= new HashMap<String, Object>();
		 JRBeanCollectionDataSource beandataSource = new JRBeanCollectionDataSource(experienceRefundLetterList);
		 
		 String getTtlAmntRefundOrLosses_27="";
		String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
		String policyNumber="";
		for(ExperienceRefundLetter er:experienceRefundLetterList){
			//policyNumber=er.getPolicyNumber_3();
			policyNumber=er.getPolicyNumber_3();
			getTtlAmntRefundOrLosses_27=er.getTtlAmntRefundOrLosses_27();
		}
		String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ReportsAndCorrespondences\\conventional\\";
	
		String policyNo[]=policyNumber.split("\\/");
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY/mm//dd");
		String date =sdf.format(new Date()).replace("/", "");
		String pdfname=policyNo[0].trim()+"_"+date+"_ExperienceRefundLetter";
		String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
		
		String v=getTtlAmntRefundOrLosses_27;
		boolean startswith= v.startsWith("-");
    	if(!startswith){
		 String jrFullReadpath = path+"PrintingAgentReports\\ReportsAndCorrespondences\\conventional\\experienceRefundLetter\\ExperienceRefundLetterFullPages.jasper";
		 inputStream = new FileInputStream(jrFullReadpath);
		}
		else{
			String jrFullReadpath = path+"PrintingAgentReports\\ReportsAndCorrespondences\\conventional\\experienceRefundLetter\\ExperienceRefundLetter.jasper";
			// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
			 inputStream = new FileInputStream(jrFullReadpath);
		}
			
	   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
	   String logo= FilenameUtils.normalize(imgpath, true); 
	   dataSource.put("logo", logo);
		JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, beandataSource);// for compiled Report .jrxml file
		
		FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
		JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
		System.out.println("PDF Generated..."+pdfFullOutputPath);
		
	} catch (Exception e) {
		System.out.println("Exception occurred : " + e);
	} finally {

	}
}


List<List<ExperienceRefundLetter>> getExperienceRefundLettersDetails(){
	List<List<ExperienceRefundLetter>> experienceRefundLetterListList=new	ArrayList<List<ExperienceRefundLetter>> ();
	List<ExperienceRefundLetter> experienceRefundLetterList=null;
	 FileInputStream fis = null;
	 Workbook workbook=null;
	 try{
		 fis = new FileInputStream(FILE_PATH);
		  workbook = new XSSFWorkbook(fis);
		 int noOfSheets=workbook.getNumberOfSheets();
		// System.out.println("Num of Sheets  :  "+noOfSheets);
		 for(int i=0;i<noOfSheets;i++){
			Sheet sheet=workbook.getSheetAt(i);
			int starRow=3;
			//int starRow = sheet.getFirstRowNum();
		    int endRow = sheet.getLastRowNum();
		   // System.out.println("start row number  :  "+starRow);
		   System.out.println("End row number  :  "+endRow);
		    
		    ExperienceRefundLetter experienceRefundLetter =null;
		    for (int j = starRow; j <= endRow; j++) {
		    //for (int j = starRow + 2; j <= endRow; j++) {
					experienceRefundLetter = new ExperienceRefundLetter();
					experienceRefundLetterList=new ArrayList<ExperienceRefundLetter>();
					Cell c1 = workbook.getSheetAt(i).getRow(j).getCell(1);
					experienceRefundLetter.setEmpOrPolicyHolder_1(c1.toString().trim() + "");
					Cell c2 = workbook.getSheetAt(i).getRow(j).getCell(2);
					experienceRefundLetter.setAddress_2(c2.toString().trim() + "");
					Cell c3 = workbook.getSheetAt(i).getRow(j).getCell(3);
					experienceRefundLetter.setPolicyNumber_3(c3.toString().trim() + "");
					Cell c4 = workbook.getSheetAt(i).getRow(j).getCell(4);
					experienceRefundLetter.setPolicyPeriodFrom_4(c4.toString().trim() + "");
					Cell c5 = workbook.getSheetAt(i).getRow(j).getCell(5);
					experienceRefundLetter.setPolicyPeriodTo_5(c5.toString().trim() + "");
					Cell c6 = workbook.getSheetAt(i).getRow(j).getCell(6);
					experienceRefundLetter.setDatePrepared_6(c6.toString().trim() + "");
					Cell c7 = workbook.getSheetAt(i).getRow(j).getCell(7);
					experienceRefundLetter.setErgGroup_7(c7.toString().trim() + "");
					Cell c8 = workbook.getSheetAt(i).getRow(j).getCell(8);
					experienceRefundLetter.setTtlPremiumHealth_8(c8.toString().trim() + "");
					Cell c9 = workbook.getSheetAt(i).getRow(j).getCell(9);
					experienceRefundLetter.setTtlPremiumLife_9(c9.toString().trim() + "");
					Cell c10 = workbook.getSheetAt(i).getRow(j).getCell(10);
					experienceRefundLetter.setGrandTtl_10(c10.toString().trim() + "");
					// System.out.println("GrandTtl:"+c10.toString().trim()+"");
					Cell c11 = workbook.getSheetAt(i).getRow(j).getCell(11);
					experienceRefundLetter.setTtlClaimHealth_11(c11.toString().trim() + "");
					Cell c12 = workbook.getSheetAt(i).getRow(j).getCell(12);
					experienceRefundLetter.setTtlClaimLife_12(c12.toString().trim() + "");
					Cell c13 = workbook.getSheetAt(i).getRow(j).getCell(13);
					experienceRefundLetter.setLossesBroughtForwardHealth_13(c13.toString().trim() + "");
					Cell c14 = workbook.getSheetAt(i).getRow(j).getCell(14);
					experienceRefundLetter.setLossesbroughtForwardLife_14(c14.toString().trim() + "");
					Cell c15 = workbook.getSheetAt(i).getRow(j).getCell(15);
					experienceRefundLetter.setRefundRateHealth_15(c15.toString().trim() + "");
					// System.out.println("RefundRateHealth : "+c15.toString().trim()+"");
					Cell c16 = workbook.getSheetAt(i).getRow(j).getCell(16);
					experienceRefundLetter.setRefundRateLife_16(c16.toString().trim() + "");
					Cell c17 = workbook.getSheetAt(i).getRow(j).getCell(17);
					experienceRefundLetter.setRetentionRateHealthGreter50Per_17(c17.toString().trim() + "");
					Cell c18 = workbook.getSheetAt(i).getRow(j).getCell(18);
					experienceRefundLetter.setRetentionRateLifeGreter50Per_18(c18.toString().trim() + "");
					Cell c19 = workbook.getSheetAt(i).getRow(j).getCell(19);
					experienceRefundLetter.setRetentionRateHealthLess50Per_19(c19.toString().trim() + "");
					Cell c20 = workbook.getSheetAt(i).getRow(j).getCell(20);
					experienceRefundLetter.setRetentionRateLifeLess50Per_20(c20.toString().trim() + "");
					Cell c21 = workbook.getSheetAt(i).getRow(j).getCell(21);
					experienceRefundLetter.setRetentionAmntHealth_21(c21.toString().trim() + "");
					Cell c22 = workbook.getSheetAt(i).getRow(j).getCell(22);
					experienceRefundLetter.setRetentionAmountLife_22(c22.toString().trim() + "");
					Cell c23 = workbook.getSheetAt(i).getRow(j).getCell(23);
					experienceRefundLetter.setTtaClaimAndLossesHealth_23(c23.toString().trim() + "");
					Cell c24 = workbook.getSheetAt(i).getRow(j).getCell(24);
					experienceRefundLetter.setTtlClaimandLossesLife_24(c24.toString().trim() + "");
					Cell c25 = workbook.getSheetAt(i).getRow(j).getCell(25);
					experienceRefundLetter.setAmntRefundOrLossesHealth_25(c25.toString().trim() + "");
					Cell c26 = workbook.getSheetAt(i).getRow(j).getCell(26);
					experienceRefundLetter.setAmntRefundOrLossesLife_26(c26.toString().trim() + "");
					Cell c27 = workbook.getSheetAt(i).getRow(j).getCell(27);
					experienceRefundLetter.setTtlAmntRefundOrLosses_27(c27.toString().trim() + "");
					Cell c28 = workbook.getSheetAt(i).getRow(j).getCell(28);
					experienceRefundLetter.setCnNo_28(c28.toString().trim() + "");
					Cell c29 = workbook.getSheetAt(i).getRow(j).getCell(29);
					experienceRefundLetter.setAccountCode_29(c29.toString().trim() + "");
					experienceRefundLetterList.add(experienceRefundLetter);
					experienceRefundLetterListList.add(experienceRefundLetterList);
			   }
		    }
		 
	 }catch(Exception e){
		System.out.println("Exception occored ExperienceRefundLettersService.getExperienceRefundLettersDetails() :"+e.toString()); 
	 }
	
	return experienceRefundLetterListList;
}
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		ExperienceRefundLettersService crs = new ExperienceRefundLettersService();
		crs.startBatch();
		System.out.println("startedd.....");
	}
}
