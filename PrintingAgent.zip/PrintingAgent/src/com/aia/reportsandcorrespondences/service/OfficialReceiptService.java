package com.aia.reportsandcorrespondences.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import org.apache.commons.io.FilenameUtils;

import com.aia.ahs.conventional.aso.service.ASOInvoiceExxonMobileService;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class OfficialReceiptService extends Thread{
private Thread t;
	
public void run() {
	
	genReport();
}

public void	genReport(){
	/*HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> asoCreditNoteRSDetails=getOfficialReceiptDetails();
		*/
	HashMap<String, Object> dataSource=new HashMap<String, Object>();
	
	dataSource.put("companyName",  "ABC SDN BHD");
	dataSource.put("addressLine1",  "JALAN ABC");
	dataSource.put("addressLine2", "ABC INDUSTRIAL PARK");
	dataSource.put("addressLine3","KUALA LUMPUR");
	dataSource.put("addressLine4", "50450 WILAYAH PERSEKUTUAN");
	dataSource.put("addressLine5", "");
	dataSource.put("receiptNum","T0004331");
	dataSource.put("issuedBy",  "H833176");
	dataSource.put("date", "01/01/2019");
	dataSource.put("sumOf",  "RINGGIT MALAYSIA ONE HUNDRED TEN THOUSAND SIX HUNDRED SIXTY ONE AND THREE CENTS ONLY");
	dataSource.put("reversalOf",  "T0004329");
	dataSource.put("amount",  "110,661.03");
	dataSource.put("chequeOrTT",  "Telegram Transfer: PIBB-KL TT@080118");
	this.uploadReport(dataSource);
	
	}
	
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		try {
String pdfOutputpath="D:\\Test_Write\\jasperPDf\\ReportsAndCorrespondences\\conventional\\";

	    	String pdfname="_OfficialReceipt";
	    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
			//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
			String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			String jrFullReadpath = path+"PrintingAgentReports\\ReportsAndCorrespondences\\conventional\\officialReceipt\\OfficialReceipt.jasper";
			// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
			FileInputStream inputStream = new FileInputStream(jrFullReadpath);
			
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
		   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
		   String logo= FilenameUtils.normalize(imgpath, true); 
		   dataSource.put("logo", logo);
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
			
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println("PDF Generated..."+pdfFullOutputPath);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} finally {

		}
	}
	
	
	HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>  getOfficialReceiptDetails(){
		HashMap<Integer, HashMap<String, Object>> OfficialReceiptRS=new HashMap<Integer, HashMap<String, Object>>();
		
		return null;
	}
	
public void startBatch() {
	System.out.println("Starting thread ");

	if (t == null) {
		t = new Thread(this);
		t.start();
	}
}

public static void main(String args[]) {
	OfficialReceiptService ces = new OfficialReceiptService();
	ces.startBatch();
	System.out.println("startedd.....");
}
}
