package com.aia.common.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.xml.bind.DatatypeConverter;


public class BytesToStringUtil  {
	
	//public static String getString(String pathFile) {
	public static byte[] getByte(String pathFile) {
		
        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;
        try {
            File file = new File(pathFile);
            bytesArray = new byte[(int) file.length()];
            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
        System.out.println("Byte      :    ====>"+bytesArray.toString());
       // byte array converting into string
      //  return DatatypeConverter.printBase64Binary(bytesArray);
        return bytesArray;
   }
	
/*	 public static void writeBytesToFile(File theFile, String bFile) throws IOException {
	      BufferedOutputStream bos = null;
	    try {
	      FileOutputStream fos = new FileOutputStream(theFile);
	      bos = new BufferedOutputStream(fos);
	      //converting string to byte
	      byte[] bytes= DatatypeConverter.parseBase64Binary(bFile); 
	      
	      //byte[] bytes= bFile.getBytes(Charset.forName("UTF-8"));
	      
	      bos.write(bytes);
	    }finally {
	      if(bos != null) {
	        try  {
	          //flush and close the BufferedOutputStream
	          bos.flush();
	          bos.close();
	        } catch(Exception e){}
	      }
	    }
	    }*/
	
	
	public static void main(String[] args) throws IOException {
		 // convert file to byte[]
       // byte[] bFile = readBytesFromFile("D:\\Test_Write\\00002245_00919382_invoice.pdf");
     //   String bFile = readBytesFromFile("D:\\Test_Write\\00002245_00919382_invoice.pdf");
       //System.out.println(bFile);
        
        //converting byte to PDF
     
       // writeBytesToFile(new File("D:\\Test_Read\\00002245_00919382_invoice.pdf"),bFile);
		BytesToStringUtil.getByte("D:\\Test_Write\\00007009_00919392_invoice.pdf");
		
	
	} 

}
