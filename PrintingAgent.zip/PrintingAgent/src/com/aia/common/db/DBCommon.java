package com.aia.common.db;

import ho.aia.utility.persistence.DataTypeHandler;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.DuplicateFormatFlagsException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import com.aia.common.model.AgentContract;
import com.aia.common.model.AppForm;
import com.aia.common.model.ClaimsData;
import com.aia.common.model.NBAgentContact;
import com.aia.common.model.Notification;
import com.aia.common.model.POSServiceRequest;
import com.aia.common.model.PolCoverage;
import com.aia.common.model.PolWebForm;
import com.aia.common.model.PolicyInfo;
import com.aia.common.model.RelatedEntity;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericUtil;
import com.aia.utility.DBUtil;
//import com.ibm.websphere.ce.cm.DuplicateKeyException;

public class DBCommon {
	final int bulkLoadBatchSize = 10000;
	final boolean showTime = true;
	
	public boolean addPrintSummary (String uniqueID, String srcFileName, String processYear, String from) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_TaxInvPrintSummary (PrintSummaryID, SeqNo, SourceFileName, ProcessYear, IsCalled, IsHardCopyPrinted, CreatedBy, CreatedDate)" +
					"VALUES (?, (select case when MAX(SeqNo) is null then 1 else MAX(SeqNo) + 1 end from tbl_TaxInvPrintSummary where PrintSummaryID = ?), " +
					"?, ?, 'N', 'N', 'BATCH', GETDATE())";
			
			/*String strSql = "INSERT INTO tbl_TaxInvPrintSummary (PrintSummaryID, SeqNo, SourceFileName, ArchiveFileName, ProcessYear, IsCalled, IsHardCopyPrinted, " +
					"OriginalPrintPDF, OriginalPrintDate, DuplicatePrintPDF, DuplicatePrintDate, CreatedBy, CreatedDate) " +
					"VALUES (?, (select case when MAX(SeqNo) is null then 1 else MAX(SeqNo) + 1 end from tbl_TaxInvPrintSummary where PrintSummaryID = ?), ?, null, ?, 'N', 'N', " + 
					"null, null, null, null, 'BATCH', GETDATE())";*/
			
			st = conn.prepareStatement(strSql);
			st.setString(1, uniqueID);
			st.setString(2, uniqueID);
			st.setString(3, srcFileName); 
			st.setString(4, processYear);
			
			st.execute();
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addPrintSummary() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean updatePrintSummary (String uniqueID, String srcFileName, String arcFileName, int fileSeqNo) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "update tbl_TaxInvPrintSummary set ArchiveFileName = ? where PrintSummaryID = ? and SeqNo = ?";
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, arcFileName);
			ps.setString(2, uniqueID); 
			ps.setInt(3, fileSeqNo);
			
			ps.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updatePrintSummary() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean updatePrintSummaryCalled (String uniqueID, int fileSeqNo) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "update tbl_TaxInvPrintSummary set IsCalled = ? where PrintSummaryID = ? and SeqNo = ?";
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, "Y");
			ps.setString(2, uniqueID); 
			ps.setInt(3, fileSeqNo);
			
			ps.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updatePrintSummaryCalled() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean updatePrintSummaryStatus (String uniqueID, int fileSeqNo, String status, String errMsg) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = null;
			
			if (fileSeqNo == 0) {
				strSql = "update tbl_TaxInvPrintSummary set IsCalled = ?, ErrMsg = ? where PrintSummaryID = ?";
			} else {
				strSql = "update tbl_TaxInvPrintSummary set IsCalled = ?, ErrMsg = ? where PrintSummaryID = ? and SeqNo = ?";
			}
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, status);
			ps.setString(2, errMsg);
			ps.setString(3, uniqueID);
			ps.setInt(4, fileSeqNo);
			
			ps.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updatePrintSummaryStatus() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean addPrintSummDet (String uniqueID, int srcFileSeqNo, int pdfFileNo, String fileName, String srcSystem) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			/*String strSql = "insert into tbl_TaxInvPrintSumDet (SummaryID, SummarySeqNo, SeqNo, FileName, CreatedBy, CreatedDate) " +
					"values ('" + processID + "', '" + i + "', " + baosNo + ", '" + processID + "_" + baosNo + "', '" + sourceSystem + "', getDate())";*/
			String strSql = "insert into tbl_TaxInvPrintSumDet (SummaryID, SummarySeqNo, SeqNo, FileName, CreatedBy, CreatedDate) " +
					"values (?, ?, ?, ?, ?, getDate())";
			
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, uniqueID);
			ps.setInt(2, srcFileSeqNo);
			ps.setInt(3, pdfFileNo); 
			ps.setString(4, fileName);
			ps.setString(5, srcSystem);
			
			ps.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addPrintSummDet() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean updateWorkableProcess (String processYear, String isProcess, List<String> taxInvoiceNo) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		String taxInvNoList = "";
		
		long start = System.currentTimeMillis();
		
		try {
			for (String taxInvNo : taxInvoiceNo) {
				if (taxInvNoList.length() > 0) {
					taxInvNoList += ", ";
				}
				
				taxInvNoList += "'" + taxInvNo + "'";
			}
			
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "update tbl_TaxInv_" + processYear + " set IsProcess = ? where TaxInvoiceNo in (" + taxInvNoList + ")";
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, isProcess);
			
			ps.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e) {
	    		
	    	}
		} finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateWorkableProcess(1) duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean updateWorkableProcess (String processYear, String isProcess, String taxInvoiceNo) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "update tbl_TaxInv_" + processYear + " set IsProcess = ? where TaxInvoiceNo = ?";
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, isProcess);
			ps.setString(2, taxInvoiceNo);
			
			ps.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.setAutoCommit(true);
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateWorkableProcess(2) duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean validateTableByYear(String processYear) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		String foundTable = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT 'Y' as isFound FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, "tbl_TaxInv_" + processYear);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				foundTable = rs.getString("isFound");
			}
			
			if (!"Y".equals(foundTable)) {
				//Create table
				executeSQL("CREATE TABLE tbl_TaxInv_" + processYear + " (" +
					"SummaryID varchar(50) NOT NULL, SummarySeqNo INT NOT NULL, SeqNo int Not Null, DocType varchar(1) NULL, SourceType varchar(2) NULL, " +
					"CompanyCode varchar(4) NULL, ClientType varchar(1) NULL, OwnerName varchar(255) NULL, Address1 varchar(255) NULL, Address2 varchar(255) NULL, " +
					"Address3 varchar(255) NULL, Address4 varchar(255) NULL, Address5 varchar(255) NULL, PolicyNo varchar(15) NULL, InsuredName varchar(255) NULL, " +
					"TaxInvoiceNo varchar(50) NULL, TaxInvoiceDate datetime NULL, OrgTaxInvNo varchar(50) NULL, OrgTaxInvDate datetime NULL, BillNo varchar(50) NULL, " +
					"TaxCode varchar(10) NULL, TransDate datetime Null, TransDesc varchar(255) NULL, ProdDesc varchar(255) NULL, AmtExclGST decimal(18, 2) NULL, " +
					"AmtGST decimal(18, 2) NOT NULL, AMTInclGST decimal(18, 2) NULL, TaxRate decimal(6, 4) NULL, Notes varchar(255) NULL, AgentGSTRegNo varchar(20) NULL, " +
					"AgentCode varchar(20) NULL, SelfBillApprovalNo varchar(50) NULL, AIAGSTRegNo varchar(20) NULL, Postcode varchar(10) NULL, AgentType varchar(5) NULL, " +
					"IsProcess varchar(1) NULL, FileName varchar(255) NULL, TaxDescription varchar(250) NULL, CreatedBy varchar(50) NULL, CreatedDate datetime NULL, " +
					"CovPeriod varchar(255) NULL)");
				
				//Create Index
				executeSQL("CREATE NONCLUSTERED INDEX Idx_InvNo ON tbl_TaxInv_" + processYear + " (TaxInvoiceNo) " +
						"WITH ( PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
				
				executeSQL("CREATE NONCLUSTERED INDEX Idx_AGTCOMPDOC ON tbl_TaxInv_" + processYear + " (AgentCode, CompanyCode, DocType) " +
						"WITH ( PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
				
				executeSQL("CREATE NONCLUSTERED INDEX Idx_TaxInvSeq ON tbl_TaxInv_" + processYear + " (SummarySeqNo, TaxInvoiceNo) " +
						"WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
				
				executeSQL("CREATE NONCLUSTERED INDEX Idx_PolicyNo ON tbl_TaxInv_" + processYear + " (PolicyNo) " +
						"WITH ( PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
				
				executeSQL("CREATE NONCLUSTERED INDEX Idx_SummID ON tbl_TaxInv_" + processYear + " (SummaryID) " +
						"WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");

				executeSQL("CREATE NONCLUSTERED INDEX Idx_SummSeq ON tbl_TaxInv_" + processYear + " (SummarySeqNo) " +
						"WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
				
				executeSQL("CREATE NONCLUSTERED INDEX Idx_SummIDSeq ON tbl_TaxInv_" + processYear + " (SummaryID, SummarySeqNo) " +
						"WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, ONLINE = OFF, " +
						"ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
				
				executeSQL("insert into tbl_TaxInv_Year (TableYear) values ('" + processYear + "')");
			}
			
		} catch(Exception ex){
			ex.printStackTrace();
        } finally {
			try {
				conn.setAutoCommit(true);
				
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.validateTableByYear() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public void executeSQL(String sqlStatement) {
		PreparedStatement st = null;
		Connection conn = null;
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			st = conn.prepareStatement(sqlStatement);
			st.execute();
					
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e){}
	    	System.out.println(ex.toString());
		}finally {
			try {
				if (st != null) {
					st.close();
				}
				
				conn.close();
			} catch(Exception ex){}
		}		
	}
	
	public boolean addData2TaxInvTable (String uniqueID, int SummarySeqNo, String inputFileName, String processYear) {
		boolean isProcess = false;
		Date startDate = new java.util.Date();
		CommonFileUtil cu = new CommonFileUtil();
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		int lineCount = 0;
		String lineStr = null;
		final int columnStartAt = 4;
		Scanner sc = null;
		String debugMsg = "";
		
		long start = System.currentTimeMillis();
		
		try {
			System.out.println("-------------------------------- [" + startDate + "] [CommonUtil] processInputFile Start --------------------------------");
			sc = new Scanner(new File(cu.getRootPath("invTxt\\" + uniqueID + "\\" + inputFileName)), "UTF-8");
			
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_TaxInv_" + processYear + " (SummaryID, SummarySeqNo, SeqNo, DocType, SourceType, CompanyCode, " +
					"ClientType, OwnerName, Address1, Address2, Address3, Address4, Address5, PolicyNo, InsuredName, TaxInvoiceNo, TaxInvoiceDate, " +
					"OrgTaxInvNo, OrgTaxInvDate, BillNo, TaxCode, TransDate, TransDesc, ProdDesc, AmtExclGST, AmtGST, AMTInclGST, TaxRate, " +
					"Notes, AgentGSTRegNo, AgentCode, SelfBillApprovalNo, AIAGSTRegNo, AgentType, Postcode, TaxDescription, CovPeriod, CreatedBy, " +
					"CreatedDate) values (" +
					"?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, getDate())";
			
			st = conn.prepareStatement(strSql);
			
			while (sc.hasNextLine()) {
				debugMsg = "";
				
				lineStr = sc.nextLine();
				
				if (lineCount >= 0) { 
					Scanner lineScan = new Scanner(lineStr);
					lineScan.useDelimiter("\\|");
					
					st.setString(1, uniqueID);
					st.setInt(2, SummarySeqNo);
					st.setInt(3, lineCount);
					st.setString(38, "Batch");
					
	    			int columnCount = 0;
	    			
	    			while(lineScan.hasNext()) {
	    				if (debugMsg.length() > 0) {
	    					debugMsg += ", ";
	    				}
	    				
						String columnData = lineScan.next();
						
						//to handle special company code OM1 = 016 and 0M2 = 072 
						if (columnCount == 2) {
							if ("0M1".equalsIgnoreCase(columnData)) {
								columnData = "016";
							} else if ("0M2".equalsIgnoreCase(columnData)) {
								columnData = "072";
							}
						}
						
						if (columnCount == 21 ||  columnCount == 22 || columnCount == 23 || columnCount == 24) {				//AmtExclGST, AmtGST, AMTInclGST, TaxRate
	    					if (columnData != null && columnData.trim().length() > 0) {
	    						try {
	    							st.setDouble(columnCount + columnStartAt, Double.valueOf(columnData));
	    							debugMsg += columnData;
	    						} catch(NumberFormatException e) {
	    							st.setDouble(columnCount + columnStartAt, 0);
	    							debugMsg += "0";
	    						}
	    					} else {
	    						st.setDouble(columnCount + columnStartAt, 0);
	    						debugMsg += "0";
	    					}
	    				} else if (columnCount == 13 || columnCount == 15) {													// TaxInvoiceDate, OrgTaxInvDate
	    					if (columnData != null && columnData.trim().length() == 0) {
	    						st.setString(columnCount + columnStartAt, null);
	    						debugMsg += null;
	    					} else {
	    						st.setString(columnCount + columnStartAt, columnData);
	    						debugMsg += "'" + columnData + "'";
	    					}
	    				} else {
	    					st.setString(columnCount + columnStartAt, columnData);
	    					debugMsg += "'" + columnData + "'";
	    				}
						
						columnCount++;
					}
	    			
	    			if (columnCount < 34) {
	    				st.setString(columnCount + columnStartAt, null);
	    			}
					
					st.addBatch();
	    			
	    			if (lineCount > 0 && lineCount % bulkLoadBatchSize == 0) { // batch size
	    				st.executeBatch();
	    				st.clearParameters();
	    				st.clearBatch();
	    				
//	    				conn.commit();
	    				
	    				System.out.println("----- [" + new java.util.Date() + "] " +  lineCount + " Done -----");
	    			}
				}
				
				lineCount++;
	        }
			
			if (lineCount % bulkLoadBatchSize > 0) {
				st.executeBatch();
				st.clearParameters();
				st.clearBatch();
//				conn.commit();
            }
			
			isProcess = true;
			
//			sc.remove();
			
			System.out.println("-------------------------------- [" + startDate + "][" + new java.util.Date() + "] [CommonUtil] processInputFile End --------------------------------");
		} catch(Exception io){
			try {
				conn.rollback();
			} catch (Exception ex) {}
			System.out.println("error on line [" + lineCount + "] " + lineStr);
			System.out.println(debugMsg);
			io.printStackTrace();
        } finally {
			try {
				conn.commit();
				conn.setAutoCommit(true);
				
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
				
				if (sc != null) {
					sc.close();
				}
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addData2TaxInvTable() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	
		return isProcess;
	}
	
	public List<String> updateProcessCase (String summaryID, int summarySeqNo, String processYear) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<String> taxInvNoList = new ArrayList<String>();
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "Update tbl_TaxInv_"+ processYear + " " +
					"set IsProcess = ? " + 
					"where SummaryID = ? " +
					"and SummarySeqNo = ? ";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, "N");
			st.setString(2, summaryID);
			st.setInt(3, summarySeqNo);
			
			st.executeUpdate();
			
		} catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateProcessCase() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return taxInvNoList;
	}
	
	public int getPrintSummSeqNo (String summaryID) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "select max(SeqNo) as seqNo from tbl_TaxInvPrintSummary where PrintSummaryID = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, summaryID);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				return rs.getInt("seqNo");
			}
		} catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPrintSummSeqNo() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return 0;
	}
	
	public List<String> getTaxInvList(String summaryID, int summarySeqNo, String processYear, int maxInvTaxNo) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<String> taxInvNoList = new ArrayList<String>();
		
		long start = System.currentTimeMillis();
		
		try {
			HashMap<Integer, HashMap<String, String>> taxInvFilterList = getTaxInvFilterList();
			
			conn = DBUtil.getConnection("bicor");
			
			/*String strSql = "select top " + maxInvTaxNo + " (TaxInvoiceNO) as TaxInvNo " +
				"from tbl_TaxInv_"+ processYear + " " +
				"where SummaryID = ? " +
				"and SummarySeqNo = ? " +
				"and (IsProcess not in ('Y') or IsProcess is null) " +
				"and OwnerName not like 'AIA %' " +
				"and OwnerName not like 'AMERICAN INTERNATIONAL ASSURANCE%' " +
				"and OwnerName not in ('MALAYSIAN AGENTS PROVIDENT FUND', 'RETAIL BUSINESS DISTRIBUTION') " +
				"group By TaxInvoiceNo " +
				"order By min(DocType), min(ClientType), min(Postcode)";*/
			
			String strSql = "SELECT top " + maxInvTaxNo + " (TaxInvoiceNo) as TaxInvNo, SourceType, OwnerName " +
				"FROM tbl_TaxInv_"+ processYear + " " + 
				"WHERE SummaryID = ? " + 
				"and SummarySeqNo = ? " + 
				"and (IsProcess not in ('Y') or IsProcess is null) " +
				"GROUP BY TaxInvoiceNo, SourceType, OwnerName " +
				"ORDER BY min(DocType), min(ClientType), min(Postcode)";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, summaryID);
			st.setInt(2, summarySeqNo);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				boolean isFilter = false;
				String taxInvNo = rs.getString("TaxInvNo");
				String sourceType = rs.getString("SourceType");
				String ownerName = rs.getString("OwnerName");
				
				for (int z=0; z<taxInvFilterList.size(); z++) {
					HashMap<String, String> filterList = taxInvFilterList.get(z);
					String filterWord  = filterList.get("FilterWord");
					String sourceSystem = filterList.get("SourceSystem");
					
					if (sourceSystem.equalsIgnoreCase(sourceType)) {
						if (ownerName.matches(filterWord)) {
							isFilter = true;
							break;
						}
					}
				}
				
				if (!isFilter) {
					taxInvNoList.add(taxInvNo);
				}
			}
		} catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getTaxInvList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return taxInvNoList;
	}
	
	public List<String> getTaxInvListWithDocFormat(String summaryID, int summarySeqNo, String processYear, String docFormat, 
			boolean isT2) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<String> taxInvNoList = new ArrayList<String>();
		
		long start = System.currentTimeMillis();
		
		try {
			HashMap<Integer, HashMap<String, String>> taxInvFilterList = getTaxInvFilterList();
			
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT (TaxInvoiceNo) as TaxInvNo, SourceType, OwnerName " +
				"FROM tbl_TaxInv_" + processYear + " a " + 
				"WHERE SummaryID = ? and SummarySeqNo = ? " + 
				"and '" + docFormat + "' = (select DocFormat from tbl_DocFormatLK where a.SourceType = SourceSystem " +
				"and a.DocType = DocType and (a.ClientType = ClientType or rtrim(ltrim(a.ClientType)) = '') " +
				"and (a.AgentType = AgentType or rtrim(ltrim(a.AgentType)) = '') and IsT2 = 'N') " +
				"and (IsProcess not in ('Y') or IsProcess is null) " +
				"GROUP BY TaxInvoiceNo, SourceType, OwnerName " +
				"ORDER BY min(DocType), min(ClientType), min(Postcode)";
			
			if(isT2) {
				strSql = "SELECT (TaxInvoiceNo) as TaxInvNo, SourceType, OwnerName " + 
						"FROM tbl_TaxInv_" + processYear + " a " + 
						"WHERE SummaryID = ? and SummarySeqNo = ? " + 
						"and '" + docFormat + "' = (select DocFormat from tbl_DocFormatLK where a.SourceType = SourceSystem " +
						"and a.DocType = DocType and (a.ClientType = ClientType or rtrim(ltrim(a.ClientType)) = '') " +
						"and (a.AgentType = AgentType or rtrim(ltrim(a.AgentType)) = '') " +
						"and a.TransDate >= DATEADD(day, -60, getDate()) and a.TransDate <= getDate()" +
						"and IsT2 = 'Y') " +
						"and (IsProcess not in ('Y') or IsProcess is null) " +
						"GROUP BY TaxInvoiceNo, SourceType, OwnerName " +
						"ORDER BY min(DocType), min(ClientType), min(Postcode)";
			}
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, summaryID);
			st.setInt(2, summarySeqNo);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				boolean isFilter = false;
				String taxInvNo = rs.getString("TaxInvNo");
				String sourceType = rs.getString("SourceType");
				String ownerName = rs.getString("OwnerName");
				
				for (int z=0; z<taxInvFilterList.size(); z++) {
					HashMap<String, String> filterList = taxInvFilterList.get(z);
					String filterWord  = filterList.get("FilterWord");
					String sourceSystem = filterList.get("SourceSystem");
					
					if (sourceSystem.equalsIgnoreCase(sourceType)) {
						if (ownerName.matches(filterWord)) {
							isFilter = true;
							break;
						}
					}
				}
				
				if (!isFilter) {
					taxInvNoList.add(taxInvNo);
				}
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
		}
		
		long end = System.currentTimeMillis(); 
		System.out.println("[DBCommon] getTaxInvListWithDocFormat() duration: " + formatNumber(((double)end - (double)start)/1000) + "s");
				
		return taxInvNoList;
	}
	
	public HashMap<Integer, HashMap<String, String>> getTaxInvDetails(String taxInvNo, String processYear) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getTaxInvDetails(" + taxInvNo + ") Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
        	
        	if(!taxInvNo.contains("'")) taxInvNo = "'" + taxInvNo + "'";
			
			String strSql = "select SummaryID, SummarySeqNo, SeqNo, DocType, SourceType, CompanyCode, ClientType, OwnerName, Address1, Address2, " +
					"Address3, Address4, Address5, PolicyNo, InsuredName, TaxInvoiceNo, convert(char(20), TaxInvoiceDate, 106) TaxInvoiceDate, OrgTaxInvNo, " +
					"convert(char(20), OrgTaxInvDate, 106) OrgTaxInvDate, BillNo, TaxCode, convert(char(20), TransDate, 106) TransDate, TransDesc, " +
					"ProdDesc, AmtExclGST, AmtGST, AMTInclGST, cast((case when (TaxRate is not null) then (TaxRate * 100) else 0 end) as Decimal(8,2)) as TaxRate, " +
					"Notes, AgentGSTRegNo, AgentCode, SelfBillApprovalNo, AIAGSTRegNo, Postcode, AgentType, CovPeriod, IsProcess, TaxDescription " +
					"from tbl_TaxInv_" + processYear + " where TaxInvoiceNo in (" + taxInvNo + ") and DocType is not null " +
					"order by tbl_TaxInv_" + processYear + ".TransDate";
			
			//convert( char(20), TransDate, 106 ) TransDate
			
			st = conn.prepareStatement(strSql);
			
			//st.setString(1, taxInvNo);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			Double totalIncGST = 0.0;
			Double totalGST = 0.0;
			Double totalExcGST = 0.0;
			
			boolean isAfterGST = false;
			String AIAGSTRegNo = "";
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				for (int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if (!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if (!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        
			        if ("AmtExclGST".equalsIgnoreCase(columnName)) {
			        	if (columnVal != null && columnVal.trim().length() > 0) {
			        		totalExcGST += Double.parseDouble(columnVal);
			        	}
			        }
			        
			        if ("AmtGST".equalsIgnoreCase(columnName)) {
			        	if (columnVal != null && columnVal.trim().length() > 0) {
			        		totalGST += Double.parseDouble(columnVal);
			        	}
			        }
			        
			        if ("AMTInclGST".equalsIgnoreCase(columnName)) {
			        	if (columnVal != null && columnVal.trim().length() > 0) {
			        		totalIncGST += Double.parseDouble(columnVal);
			        	}
			        }
			        
			        if("TransDate".equalsIgnoreCase(columnName)) {
			        	if(columnVal != null && columnVal.trim().length() > 0) {
			        		SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy");
			        		Date transDate = format.parse(columnVal);
			        		Date compareDate = format.parse("01 Sep 2018");
			        		
			        		if(transDate.compareTo(compareDate) >= 0) isAfterGST = true;
			        	}
			        }
			        
			        if("AIAGSTRegNo".equalsIgnoreCase(columnName)) {
			        	if(columnVal != null && columnVal.trim().length() > 0) {
			        		AIAGSTRegNo = columnVal;
			        	}
			        }
			        
			        // always fixed the GST percentage value to 6% (TaxRate)
			        /*if("TaxRate".equalsIgnoreCase(columnName)) {
			        	columnVal = "6.00";
			        }*/
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
			
			for(int i=0; i<rsData.size(); i++) {
				HashMap<String, String> rowData = rsData.get(i);
	        	rowData.put("totalIncGST", String.valueOf(totalIncGST));
	        	rowData.put("totalGST", String.valueOf(totalGST));
	        	rowData.put("totalExcGST", String.valueOf(totalExcGST));
	        	
	        	// only applied to GST templates
	        	if(isAfterGST) {
	        		rowData.put("TaxLabel", "INVOICE");
		        	rowData.put("AIAGSTRegNoLabel", "");
		        	rowData.put("InvNoLabel", "Invoice No :");
		        	rowData.put("OrigInvNoLabel", "Orig. Inv. No :");
		        	rowData.put("OrigInvDateLabel", "Orig. Inv. Date :");
	        	} else {
	        		rowData.put("TaxLabel", "TAX INVOICE");
		        	rowData.put("AIAGSTRegNoLabel", "GST Registration No: " + AIAGSTRegNo);
		        	rowData.put("InvNoLabel", "Tax Invoice No :");
		        	rowData.put("OrigInvNoLabel", "Orig. Tax Inv. No :");
		        	rowData.put("OrigInvDateLabel", "Orig. Tax Inv. Date :");
	        	}
	        }
			
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getTaxInvDetails(" + taxInvNo + ") End --------------------------");
        } catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getTaxInvDetails() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public String getDocFormat (HashMap<String, String> taxInvMaster) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		String docFormat = null;
		
		long start = System.currentTimeMillis();
						
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getDocFormat() Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = null;
			String sourceSystem = taxInvMaster.get("SourceType");
			String clientType = taxInvMaster.get("ClientType");
			String docType = taxInvMaster.get("DocType");
			String agentType = taxInvMaster.get("AgentType");
			
			if (agentType != null && agentType.trim().length() > 0) {
				strSql = "SELECT DocFormat FROM tbl_DocFormatLK WHERE SourceSystem = ? and DocType = ? and AgentType = ? and IsT2 = ?";
				st = conn.prepareStatement(strSql);
				
				st.setString(1, sourceSystem);
				st.setString(2, docType);
				st.setString(3, agentType);
				st.setString(4, "N");
				
			} else {
				strSql = "SELECT DocFormat FROM tbl_DocFormatLK WHERE SourceSystem = ? and ClientType = ? and DocType = ? and IsT2 = ?";
				st = conn.prepareStatement(strSql);
				
				st.setString(1, sourceSystem);
				st.setString(2, clientType);
				st.setString(3, docType);
				st.setString(4, "N");
			}
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				docFormat = rs.getString("DocFormat");
			}
			
//			System.out.println("-------------------------- [" + new java.util.Date() + "] getDocFormat() End --------------------------");
		} catch(Exception io){
			io.printStackTrace();
	    } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getDocFormat() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return docFormat;
	}
	
	public boolean addToImgDB(String processID, int SummarySeqNo, int seqNo, ByteArrayOutputStream pendReqLOCBaos, String isHardCopy, String isPrinted, String sourceType, String inputType) {
		return addToImgDB(processID, SummarySeqNo, seqNo, pendReqLOCBaos, isHardCopy, isPrinted, sourceType, inputType, null);
	}
		
	public boolean addToImgDB(String processID, int SummarySeqNo, int seqNo, ByteArrayOutputStream pendReqLOCBaos, String isHardCopy, String isPrinted, String sourceType, String inputType, String inputFileName) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		boolean returnVal = false;
		String isSave2ImgDB = "";
		String save2FolderPath = "";
		
		long start = System.currentTimeMillis();
		
		try{
			conn = DBUtil.getConnection("bicor");
			
			if (pendReqLOCBaos != null && pendReqLOCBaos.toByteArray().length > 0) {
				InputStream fis = new ByteArrayInputStream(pendReqLOCBaos.toByteArray());
				
				if ("B".equalsIgnoreCase(inputType)) {
					//------------------------------------------- START Define save to Imaging Folder or create pdf to folder -------------------------------------------
					String imgDestSQL = "select folderName, isImgDB from tbl_TaxInvDest where SourceType = ?";
					
					st = conn.prepareStatement(imgDestSQL);
					st.setString(1, sourceType);
					
					rs = st.executeQuery();
					
					while(rs.next()) {
						isSave2ImgDB = rs.getString("isImgDB");
						save2FolderPath = rs.getString("folderName");
					}
					//------------------------------------------- END Define save to Imaging Folder or create pdf to folder -------------------------------------------
					
					
					if ("Y".equalsIgnoreCase(isSave2ImgDB) && (save2FolderPath == null || save2FolderPath.trim().length() == 0)) {
						synchronized(this) {
							//delete img from imgDB
							//String deleteSQL = "DELETE FROM tbl_TaxInvImg WHERE TaxInvID = ? and SummarySeqNo = ? and SeqNo = ? OR (CreatedDate < DATEADD(MINUTE, -60, getDate()) and (IsPrinted not in ('R')))";
							/*String deleteSQL = "DELETE FROM tbl_TaxInvImg WHERE TaxInvID = ? and SummarySeqNo = ? and SeqNo = ? OR (CreatedDate < DATEADD(MINUTE, -60, getDate()))";
							st = conn.prepareStatement(deleteSQL);
							
							st.setString(1, processID);
							st.setInt(2, SummarySeqNo);
							st.setInt(3, seqNo);
							st.executeUpdate();*/
							
							//insert img to imgDB
							String addSQL = "INSERT INTO tbl_TaxInvImg (TaxInvID, SummarySeqNo, SeqNo, TaxInvData, IsHardCopy, isPrinted, CreatedDate) values (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
							
							st = conn.prepareStatement(addSQL);
							st.setString(1, processID);
							st.setInt(2, SummarySeqNo);
							st.setInt(3, seqNo);
							st.setBinaryStream(4, fis);
							st.setString(5, isHardCopy);
							st.setString(6, isPrinted);
							st.execute();
						}
					} else if (save2FolderPath != null && save2FolderPath.trim().length() > 0) {
						//\\SPMYNAS00013\GSTProject\
						//ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
						//PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "GAMTXT", "USER", "PASSWD");
						
						//NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", pwdFile.getUserId(), pwdFile.getPassword());
						NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "kapdcom", "Nd6F#wh6vL");
//						NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "asnp71g", "2345_wert");
						
						SmbFile remoteFile = null;
						if(inputFileName != null) {
							SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
							String currentTime = sdf.format(new Date());
							remoteFile = new SmbFile(save2FolderPath + sourceType + "_" + inputFileName + "_" + currentTime + "_" + SummarySeqNo + "_" + seqNo + ".pdf", auth);
							
						} else {
							remoteFile = new SmbFile(save2FolderPath + sourceType + "_" + processID + "_" + SummarySeqNo + "_" + seqNo + ".pdf", auth);
						}
						
						remoteFile.connect(); //Try to connect
			            
			            OutputStream out = new BufferedOutputStream(new SmbFileOutputStream(remoteFile));
			            
			            byte[] buffer = new byte[4096];
			            int len = 0; //Read length
			            while ((len = fis.read(buffer)) != -1) {
			                out.write(buffer, 0, len);
			            }
			            out.flush();
					}
				} else {
					synchronized(this) {
						//delete img from imgDB
						//String deleteSQL = "DELETE FROM tbl_TaxInvImg WHERE TaxInvID = ? OR (CreatedDate < DATEADD(MINUTE, -60, getDate()) and (IsPrinted not in ('R')))";
						/*String deleteSQL = "DELETE FROM tbl_TaxInvImg WHERE TaxInvID = ? OR (CreatedDate < DATEADD(MINUTE, -60, getDate()))";
						st = conn.prepareStatement(deleteSQL);
						
						st.setString(1, processID);
						st.executeUpdate();*/
						
						//insert img to imgDB
						String addSQL = "INSERT INTO tbl_TaxInvImg (TaxInvID, SummarySeqNo, SeqNo, TaxInvData, IsHardCopy, isPrinted, CreatedDate) values (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
						
						st = conn.prepareStatement(addSQL);
						st.setString(1, processID);
						st.setInt(2, SummarySeqNo);
						st.setInt(3, seqNo);
						st.setBinaryStream(4, fis);
						st.setString(5, isHardCopy);
						st.setString(6, isPrinted);
						st.execute();
					}
				}
				
				//---------------------------------------------------------- START For Debug only ----------------------------------------------------------
				/*OutputStream debugFile = new FileOutputStream(new File("D:/project/PrintingAgent/pdf/" + processID + "_" + seqNo + ".pdf"));
				byte[] bytes = new byte[1024];
				int read = 0;
				while ((read = fis.read(bytes)) != -1) {
					debugFile.write(bytes, 0, read);
					
//					String s = new String(bytes);
				}*/
				//---------------------------------------------------------- END For Debug only ----------------------------------------------------------
								
				fis.close();				
			}
			
			returnVal = true;
		} catch(DuplicateFormatFlagsException dke) {
			System.out.println("DBCommon.addToImgDB() DuplicateKeyException: " + dke.toString());
		
		} catch (Exception ex) {
			System.out.println(ex.toString());
			ex.printStackTrace();
			
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addToImgDB() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return returnVal;
	}
	
	public boolean isExistsInTaxInvImg(String taxInvId) {
		boolean exists = false;
		
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT TaxInvID FROM tbl_TaxInvImg WHERE TaxInvID = ?";
			st = conn.prepareStatement(strSql);
			
			st.setString(1, taxInvId);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				exists = true;
			}
		} catch(Exception ex) {
			System.out.println(ex.toString());
			ex.printStackTrace();
			
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
		}
		
		return exists;
	}
	
	public HashMap<Integer, HashMap<String, String>> getGSTSummary(String taxInvNo, String processYear) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getTaxInvDetails(" + taxInvNo + ") Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select TaxCode, TaxDescription, count(TaxCode) as TotalItem, sum(AMTInclGST) as TotalAmt, sum(AmtGST) as TotalGST " +
					"from tbl_TaxInv_" + processYear + " " +
					"where TaxInvoiceNo = ? " +
					"and DocType is not null " +
					"group by TaxCode, TaxDescription";
			
			//convert( char(20), TransDate, 106 ) TransDate
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, taxInvNo);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				for (int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if (!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if (!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
			
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getTaxInvDetails(" + taxInvNo + ") End --------------------------");
        } catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getGSTSummary() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public HashMap<String, String> getPrintSummary(String printSummaryID, String seqNo) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<String, String> rsData = new HashMap<String, String>();
		
		long start = System.currentTimeMillis();
		
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getPrintSummary(" + printSummaryID + ") Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
			
        	String strSql = "SELECT * FROM tbl_TaxInvPrintSummary WHERE PrintSummaryID = ? and SeqNo = ?";
			
			//convert( char(20), TransDate, 106 ) TransDate
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, printSummaryID);
			st.setInt(2, Integer.valueOf(seqNo));
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			
			if (rs.next()) {
				for (int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if (!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if (!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        rsData.put(columnName, columnVal);
			    }
			}
						
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getPrintSummary(" + printSummaryID + ") End --------------------------");
        } catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPrintSummary() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public List<Integer> getPrintSummarySeqNo (String printSummaryID){
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Integer> seqNoList = new ArrayList<Integer>();
		
		long start = System.currentTimeMillis();
		
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getPrintSummarySeqNo(" + printSummaryID + ") Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT distinct(SeqNo) FROM tbl_TaxInvPrintSummary WHERE PrintSummaryID = ? ORDER BY SeqNo";
						
			st = conn.prepareStatement(strSql);
			
			st.setString(1, printSummaryID);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				seqNoList.add(rs.getInt("SeqNo"));				
			}
						
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getPrintSummarySeqNo(" + printSummaryID + ") End --------------------------");
        } catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPrintSummarySeqNo() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return seqNoList;		
	}

	public String getTaxInvNoExists(String processID, String processYear, int seqNo) {
		String foundStr = null;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
						
        try {
        	conn = DBUtil.getConnection("bicor");
        	
        	String strSql = "select TaxInvoiceNo FROM tbl_TaxInv_" + processYear + " WHERE TaxInvoiceNo in (" +
        			"select TaxInvoiceNo from tbl_TaxInv_" + processYear + " WHERE SummaryID = ? and SummarySeqNo = ?) " +
        			"and (SummaryID != ? OR (SummaryID = ? and SummarySeqNo != ?))";
			st = conn.prepareStatement(strSql);
			
			st.setString(1, processID);
			st.setInt(2, seqNo);
			st.setString(3, processID);
			st.setString(4, processID);
			st.setInt(5, seqNo);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				if(foundStr == null) foundStr = "";
				foundStr += rs.getString("TaxInvoiceNo") + "\n";
			}
		} catch(Exception io) {
			io.printStackTrace();
			
	    } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
		}
        
        long end = System.currentTimeMillis(); 
		System.out.println("[DBCommon] getTaxInvNoExists() duration: " + formatNumber(((double)end - (double)start)/1000) + "s");
		
		return foundStr;
	}
	
	public boolean updateTaxInvDataIfExists(String processID, String processYear, int seqNo) {
		boolean success = true;
		
		long start = System.currentTimeMillis();
		
		try {
			removeTaxInvYear(processID, processYear, seqNo);
			updatePrintSummaryStatus(processID, seqNo, "E", "Duplicate tax invoices found!");
			removeTaxInvSumDet(processID, seqNo);
			
		} catch(Exception ex) {
			ex.printStackTrace();
			success = false;
		}
		
		long end = System.currentTimeMillis(); 
		System.out.println("[DBCommon] updateTaxInvDataIfExists() duration: " + formatNumber(((double)end - (double)start)/1000) + "s");
		
		return success;
	}

	private void removeTaxInvYear(String processID, String processYear, int seqNo) throws Exception {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
        	conn = DBUtil.getConnection("bicor");
        	
			String strSql = "DELETE FROM tbl_TaxInv_" + processYear + " WHERE SummaryID = ? AND SummarySeqNo = ?";
			st = conn.prepareStatement(strSql);
			
			st.setString(1, processID);
			st.setInt(2, seqNo);
			
			st.executeUpdate();
			
		} catch(Exception io) {
			throw io;
			
	    } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.removeTaxInvYear() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	}
	
	private void removeTaxInvSumDet(String processID, int seqNo) throws Exception {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
        	conn = DBUtil.getConnection("bicor");
        	
			String strSql = "DELETE FROM tbl_TaxInvPrintSumDet WHERE SummaryID = ? AND SummarySeqNo = ?";
			st = conn.prepareStatement(strSql);
			
			st.setString(1, processID);
			st.setInt(2, seqNo);
			
			st.executeUpdate();
			
		} catch(Exception io) {
			throw io;
			
	    } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.removeTaxInvSumDet() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	}
	
	public void removeTaxInvEntry(String processID, String processYear) throws Exception {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
        	conn = DBUtil.getConnection("bicor");
        	
			String strSql = "DELETE FROM tbl_TaxInv_" + processYear + " WHERE TaxInvoiceNo = ?";
			st = conn.prepareStatement(strSql);
			
			st.setString(1, processID);
			
			st.executeUpdate();
			
		} catch(Exception io) {
			throw io;
			
	    } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.removeTaxInvEntry() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	}

	public String getSourceTypeDesc (String srcType) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		String srcTypeDesc = "";
		
		long start = System.currentTimeMillis();
						
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getDocFormat() Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select LKDesc from tbl_PrintAgtLK where LKType = 'SourceType' and LKCode = ?";
			st = conn.prepareStatement(strSql);
			st.setString(1, srcType);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				srcTypeDesc = "(" + srcType + ")" + rs.getString("LKDesc");
				
			}
			
//			System.out.println("-------------------------- [" + new java.util.Date() + "] getDocFormat() End --------------------------");
		} catch(Exception io){
			io.printStackTrace();
	    } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getSourceTypeDesc() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return srcTypeDesc;
	}
	
	public String formatNumber(double number) {
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);
		nf.setGroupingUsed(false);
		
		return nf.format(number);
	}

	public HashMap<Integer, HashMap<String, String>> checkAndConvertTo10CharPolNo(String sourceType, HashMap<Integer, HashMap<String, String>> taxInvRS) {
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		try {
			if(taxInvRS != null && taxInvRS.size() > 0) {
				for(int i = 0; i < taxInvRS.size(); i++) {
					HashMap<String, String> rsRow = taxInvRS.get(i);
					
					if(rsRow.get("PolicyNo") != null && rsRow.get("PolicyNo").length() == 8) {
						String policyNo = rsRow.get("PolicyNo");
						String fullPolicyNo = "";
						
						// convert to 10 char policy number based on sourceType
						if("LA".equalsIgnoreCase(sourceType) || "T1".equalsIgnoreCase(sourceType)) {
							fullPolicyNo = getLAPolicyWithCheckDigit(policyNo);
							
						} else if("P1".equalsIgnoreCase(sourceType)) {
							// the first 2 char will be upper cased and will check between A to Z
							//if(startsBetween(policyNo, 'A', 'Z', 0) && startsBetween(policyNo, 'A', 'Z', 1))
							//	fullPolicyNo = getPAPolicyWithCheckDigit("", policyNo);
							
							if(!policyNo.substring(0, 2).equalsIgnoreCase("P0") && 
									!policyNo.substring(0, 2).equalsIgnoreCase("P8")) {
								fullPolicyNo = getPAPolicyWithCheckDigit("", policyNo);
							}
						}
						
						// replace with 10 char policy number
						if(fullPolicyNo != null && fullPolicyNo.length() == 10) {
							rsRow.put("PolicyNo", fullPolicyNo);
						}
					}
					
					rsData.put(i, rsRow);
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return rsData;
	}
	
	protected String getPAPolicyWithCheckDigit(String companyCode, String policyNumber) {
		Connection conn = null;
		CallableStatement cs = null;
		
		try {
			conn = DBUtil.getConnection("Common");
			
			cs = conn.prepareCall("{call db_iws..po_iw_pa_check_digit(?, ?, ?)}");
			cs.setString(1, companyCode);
			cs.setString(2, policyNumber);
			cs.registerOutParameter(3, Types.VARCHAR);
			
			cs.execute();
			policyNumber = (String)cs.getObject(3);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try { cs.close(); } catch (Exception e) { /* ignored */ }
		    try { conn.close(); } catch (Exception e) { /* ignored */ }
		    
		    cs = null;
		    conn = null;
		}
		
		return policyNumber;
	}
	
	protected String getLAPolicyWithCheckDigit(String policyNumber) {
		Connection conn = null;
		CallableStatement cs = null;
		
		try {
			conn = DBUtil.getConnection("Common");
			
			cs = conn.prepareCall("{call db_iws..po_iw_il_check_digit(?, ?)}");
			cs.setString(1, policyNumber);
			cs.registerOutParameter(2, Types.VARCHAR);
			
			cs.execute();
			policyNumber = (String)cs.getObject(2);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try { cs.close(); } catch (Exception e) { /* ignored */ }
		    try { conn.close(); } catch (Exception e) { /* ignored */ }
		    
		    cs = null;
		    conn = null;
		}
		
		return policyNumber;
	}
	
	protected boolean startsBetween(String s, char lowest, char highest, int location) {
	    char c = s.charAt(location);
	    c = Character.toUpperCase(c);
	    return c >= lowest && c <= highest;
	}
	
	public HashMap<Integer, HashMap<String, String>> getTaxInvFilterList() {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getTaxInvFilterList(" + taxInvNo + ") Start --------------------------");
        	
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT SourceSystem, FilterWord FROM tbl_TaxInvFilter";
			
			st = conn.prepareStatement(strSql);
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				for (int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if (!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if (!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
			
//        	System.out.println("-------------------------- [" + new java.util.Date() + "] getTaxInvFilterList(" + taxInvNo + ") End --------------------------");
        } catch(Exception io){
			io.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getTaxInvFilterList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public List<String> getTableYear() {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<String> tableYear = new ArrayList<String>();
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "select TableYear from tbl_TaxInv_Year order by TableYear desc";
			
			st = conn.prepareStatement(strSql);
			rs = st.executeQuery();
			
			while (rs.next()) {
				tableYear.add(rs.getString("TableYear"));				
			}
		} catch(Exception ex){
			ex.printStackTrace();
        } finally {
			try {
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getTableYear() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		return tableYear;
	}

	public boolean addData2PolicyTable(String uniqueId, PolicyInfo policyInfo) {
		boolean isProcess = false;
		Date startDate = new java.util.Date();
		
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		String debugMsg = "";
		
		long start = System.currentTimeMillis();
		
		try {
			System.out.println("-------------------------------- [" + startDate + "] [DBCommon] addData2PolicyTable Start --------------------------------");
			
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_ep_PolInfo (PolicyID, CompanyCode, PolicyNo, InsuredName, FaceAmount, " +
					"PolicyDate, PlanName, IssueDate, ExpiryDate, InsuredAge, AgeAdmitted, Gender, Currency, InsuredMykad, " +
					"OwnerName, OwnerMykad, OwnerAge, OwnerGender, PolicyDesc, GSTAmount, PremiumAmount, TotalAmount, " +
					"CreatedBy, CreatedDate) VALUES " +
					"(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, getDate())";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, uniqueId);
			st.setString(2, policyInfo.getCompanyCode());
			st.setString(3, policyInfo.getPolicyNo());
			st.setString(4, policyInfo.getInsuredName());
			st.setDouble(5, policyInfo.getFaceAmount().doubleValue());
			st.setString(6, GenericUtil.dateToStrDb(policyInfo.getPolicyDate()));
			st.setString(7, policyInfo.getPlanName());
			st.setString(8, GenericUtil.dateToStrDb(policyInfo.getIssueDate()));
			st.setString(9, GenericUtil.dateToStrDb(policyInfo.getExpiryDate()));
			st.setInt(10, policyInfo.getInsuredAge());
			st.setString(11, policyInfo.getAgeAdmitted());
			st.setString(12, policyInfo.getGender());
			st.setString(13, policyInfo.getCurrency());
			st.setString(14, policyInfo.getInsuredMykad());
			st.setString(15, policyInfo.getOwnerName());
			st.setString(16, policyInfo.getOwnerMykad());
			st.setInt(17, policyInfo.getOwnerAge());
			st.setString(18, policyInfo.getOwnerGender());
			st.setString(19, policyInfo.getPolicyDesc());
			st.setDouble(20, policyInfo.getGstAmount().doubleValue());
			st.setDouble(21, policyInfo.getPremiumAmount().doubleValue());
			st.setDouble(22, policyInfo.getTotalAmount().doubleValue());
			st.setString(23, "SYSTEM");
			
			debugMsg = st.toString();
			
			st.addBatch();
			st.executeBatch();
			
			isProcess = true;
			
			System.out.println("-------------------------------- [" + startDate + "][" + new java.util.Date() + "] [DBCommon] addData2PolicyTable End --------------------------------");
			
		} catch(Exception io){
			try {
				conn.rollback();
				
			} catch (Exception ex) {}
			
			System.out.println(debugMsg);
			io.printStackTrace();
			
        } finally {
			try {
				conn.commit();
				conn.setAutoCommit(true);
				
				if (st != null) st.close();
				if (rs != null) rs.close();				
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addData2PolicyTable() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	
		return isProcess;
	}

	public boolean addData2CoverageTable(String uniqueId, PolicyInfo policyInfo, AppForm appForm) {
		boolean isProcess = false;
		CommonFileUtil cu = new CommonFileUtil();
		
		Date startDate = new java.util.Date();
		
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		String debugMsg = "";
		
		long start = System.currentTimeMillis();
		
		try {
			System.out.println("-------------------------------- [" + startDate + "] [DBCommon] addData2CoverageTable Start --------------------------------");
			
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_ep_PolCoverage (PolicyID, CovType, CoverageName, FormNo, ExpiryDate, " +
					"BenefitAmount, PremiumAmount, CeasedDate, CreatedBy, CreatedDate) VALUES " +
					"(?, ?, ?, ?, ?, ?, ?, ?, ?, getDate())";
			
			st = conn.prepareStatement(strSql);
			
			List<PolCoverage> polCovList = null;
			String covType = "";
			
			if(policyInfo != null) {
				polCovList = policyInfo.getCoverages();
				covType = cu.getPolCovType();
				
			} /*else if(appForm != null) {
				polCovList = appForm.getPlans();
				covType = cu.getAppCovType();
			}*/
			
			for(PolCoverage coverage: polCovList) {
				st.setString(1, uniqueId);
				st.setString(2, covType);
				st.setString(3, coverage.getCoverageName());
				st.setString(4, !cu.isBlank(coverage.getFormNo())? coverage.getFormNo(): null);
				st.setString(5, !cu.isBlank(coverage.getExpiryDate())? GenericUtil.dateToStrDb(coverage.getExpiryDate()): null);
				st.setDouble(6, !cu.isBlank(coverage.getBenefitAmount())? coverage.getBenefitAmount().doubleValue(): 0);
				st.setDouble(7, !cu.isBlank(coverage.getPremiumAmount())? coverage.getPremiumAmount().doubleValue(): 0);
				st.setString(8, !cu.isBlank(coverage.getCeasedDate())? GenericUtil.dateToStrDb(coverage.getCeasedDate()): null);
				st.setString(9, "SYSTEM");
				
				debugMsg = st.toString();
				
				st.addBatch();
			}
			
			st.executeBatch();
			
			isProcess = true;
			
			System.out.println("-------------------------------- [" + startDate + "][" + new java.util.Date() + "] [DBCommon] addData2CoverageTable End --------------------------------");
			
		} catch(Exception io){
			try {
				conn.rollback();
				
			} catch (Exception ex) {}
			
			System.out.println(debugMsg);
			io.printStackTrace();
			
        } finally {
			try {
				conn.commit();
				conn.setAutoCommit(true);
				
				if (st != null) st.close();
				if (rs != null) rs.close();				
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addData2CoverageTable() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	
		return isProcess;
	}

	public boolean addData2AppFormTable(String uniqueId, AppForm appForm) {
		boolean isProcess = false;
		Date startDate = new java.util.Date();
		
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		String debugMsg = "";
		
		long start = System.currentTimeMillis();
		
		try {
			System.out.println("-------------------------------- [" + startDate + "] [DBCommon] addData2AppFormTable Start --------------------------------");
			
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_ep_AppForm (PolicyID, PolicyNo, InsuredName, MykadNo, DateOfBirth, Gender, " +
					"Nationality, Occupation, Address, Postcode, TelNo, Height, Weight, PlanName, SumAssured, " +
					"qIsSmoke, qCigaretteNo, qIsCriticalIllness, qIsSymptoms, qIsDefects, qIsInsAccept, IsReceiveInfo, " +
					"PolLanguage, CreatedBy, CreatedDate) " +
					"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, getDate())";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, uniqueId);
			st.setString(2, appForm.getPolicyNo());
			st.setString(3, appForm.getInsuredName());
			st.setString(4, appForm.getMykadNo());
			st.setString(5, GenericUtil.dateToStrDb(appForm.getDateOfBirth()));
			st.setString(6, appForm.getGender());
			st.setString(7, appForm.getNationality());
			st.setString(8, appForm.getOccupation());
			st.setString(9, appForm.getAddress());
			st.setString(10, appForm.getPostcode());
			st.setString(11, appForm.getTelNo());
			st.setFloat(12, appForm.getHeight());
			st.setFloat(13, appForm.getWeight());
			st.setString(14, appForm.getPlanName());
			st.setDouble(15, appForm.getSumAssured().doubleValue());
			st.setString(16, appForm.getqIsSmoke());
			st.setInt(17, appForm.getqCigaretteNo());
			st.setString(18, appForm.getqIsCriticalIllness());
			st.setString(19, appForm.getqIsSymptoms());
			st.setString(20, appForm.getqIsDefects());
			st.setString(21, appForm.getqIsInsAccept());
			st.setString(22, appForm.getIsReceiveInfo());
			st.setString(23, appForm.getPolLanguage());
			st.setString(24, "SYSTEM");
			
			debugMsg = st.toString();
			
			st.addBatch();
			st.executeBatch();
			
			isProcess = true;
			
			System.out.println("-------------------------------- [" + startDate + "][" + new java.util.Date() + "] [DBCommon] addData2AppFormTable End --------------------------------");
			
		} catch(Exception io){
			try {
				conn.rollback();
				
			} catch (Exception ex) {}
			
			System.out.println(debugMsg);
			io.printStackTrace();
			
        } finally {
			try {
				conn.commit();
				conn.setAutoCommit(true);
				
				if (st != null) st.close();
				if (rs != null) rs.close();				
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addData2AppFormTable() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	
		return isProcess;
	}
	
	public boolean addData2EntityTable(String uniqueId, List<RelatedEntity> entities, String type) {
		boolean isProcess = false;
		CommonFileUtil cu = new CommonFileUtil();
		
		Date startDate = new java.util.Date();
		
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		String debugMsg = "";
		
		long start = System.currentTimeMillis();
		
		try {
			System.out.println("-------------------------------- [" + startDate + "] [DBCommon] addData2EntityTable Start --------------------------------");
			
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_ep_RelatedEntity (PolicyID, EntityType, Name, Address, SharePercent, " +
					"IdNo, DateOfBirth, Relationship, CreatedBy, CreatedDate) VALUES " +
					"(?, ?, ?, ?, ?, ?, ?, ?, ?, getDate())";
			
			st = conn.prepareStatement(strSql);
			
			for(RelatedEntity entity: entities) {
				st.setString(1, uniqueId);
				st.setString(2, type);
				st.setString(3, entity.getName());
				st.setString(4, !cu.isBlank(entity.getAddress())? entity.getAddress(): null);
				st.setDouble(5, !cu.isBlank(entity.getSharePercent())? entity.getSharePercent().doubleValue(): 0);
				st.setString(6, !cu.isBlank(entity.getIdNo())? entity.getIdNo(): null);
				st.setString(7, !cu.isBlank(entity.getDateOfBirth())? GenericUtil.dateToStrDb(entity.getDateOfBirth()): null);
				st.setString(8, !cu.isBlank(entity.getRelationship())? entity.getRelationship(): null);
				st.setString(9, "SYSTEM");
				
				debugMsg = st.toString();
				
				st.addBatch();
			}
			
			st.executeBatch();
			
			isProcess = true;
			
			System.out.println("-------------------------------- [" + startDate + "][" + new java.util.Date() + "] [DBCommon] addData2EntityTable End --------------------------------");
			
		} catch(Exception io){
			try {
				conn.rollback();
				
			} catch (Exception ex) {}
			
			System.out.println(debugMsg);
			io.printStackTrace();
			
        } finally {
			try {
				conn.commit();
				conn.setAutoCommit(true);
				
				if (st != null) st.close();
				if (rs != null) rs.close();				
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.addData2EntityTable() duration: " + GenericUtil.calculateTime(start) + "s");
		}
	
		return isProcess;
	}
	
	public PolicyInfo getPolicyDetails(String companyCode, String policyNo, String covType) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		PolicyInfo policyInfo = new PolicyInfo();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select pi.PolicyID, CompanyCode, PolicyNo, InsuredName, FaceAmount, PolicyDate, " +
					"PlanName, IssueDate, pi.ExpiryDate, InsuredAge, AgeAdmitted, Gender, Currency, InsuredMykad, " +
					"OwnerName, OwnerMykad, OwnerAge, OwnerGender, " +
					"PolicyDesc, GSTAmount, pi.PremiumAmount, TotalAmount, CoverageName, FormNo, " +
					"pc.ExpiryDate as CovExpiryDate, pc.BenefitAmount as CovBenefitAmount, " +
					"pc.PremiumAmount as CovPremiumAmount " +
					"from tbl_ep_PolInfo pi, tbl_ep_PolCoverage pc " +
					"where pi.CompanyCode = ? and pi.PolicyNo = ? and pi.PolicyID = pc.PolicyID and pc.CovType = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, companyCode);
			st.setString(2, policyNo);
			st.setString(3, covType);
			
			rs = st.executeQuery();
			
			List<PolCoverage> coverages = new ArrayList<PolCoverage>();
			policyInfo.setCoverages(coverages);
			
			PolCoverage coverage = null;
			int row = 0;
			
			while(rs.next()) {
				if(row == 0) {
					policyInfo.setPolicyId(rs.getString("PolicyID"));
					policyInfo.setCompanyCode(rs.getString("CompanyCode"));
					policyInfo.setPolicyNo(rs.getString("PolicyNo"));
					policyInfo.setInsuredName(rs.getString("InsuredName"));
					policyInfo.setFaceAmount(new BigDecimal(rs.getString("FaceAmount")));
					policyInfo.setPolicyDate(GenericUtil.parseDate(rs.getString("PolicyDate"), "yyyy-MM-dd HH:mm:ss"));
					policyInfo.setPlanName(rs.getString("PlanName"));
					policyInfo.setIssueDate(GenericUtil.parseDate(rs.getString("IssueDate"), "yyyy-MM-dd HH:mm:ss"));
					policyInfo.setExpiryDate(GenericUtil.parseDate(rs.getString("ExpiryDate"), "yyyy-MM-dd HH:mm:ss"));
					policyInfo.setInsuredAge(rs.getInt("InsuredAge"));
					policyInfo.setAgeAdmitted(rs.getString("AgeAdmitted"));
					policyInfo.setGender(rs.getString("Gender"));
					policyInfo.setCurrency(rs.getString("Currency"));
					policyInfo.setInsuredMykad(rs.getString("InsuredMykad"));
					policyInfo.setOwnerName(rs.getString("OwnerName"));
					policyInfo.setOwnerMykad(rs.getString("OwnerMykad"));
					policyInfo.setOwnerAge(rs.getInt("OwnerAge"));
					policyInfo.setOwnerGender(rs.getString("OwnerGender"));
					policyInfo.setPolicyDesc(rs.getString("PolicyDesc"));
					policyInfo.setGstAmount(new BigDecimal(rs.getString("GSTAmount")));
					policyInfo.setPremiumAmount(new BigDecimal(rs.getString("PremiumAmount")));
					policyInfo.setTotalAmount(new BigDecimal(rs.getString("TotalAmount")));
				}
				
				coverage = new PolCoverage();
				
				coverage.setCoverageName(rs.getString("CoverageName"));
				coverage.setFormNo(rs.getString("FormNo"));
				coverage.setExpiryDate(GenericUtil.parseDate(rs.getString("CovExpiryDate"), "yyyy-MM-dd HH:mm:ss"));
				coverage.setBenefitAmount(new BigDecimal(rs.getString("CovBenefitAmount")));
				coverage.setPremiumAmount(new BigDecimal(rs.getString("CovPremiumAmount")));
				
				coverages.add(coverage);
			}
        } catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPolicyDetails() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return policyInfo;
	}
	
	public AppForm getAppFormDetails(String policyId) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		AppForm appForm = new AppForm();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select af.PolicyID, PolicyNo, InsuredName, MykadNo, DateOfBirth, Gender, Nationality, " +
					"Occupation, Address, Postcode, TelNo, Height, Weight, PlanName, SumAssured, qIsSmoke, " +
					"qCigaretteNo, qIsCriticalIllness, qIsSymptoms, qIsDefects, qIsInsAccept, IsReceiveInfo, " +
					"PolLanguage " +
					"from tbl_ep_AppForm af where af.PolicyID = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyId);
			
			rs = st.executeQuery();
			
			/*List<PolCoverage> plans = new ArrayList<PolCoverage>();
			appForm.setPlans(plans);
			
			PolCoverage plan = null;
			int row = 0;*/
			
			while(rs.next()) {
				appForm.setPolicyId(rs.getString("PolicyID"));
				appForm.setPolicyNo(rs.getString("PolicyNo"));
				appForm.setInsuredName(rs.getString("InsuredName"));
				appForm.setMykadNo(rs.getString("MykadNo"));
				appForm.setDateOfBirth(GenericUtil.parseDate(rs.getString("DateOfBirth"), "yyyy-MM-dd HH:mm:ss"));
				appForm.setGender(rs.getString("Gender"));
				appForm.setNationality(rs.getString("Nationality"));
				appForm.setOccupation(rs.getString("Occupation"));
				appForm.setAddress(rs.getString("Address"));
				appForm.setPostcode(rs.getString("Postcode"));
				appForm.setTelNo(rs.getString("TelNo"));
				appForm.setHeight(new Float(rs.getString("Height")));
				appForm.setWeight(new Float(rs.getString("Weight")));
				appForm.setPlanName(rs.getString("PlanName"));
				appForm.setSumAssured(new BigDecimal(rs.getString("SumAssured")));
				
				appForm.setqIsSmoke(rs.getString("qIsSmoke"));
				appForm.setqCigaretteNo(rs.getInt("qCigaretteNo"));
				appForm.setqIsCriticalIllness(rs.getString("qIsCriticalIllness"));
				appForm.setqIsSymptoms(rs.getString("qIsSymptoms"));
				appForm.setqIsDefects(rs.getString("qIsDefects"));
				appForm.setqIsInsAccept(rs.getString("qIsInsAccept"));
				
				appForm.setIsReceiveInfo(rs.getString("IsReceiveInfo"));
				appForm.setPolLanguage(rs.getString("PolLanguage"));
				
				/*plan = new PolCoverage();
				
				plan.setCoverageName(rs.getString("CoverageName"));
				plan.setBenefitAmount(new BigDecimal(rs.getString("CovBenefitAmount")));
				
				plans.add(plan);*/
			}
			
			// add nominees and trustees
			appForm = getRelatedEntities(policyId, appForm);
			
        } catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getAppFormDetails() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return appForm;
	}

	private AppForm getRelatedEntities(String policyId, AppForm appForm) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		CommonFileUtil cu = new CommonFileUtil();
		
        try {
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select EntityType, Name, Address, SharePercent, IdNo, DateOfBirth, Relationship " +
					"from tbl_ep_RelatedEntity where PolicyID = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyId);
			
			rs = st.executeQuery();
			
			List<RelatedEntity> nominees = new ArrayList<RelatedEntity>();
			appForm.setNominees(nominees);
			
			List<RelatedEntity> trustees = new ArrayList<RelatedEntity>();
			appForm.setTrustees(trustees);
			
			RelatedEntity entity = null;
			
			while(rs.next()) {
				entity = new RelatedEntity();
				
				entity.setName(rs.getString("Name"));
				entity.setAddress(rs.getString("Address"));
				entity.setSharePercent(new BigDecimal(rs.getString("SharePercent")));
				entity.setIdNo(rs.getString("IdNo"));
				entity.setDateOfBirth(GenericUtil.parseDate(rs.getString("DateOfBirth"), "yyyy-MM-dd HH:mm:ss"));
				entity.setRelationship(rs.getString("Relationship"));
				
				if(cu.getAfNominee().equals(rs.getString("EntityType"))) {
					nominees.add(entity);
					
				} else if(cu.getAfTrustee().equals(rs.getString("EntityType"))) {
					trustees.add(entity);
				}
			}
        } catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getRelatedEntities() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return appForm;
	}
	
	public HashMap<String, String> getTemplates(String templateGroup) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		CommonFileUtil cu = new CommonFileUtil();
		HashMap<String, String> templMap = new HashMap<String, String>();
		
        try {
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select TemplCode, TemplType from tbl_ep_Template where TemplGroup = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, templateGroup);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				if(!cu.isBlank(rs.getString("TemplCode")) && !cu.isBlank(rs.getString("TemplType")))
					templMap.put(rs.getString("TemplCode"), rs.getString("TemplType"));
			}
        } catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getTemplates() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return templMap;
	}
	
	public String getSubTemplate(Integer Age) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		String subTemplate = null;
		long start = System.currentTimeMillis();
		
		CommonFileUtil cu = new CommonFileUtil();
        try {
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select TemplSubCode from tbl_ep_subTemplate" +
					" where "+ Age +" BETWEEN  MinAge AND MaxAge";
			System.out.println("Getting Sub Template Query " + strSql);
			st = conn.prepareStatement(strSql);
			rs = st.executeQuery();
			
			while(rs.next()) {
				if(!cu.isBlank(rs.getString("TemplSubCode")))
					subTemplate = rs.getString("TemplSubCode");
			}
        } catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getSubTemplates() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return subTemplate;
	}
	
	public Map<String,String> getPlanNames() {
		Map<String,String> planNames = new HashMap<String,String>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "select *  from tbl_ep_ProductTemplate ";
			st = conn.prepareStatement(strSql);
			rs = st.executeQuery();
			
			while(rs.next()) {
				String key = rs.getString("CompCode") + rs.getString("BasicPlan");
				String value = rs.getString("ProductName");
				
				planNames.put(key, value);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
		}
		
		return planNames;
	}
	
	public  String getTemplate(String compCode,String covCode){
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		String template = null;

        try {
        	conn = DBUtil.getConnection("bicor");
			
			String strSql = "select Template from tbl_ep_ProductTemplate where BasicPlan = ? and CompCode = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, covCode);
			st.setString(2, compCode);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				template = rs.getString("Template");
			}
        } catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
		}
        
        return template;
	}
	
	public HashMap<String, String> getSystemConfig() {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<String, String> rsData = new HashMap<String, String>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("bicor");
        	
			String strSql = "select ConfigCode, ConfigValue from tbl_PrintAgtConfig order by ConfigCode";
			
			st = conn.prepareStatement(strSql);
			rs = st.executeQuery();
			
			while(rs.next()) {
				String configCode = rs.getString("ConfigCode");
				String configValue = rs.getString("ConfigValue");
				
				rsData.put(configCode, configValue);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getSystemConfig() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}

	public List<PolicyInfo> getPolicyListToPrint(String policyStatus) {
		List<PolicyInfo> policyInfos = new ArrayList<PolicyInfo>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
        	
			String strSql = "select COMPANYCODE, POLICYNUMBER from EC_PRINT_STATUS " +
					"where STATUS = ? order by CREATEDDATETIME asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				PolicyInfo policyInfo = new PolicyInfo();
				
				String companyCode = rs.getString("COMPANYCODE");
				String policyNo = rs.getString("POLICYNUMBER");
				
				if(!cu.isBlank(companyCode) && !cu.isBlank(policyNo)) {
					policyInfo.setCompanyCode(companyCode);
					policyInfo.setPolicyNo(policyNo);
					
					policyInfos.add(policyInfo);
				}
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPolicyListToPrint() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return policyInfos;
	}
	
	public List<PolWebForm> getWebFormPolicyListToPrint(String policyStatus) {
		List<PolWebForm> policyWebForms = new ArrayList<PolWebForm>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
        	
			String strSql = "select COMPANYCODE, POLICYNUMBER from db_eappln..tbl_MDTA_PRINT_STATUS " +
					"where STATUS = ? order by CREATEDDATETIME asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				PolWebForm polWebForm = new PolWebForm();
				
				String companyCode = rs.getString("COMPANYCODE");
				String policyNo = rs.getString("POLICYNUMBER");
				
				if(!cu.isBlank(companyCode) && !cu.isBlank(policyNo)) {
					//polWebForm.setCompanyCode(companyCode);
					polWebForm.setPolicyNo(policyNo);
					
					policyWebForms.add(polWebForm);
				}
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getWebFormPolicyListToPrint() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return policyWebForms;
	}
	
	public List<AgentContract> getAgentContractListToPrint(String trxId , String contractType , String status) {
		List<AgentContract> agentContractList = new ArrayList<AgentContract>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("ipos");
			
			// TODO: continue
			String strSql = "select contract_id, trx_id,agent_rank,license_prod,contract_type,program_type,name,id_no,add_1,add_2,add_3," +
					"postcode,state,contracted_date,effective_date,agent_code,agent_email,agency_code,sts_code,applicant_sign_date," +
					"cast(applicant_sign as varchar(max)) applicant_sign , witness_name,witness_id_no,witness_sign_date,cast( witness_sign as varchar(max)) witness_sign ,email_to,email_cc,status,created_date," +
					"created_by,updated_date,updated_by,city from db_iRecruit..CONTRACT " +
				//	"where contract_id = 19 order by created_date asc";
						"where trx_id = ? and contract_type = ? and status = ? order by created_date asc";
				//	"where STATUS IS NULL order by created_date asc";
					//"where trx_id = 331 order by created_date asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, trxId);
			st.setString(2, contractType);
			st.setString(3, status);
			//st.setNull(1, java.sql.Types.VARCHAR);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				AgentContract agentContract = new AgentContract();
				
				String contractId = rs.getString("contract_id");
				trxId = rs.getString("trx_id");
				String agent_rank = rs.getString("agent_rank");
				String license_prod = rs.getString("license_prod");
				String contract_type = rs.getString("contract_type");
				String program_type = rs.getString("program_type");
				String name = rs.getString("name");
				String id_no = rs.getString("id_no");
				String add_1 = rs.getString("add_1");
				String add_2 = rs.getString("add_2");
				String add_3 = rs.getString("add_3");
				String postcode = rs.getString("postcode");
				String state = rs.getString("state");
				Date contracted_date = rs.getDate("contracted_date");
				Date effective_date = rs.getDate("effective_date");
				String agent_code = rs.getString("agent_code");
				String agent_email = rs.getString("agent_email");
				String agency_code = rs.getString("agency_code");
				String sts_code = rs.getString("sts_code");
				
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String apSignDate=rs.getString("applicant_sign_date");
				Date applicant_sign_date =formatter.parse(apSignDate);
				
				String applicant_sign = rs.getString("applicant_sign");
				String witness_name = rs.getString("witness_name");
				String witness_id_no = rs.getString("witness_id_no");
				
				String witSignDate=rs.getString("applicant_sign_date");
				Date witness_sign_date = formatter.parse(witSignDate);
				
				String witness_sign = rs.getString("witness_sign");
				String email_to = rs.getString("email_to");
				String email_cc = rs.getString("email_cc");
				String city = rs.getString("city");

				
				agentContract.setContractId((!cu.isBlank(contractId)) ? contractId : "");
				agentContract.setTrxId((!cu.isBlank(trxId)) ? trxId : "");
				agentContract.setAgentRank((!cu.isBlank(agent_rank)) ? agent_rank : "");
				agentContract.setLicenseProd((!cu.isBlank(license_prod)) ? license_prod : "");
			//	agentContract.setLicenseProd("Takaful");
				agentContract.setContractType((!cu.isBlank(contract_type)) ? contract_type : "");
				agentContract.setProgramType((!cu.isBlank(program_type)) ? program_type : "");
			//	agentContract.setProgramType("DADM Life Planner");
				agentContract.setAgentName((!cu.isBlank(name)) ? name : "");
				agentContract.setIdNo((!cu.isBlank(id_no)) ? id_no : "");
				agentContract.setAddress1((!cu.isBlank(add_1)) ? add_1 : "");
				agentContract.setAddress2((!cu.isBlank(add_2)) ? add_2 : "");
				agentContract.setAddress3((!cu.isBlank(add_3)) ? add_3 : "");
				agentContract.setPostcode((!cu.isBlank(postcode)) ? postcode : "");
				agentContract.setState((!cu.isBlank(state)) ? state : "");
				agentContract.setContractDate((!cu.isBlank(contracted_date)) ? contracted_date : null);
				agentContract.setEffectiveDate((!cu.isBlank(effective_date)) ? effective_date : null);
				agentContract.setAgentCode((!cu.isBlank(agent_code)) ? agent_code : "");
				agentContract.setAgentEmail((!cu.isBlank(agent_email)) ? agent_email : "");
				agentContract.setAgencyCode((!cu.isBlank(agency_code)) ? agency_code : "");
				agentContract.setStsCode((!cu.isBlank(sts_code)) ? sts_code : "");
				agentContract.setApplicantSignDate((!cu.isBlank(applicant_sign_date)) ? applicant_sign_date : null);
				System.out.println("[DBCommon][getAgentContractListToPrint] Applicant Sign Date is ..:"+agentContract.getApplicantSignDate());
				agentContract.setApplicantSign((!cu.isBlank(applicant_sign)) ? applicant_sign : "");
				agentContract.setWitnessName((!cu.isBlank(witness_name)) ? witness_name : "");
				agentContract.setWitnessIdNo((!cu.isBlank(witness_id_no)) ? witness_id_no : "");
				agentContract.setWitnessSignDate((!cu.isBlank(witness_sign_date)) ? witness_sign_date : null);
				agentContract.setWitnessSign((!cu.isBlank(witness_sign)) ? witness_sign : "");
				agentContract.setEmailTo((!cu.isBlank(email_to)) ? email_to : "");
				agentContract.setEmailCc((!cu.isBlank(email_cc)) ? email_cc : "");
				agentContract.setCity((!cu.isBlank(city)) ? city : "");
				agentContract.setAddr1(add_1+" "+add_2);
				agentContract.setAddr2(add_3+" "+postcode);
				agentContract.setAddr3(city+" "+state);
				
				agentContractList.add(agentContract);

			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getAgentContractListToPrint() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return agentContractList;
	}
	
	public List<String> getAgentTrxListToPrint(String agentStatus) {
		//List<AgentContract> agentContractList = new ArrayList<AgentContract>();
		List<String> trxID =  new ArrayList<String>();
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		//CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("ipos");
			
			// TODO: continue
			String strSql = "select trx_id from db_iRecruit..CONTRACT " +
				//	"where contract_id = 19 order by created_date asc";
						"where STATUS = ?  order by created_date asc";
				//	"where STATUS IS NULL order by created_date asc";
				//	"where trx_id = 46 order by created_date asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, agentStatus);
			//st.setNull(1, java.sql.Types.VARCHAR);

			rs = st.executeQuery();
			
			while(rs.next()) {
				String trxId = rs.getString("trx_id");
				if(! trxID.contains(trxId)){
					System.out.println("Adding Trx_Id.."+trxId );
					trxID.add(trxId);
				}
				

			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getAgentContractListToPrint() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return trxID;
	}
	
	public HashMap<Integer, HashMap<String, String>> getPolicyInfo(String companyCode, String policyNo) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
			
			String strSql = "select p.EC_POLICY_ID as PolicyID, p.EC_CLIENT_ID as ClientId, p.CREATEDDATETIME as PolicyDate, " +
					"p.CREATEDDATETIME as IssueDate, p.POLICY_EXPIRY_DATE as ExpiryDate, " +
					"rtrim(ltrim(isnull(c.NAME1,'') + ' ' + isnull(c.NAME2,'') + ' ' + isnull(c.NAME3,''))) as InsuredName, " +
					"rtrim(ltrim(isnull(c.NAME1,'') + ' ' + isnull(c.NAME2,'') + ' ' + isnull(c.NAME3,''))) as OwnerName, " +
					"c.GENDER as Gender, c.GENDER as OwnerGender, c.NRIC as InsuredMykad, " +
					"c.PASSPORTNO_OTHERS as InsuredPassport, c.NRIC as OwnerMykad, c.PASSPORTNO_OTHERS as OwnerPassport, " +
					"d.PAYMENTMODE as ModeOfPayment , d.SUMASSURED as FaceAmount, d.INSUREDAGE as InsuredAge, d.INSUREDAGE as OwnerAge, " +
					"d.PREMIUMAMOUNT as PremiumAmount, d.CURRENCY as Currency, d.PREMIUMAMOUNT as TotalAmount, " +
					"c.DOB as DateOfBirth, c.NATIONALITY as Nationality, c.OCCUPATION as Occupation, c.NATURE_OF_BIZ as NatureOfBiz, c.NAME_OF_EMPLOYER as EmployerName , " +
					"c.MOBILENUMBER as TelNo, c.HEIGHT as Height, c.WEIGHT as Weight, d.SUMASSURED as SumAssured, " +
					"c.IS_SMOKER as QIsSmoke, p.ISRECEIVEPROMOTIONS as IsReceiveInfo, p.CONTRACTLANGUAGE as PolLanguage, " +
					"a.ADDRESS1, a.ADDRESS2, a.ADDRESS3, a.CITYSTATE, a.COUNTRY, a.POSTCODE, c.EMAIL as Email " +
					"from EC_POLICY p, EC_CLIENT c, EC_PDS d, EC_ADDRESS a " +
					"where p.COMPANYCODE = ? and p.POLICYNUMBER = ? and p.EC_CLIENT_ID = c.EC_CLIENT_ID " +
					"and p.EC_PDS_ID = d.EC_PDS_ID and p.EC_CLIENT_ID = a.EC_CLIENT_ID";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, companyCode);
			st.setString(2, policyNo);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
        } catch(Exception io){
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPolicyInfo() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public String getOccupationClass(String OccCode , String PlanCode){
		
		String OccClass = "";
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		long start = System.currentTimeMillis();
		
		try{
			conn = DBUtil.getConnection("ipos");
			
			String strSql = "select * from EC_OCC_CLASS where PlanCode = ? and OccupationCode = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, PlanCode);
			st.setString(2, OccCode);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				OccClass = rs.getString("OccupationClass");
				System.out.println("DbCommon . OccupationClass .:"+OccClass);
			}
			
		}catch(Exception io){
			io.printStackTrace();
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPolCoverage() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		
		return OccClass;
	}
	
	public HashMap<Integer, HashMap<String, String>> getPolCoverage(String companyCode, String policyNo) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
			
			String strSql = "select cr.PLANCODE as PlanCode, cr.PLANSHORTNAME as PlanShortName, " +
					"p.POLICY_EXPIRY_DATE as ExpiryDate, '' as FormNo, cr.RIDSA as BenefitAmount, " +
					"cr.RIDPREM as PremiumAmount, 'N/A' as CeasedDate " +
					"from EC_POLICY p, EC_COVERAGE_INFO ci, EC_COVERAGE_RIDER cr " +
					"where p.COMPANYCODE = ? and p.POLICYNUMBER = ? and p.EC_COVERAGE_INFO_ID = ci.EC_COVERAGE_INFO_ID " +
					"and ci.EC_COVERAGE_INFO_ID = cr.EC_COVERAGE_INFO_ID order by cr.RIDPLANTYPE asc";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, companyCode);
			st.setString(2, policyNo);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
        } catch(Exception io){
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPolCoverage() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public HashMap<Integer, HashMap<String, String>> getPolWebInfo(String policyNo) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
			
        	String strSql = "select MCON.app_policyno as policyNo,MCON.app_serial_no as serialNo,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='ProductType' and Code = MCON.app_type_pri) as typePri," +
        			"(select Description from db_eappln..tbl_MDTA_Lookup where Type ='ProductType' and Code = MCON.app_type_sec) as typeSec,MCON.app_rc_date as rcDate,MCON.With_Ori_Signed_Form as withOriSignedForm," +
        			"MCON.App_Authorize_BankStaff_ID as appAuthorizeBankStaffID,MCON.app_selling_agent as appSellingAgent,MCON.app_bank_branch as appBankBranch,MCON.app_hse_loan_no as appHseLoanNo,MCON.app_CCSS_refno as appCCSSRefno,"+
        			"MCON.LA_PremiumPayable as laPremiumPayable,MCON.app_staff_name as appStaffName,MCON.app_witness_name as appWitnessName,MCON.app_witness_ic as appWitnessIc,MCON.app_witness_dated as appWitnessDate,"+
        			"MCLI.app_name as appName,MCLI.app_ic_new as appIcNew,MCLI.app_ic_other as appIcOther,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='Nationality' and Code = MCLI.APP_NATIONALITY) as appNATIONALITY,MCLI.app_dob as appDob,"+
        			"MCLI.app_age as appAge,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='Gender' and Code = MCLI.app_gender) as appGender,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='MaritalStatus' and Code = MCLI.app_marital) as appMarital,MCLI.APP_OCC_NATURE as APPOCCNATURE, " +
        			"MCLI.app_occ + ' - ' + (select occupation from db_eappln..Occupation where OCC_CODE = MCLI.app_occ) as appOcc ,"+
        			"MCLI.app_occclass as appOccclass,MCLI.app_add_line1 as appAddLine1,MCLI.app_add_line2 as appAddLine2,MCLI.app_add_line3 as appAddLine3,MCLI.app_add_postcode as appAddPostcode,"+
        			"MCLI.app_add_state as appAddState,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='Country' and Code = MCLI.App_Country) as AppCountry,MCLI.app_tel_hp as appTelHp,MCLI.app_email_address as appEmailAddress,MCLI.APP_FOREIGNER_CLF as APPFOREIGNERCLF,"+
        			"MCLI.APP_FOREIGNER_FT as APPFOREIGNERFT,MCLI.app_Wasi as appWasi,MCLI.app_Conditional_Hibah as appConditionalHibah,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='Relationship' and Code = MCLI.app_nominee_rel) as appNomineeRel,"+
        			"MCLI.app_optin as appOptin,MCLI.app_FATCA_US_Person_Circumstances as appFATCAUSPersonCircumstances,MCLI.app_FATCA_US_Person_DataWaiver as appFATCAUSPersonDataWaiver,"+
        			"MCLI.app_sign_dated as appSignDated,MHEA.app_q1a_ht as appq1Aht,MHEA.app_q1b_wt as appq1bWt,MHEA.app_q1c_wt_chg as appq1cWtChg,MHEA.app_q2 as appq2,"+
        			"MHEA.app_q3 as appq3,MHEA.app_details as appDetails,MHEA.app_financier_name as appFinancierName,MHEA.app_ln_amt_hse as applnAmtHse,MHEA.app_repay_period_hse as appRepayPeriodHse,"+
        			"MHEA.app_interim_period as appInterimPeriod,MHEA.app_premium_financed as appPremiumFinanced,MHEA.app_int_rate_hse as appIntRateHse,MHEA.app_financier_sign_dated as appFinancierSignDated"+
        			" from db_eappln..tbl_MDTA_Control MCON,db_eappln..tbl_MDTA_Client MCLI,db_eappln..tbl_MDTA_Health MHEA" +
        			" where MCON.app_policyno = ? and MCLI.app_policyno = ? and MCLI.app_client_type='A' and MHEA.app_policyno = ?";
        	
			
			st = conn.prepareStatement(strSql);

			st.setString(1, policyNo);
			st.setString(2, policyNo);
			st.setString(3, policyNo);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
        } catch(Exception io){
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPolCoverage() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	//getPolWebInfoNominee
	// created by Kishore  - 2018/04/18
	
		public HashMap<Integer, HashMap<String, String>> getPolWebInfoNominee(String policyNo) {
			Connection conn = null;
			PreparedStatement st = null;
			ResultSet rs = null;
			
			HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
			
			long start = System.currentTimeMillis();
			
	        try {
	        	conn = DBUtil.getConnection("ipos");
				
	        	String strSql = "select MCLI.app_Wasi as appWasi,MCLI.app_Conditional_Hibah as appConditionalHibah,MCLI.app_name as appNameNominee , MCLI.app_ic_new as appIcNewNominee,MCLI.app_ic_other as appIcOtherNominee , MCLI.app_dob as appDobNominee,"+
					"MCLI.app_age as appAgeNominee,(select Description from db_eappln..tbl_MDTA_Lookup where Type ='Relationship' and Code = MCLI.app_nominee_rel) as appNomineeRel, "+
					"MCLI.app_add_line1 as appAddLine1Nominee,MCLI.app_add_line2 as appAddLine2Nominee,MCLI.app_add_line3 as appAddLine3Nominee,MCLI.app_add_postcode as appAddPostcodeNominee,"+
					"MCLI.app_add_state as appAddStateNominee"+
					" from db_eappln..tbl_MDTA_Client MCLI where MCLI.app_policyno = ? and MCLI.app_client_type='N'";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, policyNo);
				rs = st.executeQuery();
				
				ResultSetMetaData rsmd = rs.getMetaData();
				
				int numColumns = rsmd.getColumnCount();
				int recCount = 0;
				
				while (rs.next()) {
					HashMap<String, String> colData = new HashMap<String, String>();
					
					for(int i=1; i<=numColumns; i++) {
				        String columnName = rsmd.getColumnLabel(i);
				        String columnVal = rs.getString(columnName);
				        
				        if(!DataTypeHandler.isEmpty(columnName)) {
				        	columnName = columnName.trim();
				        	System.out.println("[getPolWebInfoNominee]...Nominee..Column Name : "+columnName);
				        }
				        
				        if(!DataTypeHandler.isEmpty(columnVal)) {
				        	columnVal = columnVal.trim();
				        	System.out.println("[getPolWebInfoNominee]...Nominee..Column Name : "+columnVal);
				        }
				        
				        colData.put(columnName, columnVal);
				    }
					
					rsData.put(recCount++, colData);
				}
	        } catch(Exception io){
				io.printStackTrace();
				
	        } finally {
				try {
					if (st != null) st.close();
					if (rs != null) rs.close();
					conn.close();
					
				} catch(Exception ex){}
				
				if(showTime)
					System.out.println("DBCommon.getPolCoverage() duration: " + GenericUtil.calculateTime(start) + "s");
			}
	        
	        return rsData;
		}	
	
	
	public HashMap<Integer, HashMap<String, String>> getAppFormQuestions(String policyId) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
			
			String strSql = "select OrderingNumber, UWAnswer " +
					"from EC_UWQUESTIONNAIRE q, EC_UNDERWRITE_QUESTION_MASTER m " +
					"where q.EC_POLICY_ID = ? and q.UWQuestionCode = m.UnderWriteQuestionCode " +
					"and m.UnderWriteQuestionCat = ? order by m.OrderingNumber asc";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, policyId);
			st.setString(2, "UnderWrite");
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
        } catch(Exception io){
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getAppFormQuestions() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public HashMap<Integer, HashMap<String, String>> getNominees(String policyId) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
			
			String strSql = "select rtrim(ltrim(isnull(c.NAME1,'') + ' ' + isnull(c.NAME2,'') + ' ' + isnull(c.NAME3,''))) " +
					"as Name, m.NBCFEParam as Relationship, n.PERCENTALLOCATION as SharePercent, a.ADDRESS1, a.ADDRESS2, " +
					"a.ADDRESS3, a.CITYSTATE, a.COUNTRY, a.POSTCODE, c.DOB as DateOfBirth, c.NRIC as Mykad, " +
					"c.PASSPORTNO_OTHERS as Passport " +
					"from EC_NOMINEE n, EC_CLIENT c, EC_ADDRESS a, db_eappln..tbl_EAppln_NBCFEMapping m " +
					"where n.EC_POLICY_ID = ? and n.EC_CLIENT_ID = c.EC_CLIENT_ID and c.EC_CLIENT_ID = a.EC_CLIENT_ID " +
					"and n.RELATIONSHIP = m.EAppParam and m.ParamType = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, policyId);
			st.setString(2, "OWNER_REL");
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
        } catch(Exception io){
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getNominees() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public HashMap<Integer, HashMap<String, String>> getTrustees(String policyId) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
			
			String strSql = "select rtrim(ltrim(isnull(c.NAME1,'') + ' ' + isnull(c.NAME2,'') + ' ' + isnull(c.NAME3,''))) " +
					"as Name, a.ADDRESS1, a.ADDRESS2, a.ADDRESS3, a.CITYSTATE, a.COUNTRY, a.POSTCODE, c.DOB as DateOfBirth, " +
					"c.NRIC as Mykad, c.PASSPORTNO_OTHERS as Passport " +
					"from EC_TRUSTEE t, EC_CLIENT c, EC_ADDRESS a " +
					"where t.EC_POLICY_ID = ? and t.EC_CLIENT_ID = c.EC_CLIENT_ID and c.EC_CLIENT_ID = a.EC_CLIENT_ID";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, policyId);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
        } catch(Exception io){
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getTrustees() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public boolean updatePrintStatus(String companyCode, String policyNo, String policyStatus) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
        	
			String strSql = "update EC_PRINT_STATUS set STATUS = ? where COMPANYCODE = ? and POLICYNUMBER = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyStatus);
			st.setString(2, companyCode);
			st.setString(3, policyNo);
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updatePrintStatus() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean updateWebFormPrintStatus(String companyCode, String policyNo, String policyStatus) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
        	
			String strSql = "update db_eappln..tbl_MDTA_PRINT_STATUS set STATUS = ? where COMPANYCODE = ? and POLICYNUMBER = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyStatus);
			st.setString(2, companyCode);
			st.setString(3, policyNo);
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateWebFormPrintStatus() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean updateAgentFormPrintStatus(String trxId, String contractType , String printStatus) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("ipos");
        	
			String strSql = "update db_iRecruit..CONTRACT set STATUS = ? where trx_id = ? and contract_type = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, printStatus);
			st.setString(2, trxId);
			st.setString(3, contractType);
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateWebFormPrintStatus() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	
	public HashMap<Integer, HashMap<String, String>> getNBLookup(String lkType, String companyCode, String hostType) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select FEValue, FEDescription from TNBLKUP " +
					"where LKType = ? and CompanyCode = ? and HostType = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, lkType);
			st.setString(2, companyCode);
			st.setString(3, hostType);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getNBLookup(" + lkType + ") duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public HashMap<Integer, HashMap<String, String>> getNBRelationship(String companyCode) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select OccdRelationCode as FEValue, Description as FEDescription from TNBRLTLK " +
					"where CompanyCode = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, companyCode);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getNBRelationship() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public HashMap<Integer, HashMap<String, String>> getPlans() {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select CompanyCode, CoverageCode, CoverageShortName, FullName from TNBCVGC";
			
			st = conn.prepareStatement(strSql);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPlans() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public boolean validateTableByMonthYear(String tableName) {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		String foundTable = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT 'Y' as isFound FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ?";
			
			st = conn.prepareStatement(strSql);
			
			st.setString(1, tableName);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				foundTable = rs.getString("isFound");
			}
			
			if (!"Y".equals(foundTable)) {
				//Create table
				executeSQL("CREATE TABLE " + tableName + " (" +
						"dm_doc_id uniqueidentifier NOT NULL, dm_doc_data image NULL, created_dt datetime NULL" +
						")");
				
				//Create Index
				executeSQL("CREATE NONCLUSTERED INDEX Idx_DocId ON " + tableName + " (dm_doc_id) " +
						"WITH (PAD_INDEX = OFF, FILLFACTOR = 100, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF, " +
						"ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = NONE)");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			
        } finally {
			try {
				conn.setAutoCommit(true);
				
				if (st != null) {
					st.close();
				}
					
				if (rs != null) {
					rs.close();
				}
				
				conn.close();
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.validateTableByMonthYear() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean addALPPDocBase(String baseId, String docId, String docType, String policyNo, String icNo, 
			String processYear, String tableDocName, String receivedDate) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "INSERT INTO tbl_dm_doc (id, dm_doc_id, mt_app_cd, mt_doc_type_cd, proposal_no, ic_no, recv_dt, " +
					"process_year, dm_status, tbl_doc_nm, is_supressed, created_by, created_dt) " +
					"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, getdate())";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, baseId);
			st.setString(2, docId);
			st.setString(3, "003"); 
			st.setString(4, docType);
			st.setString(5, policyNo);
			st.setString(6, icNo);
			st.setString(7, receivedDate);
			st.setString(8, processYear);
			st.setBoolean(9, true);
			st.setString(10, tableDocName);
			st.setBoolean(11, false);
			st.setString(12, "PRINTAGENT");
			
			st.execute();
			
			conn.commit();
			
		} catch (Exception ex) {
	    	try {
	    		conn.rollback();
	    	} catch (Exception e) {}
	    	
	    	System.out.println(ex.toString());
	    	
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				
				conn.setAutoCommit(true);
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.addALPPDocBase() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean addALPPDocImage(String docId, ByteArrayOutputStream fullPdfBaos, String tableName) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			InputStream fis = new ByteArrayInputStream(fullPdfBaos.toByteArray());
			
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "INSERT INTO " + tableName + " (dm_doc_id, dm_doc_data, created_dt) VALUES (?, ?, getdate())";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, docId);
			st.setBinaryStream(2, fis, fullPdfBaos.size());
			
			st.execute();
			
			fis.close();
			
		} catch (Exception ex) {
	    	System.out.println(ex.toString());
	    	
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.addALPPDocImage() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean getALPPDocImage(String docId, String tableName) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("bicor");
			
			String strSql = "SELECT dm_doc_data from " + tableName + " where dm_doc_id = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, docId);
			
			rs = st.executeQuery();
			
			byte[] fis = null;
			while(rs.next()) {
				fis = rs.getBytes("dm_doc_data");
			}
			
			if(fis != null) {
				OutputStream debugFile = new FileOutputStream(new File("c:/temp/test.pdf"));
				debugFile.write(fis);
				
			} else {
				System.out.println("PDF is null...");
			}
			
		} catch (Exception ex) {
	    	System.out.println(ex.toString());
	    	
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.getALPPDocImage() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public int setALPPEmail(String recipient, String subject, String content,String emailCC , String fromEmail) {
		Connection conn = null;
		CallableStatement cs = null;
		int masId = 0;
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("alpp");
			
			cs = conn.prepareCall("{call SP_INSERT_EMAILMASTER(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
			cs.registerOutParameter(1, java.sql.Types.INTEGER);
			cs.setString(2, "PrintAgent"); // source
			if(fromEmail != null && fromEmail != "" && fromEmail.trim().length()>0){
				cs.setString(3, fromEmail);
			}else{
				cs.setString(3, "noreply@aia.com");
			}
			
			cs.setString(4, recipient);
			if(!"".equalsIgnoreCase(emailCC)){
				cs.setString(5, emailCC); // cc email
			}else{
				cs.setString(5, null); // cc email
			}
			
			cs.setString(6, null); // bcc email
			cs.setString(7, subject);
			cs.setString(8, content);
			cs.setString(9, "P"); // email status (pending)
			cs.setString(10, GenericUtil.dateToStr(new Date(), "yyyy-MM-dd HH:mm:ss")); // created date
			cs.setString(11, null); // sent date
			cs.setString(12, null); // reference id
			
			//cs.execute();
			
			cs.executeUpdate();
			masId = cs.getInt(1);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try { cs.close(); } catch (Exception e) { /* ignored */ }
		    try { conn.close(); } catch (Exception e) { /* ignored */ }
		    
		    cs = null;
		    conn = null;
		    
		    if(showTime)
				System.out.println("DBCommon.setALPPEmail() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		//return true;
		return masId;
	}
	
	public int getLatestIdForEmail(String recipient) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		int masterId = 0;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("alpp");
			
			String strSql = "SELECT MAX(PkId) as MaxId from tblEmailMaster where RecipientEmail = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, recipient);
			
			rs = st.executeQuery();
			
			while (rs.next()) {
				masterId = rs.getInt("MaxId");
			}
		} catch (Exception ex) {
	    	System.out.println(ex.toString());
	    	
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.getLatestIdForEmail() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return masterId;
	}
	
	public boolean setALPPEmailAttachment(int masterId, ByteArrayOutputStream attachment, String policyNo) {
		Connection conn = null;
		CallableStatement cs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			InputStream fis = new ByteArrayInputStream(attachment.toByteArray());
			
			conn = DBUtil.getConnection("alpp");
			
			cs = conn.prepareCall("{call SP_INSERT_EMAILDETAILS(?, ?, ?, ?, ?, ?)}");
			cs.setInt(1, masterId);
			cs.setBinaryStream(2, fis, attachment.size()); // attachment image
			cs.setString(3, "PDF"); // attachment type
			cs.setString(4, policyNo); // attachment name
			cs.setString(5, "PrintAgent"); // source
			cs.setString(6, GenericUtil.dateToStr(new Date(), "yyyy-MM-dd HH:mm:ss")); // created date
			
			cs.execute();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
		} finally {
			try { cs.close(); } catch (Exception e) { /* ignored */ }
		    try { conn.close(); } catch (Exception e) { /* ignored */ }
		    
		    cs = null;
		    conn = null;
		    
		    if(showTime)
				System.out.println("DBCommon.setALPPEmailAttachment() duration: " + 
						GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public boolean getALPPEmailImage(String docId) {
		PreparedStatement st = null;
		Connection conn = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		try {
			conn = DBUtil.getConnection("alpp");
			
			String strSql = "SELECT Attachment from tblEmailDetails where PkId = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, docId);
			
			rs = st.executeQuery();
			
			byte[] fis = null;
			while(rs.next()) {
				fis = rs.getBytes("Attachment");
			}
			
			if(fis != null) {
				OutputStream debugFile = new FileOutputStream(new File("c:/temp/test.pdf"));
				debugFile.write(fis);
				
			} else {
				System.out.println("PDF is null...");
			}
			
		} catch (Exception ex) {
	    	System.out.println(ex.toString());
	    	
		} finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
			
			if(showTime)
				System.out.println("DBCommon.getALPPEmailImage() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return true;
	}
	
	public String getPromoCode(String templateGroup) {		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
		String promoCode = "";
						
        try {
        	conn = DBUtil.getConnection("bicor");
        	
        	String strSql = "select top 1 Code as PromoCode FROM tbl_ep_PromoCode WHERE TemplGroup = ? and UsedDate is null";
			st = conn.prepareStatement(strSql);
			
			st.setString(1, templateGroup);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				promoCode = rs.getString("PromoCode");
			}
		} catch(Exception io) {
			io.printStackTrace();
			
	    } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex) {}
		}
        
        long end = System.currentTimeMillis(); 
		System.out.println("[DBCommon] getPromoCode() duration: " + formatNumber(((double)end - (double)start)/1000) + "s");
		
		return promoCode;
	}
	
	public void updatePromoCode(String promoCode, String templateCode) {		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
						
        try {
        	conn = DBUtil.getConnection("bicor");
			
			conn.setAutoCommit(false);
			
			String strSql = "update tbl_ep_PromoCode set UsedDate = getDate() where Code = ? and TemplGroup = ?";
			
			PreparedStatement ps = conn.prepareStatement(strSql);
			ps.setString(1, promoCode);
			ps.setString(2, templateCode);
			
			ps.execute();
			
			conn.commit();
			
        } catch(Exception ex) {
	    	try {
	    		conn.rollback();
	    		
	    	} catch (Exception e) { }
	    	
	    	System.out.println(ex.toString());
			
	    } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.setAutoCommit(true);
				conn.close();
				
			} catch(Exception ex) { }
		}
        
        long end = System.currentTimeMillis(); 
		System.out.println("[DBCommon] updatePromoCode() duration: " + formatNumber(((double)end - (double)start)/1000) + "s");
	}
	
	public List<Notification> getNotificationList(String newStatus, String failedStatus) {
		List<Notification> notifications = new ArrayList<Notification>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select top 100 GUID, NotificationType, AgentCode, PolicyNumber, LineOfBusiness, OwnerName, " +
					"ServiceRequestType, ClaimAmount, ClaimStatusCode, ClaimStatusDesc, CoveredMember, HospitalName, " +
					"ClaimNo, ClaimOccNo, RowStatus, TryCount, ReturnResult,NRIC from db_iws..ubp_AgentNotification " +
					"where (RowStatus = ? or RowStatus = ?) order by CreateDate asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, newStatus);
			st.setString(2, failedStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				Notification n = new Notification();
				
				n.setGuid(rs.getString("GUID"));
				n.setNotificationType(rs.getString("NotificationType"));
				n.setAgentCode(rs.getString("AgentCode"));
				n.setPolicyNumber(rs.getString("PolicyNumber"));
				n.setLineOfBusiness(rs.getString("LineOfBusiness"));
				n.setOwnerName(rs.getString("OwnerName"));
				n.setServiceRequestType(rs.getString("ServiceRequestType"));
				n.setClaimAmount(new BigDecimal(!cu.isBlank(rs.getString("ClaimAmount"))? rs.getString("ClaimAmount"): "0"));
				//n.setClaimAmount(rs.getBigDecimal("ClaimAmount"));
				n.setClaimStatusCode(rs.getString("ClaimStatusCode"));
				n.setClaimStatusDesc(rs.getString("ClaimStatusDesc"));
				n.setCoveredMember(rs.getString("CoveredMember"));
				n.setHospitalName(rs.getString("HospitalName"));
				n.setClaimNo(rs.getString("ClaimNo"));
				n.setClaimOccNo(rs.getInt("ClaimOccNo"));
				n.setRowStatus(rs.getString("RowStatus"));
				n.setTryCount(rs.getInt("TryCount"));
				n.setReturnResult(rs.getString("ReturnResult"));
				n.setNric(rs.getString("NRIC"));
				
				notifications.add(n);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getNotificationList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return notifications;
	}
	
	public boolean updateNotificationRow(String guid, String rowStatus, int tryCount, String result) {
		boolean success = false;
		CommonFileUtil cu = new CommonFileUtil();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			if(!cu.isBlank(rowStatus) && tryCount != -1) {
				strSql = "update db_iws..ubp_AgentNotification set RowStatus = ?, TryCount = ?, ReturnResult = ? , esb_time = getdate() " +
						"where GUID = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setInt(2, tryCount);
				st.setString(3, result);
				st.setString(4, guid);
				
			} else { // just update row status
				strSql = "update db_iws..ubp_AgentNotification set RowStatus = ? where GUID = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setString(2, guid);
			}
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateNotificationRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}

	public HashMap<Integer, HashMap<String, String>> getLookups() {
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		HashMap<Integer, HashMap<String, String>> rsData = new HashMap<Integer, HashMap<String, String>>();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select LKType, LKCode, LKDescription, LKCategory, LKSubCategory from db_iws..ubp_Lookup";
			
			st = conn.prepareStatement(strSql);
			
			rs = st.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int numColumns = rsmd.getColumnCount();
			int recCount = 0;
			
			while (rs.next()) {
				HashMap<String, String> colData = new HashMap<String, String>();
				
				for(int i=1; i<=numColumns; i++) {
			        String columnName = rsmd.getColumnLabel(i);
			        String columnVal = rs.getString(columnName);
			        
			        if(!DataTypeHandler.isEmpty(columnName)) {
			        	columnName = columnName.trim();
			        }
			        
			        if(!DataTypeHandler.isEmpty(columnVal)) {
			        	columnVal = columnVal.trim();
			        }
			        
			        colData.put(columnName, columnVal);
			    }
				
				rsData.put(recCount++, colData);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getLookups() duration: " + GenericUtil.calculateTime(start) + "s");
		}
        
        return rsData;
	}
	
	public List<Notification> getUpdateContactList(String newStatus, String failedStatus) {
		List<Notification> notifications = new ArrayList<Notification>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select top 100 GUID, NotificationType, AgentCode, PolicyNumber, LineOfBusiness, OwnerName, " +
					"ServiceRequestType, ClaimAmount, ClaimStatus, CoveredMember, HospitalName, ClaimNo, ClaimOccNo, " +
					"RowStatus, TryCount, ReturnResult,NRIC from db_iws..ubp_AgentNotification " +
					"where (RowStatus = ? or RowStatus = ?) order by CreateDate asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, newStatus);
			st.setString(2, failedStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				Notification n = new Notification();
				
				n.setGuid(rs.getString("GUID"));
				n.setNotificationType(rs.getString("NotificationType"));
				n.setAgentCode(rs.getString("AgentCode"));
				n.setPolicyNumber(rs.getString("PolicyNumber"));
				n.setLineOfBusiness(rs.getString("LineOfBusiness"));
				n.setOwnerName(rs.getString("OwnerName"));
				n.setServiceRequestType(rs.getString("ServiceRequestType"));
				n.setClaimAmount(new BigDecimal(!cu.isBlank(rs.getString("ClaimAmount"))? rs.getString("ClaimAmount"): "0"));
				//n.setClaimAmount(rs.getBigDecimal("ClaimAmount"));
				n.setClaimStatusCode(rs.getString("ClaimStatusCode"));
				n.setClaimStatusDesc(rs.getString("ClaimStatusDesc"));
				n.setCoveredMember(rs.getString("CoveredMember"));
				n.setHospitalName(rs.getString("HospitalName"));
				n.setClaimNo(rs.getString("ClaimNo"));
				n.setClaimOccNo(rs.getInt("ClaimOccNo"));
				n.setRowStatus(rs.getString("RowStatus"));
				n.setTryCount(rs.getInt("TryCount"));
				n.setReturnResult(rs.getString("ReturnResult"));
				n.setNric(rs.getString("NRIC"));
				
				notifications.add(n);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getNotificationList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return notifications;
	}

	public List<POSServiceRequest> getPOSServiceRequestList(String newStatus, String failedStatus) {
		List<POSServiceRequest> serviceRequests = new ArrayList<POSServiceRequest>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select top 100 PolicyNo, KeyRequestNo, RequestNo, SubmittingAgentCode, ReqType, ReqStatus, " +
					"ReqStatusDesc, ReqDate, LineOfBusiness, LastUpdateDate, RowStatus, TryCount, ReturnResult " +
					"from db_pos2..ubp_POSREQ01 where (RowStatus = ? or RowStatus = ?) order by CreateDate asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, newStatus);
			st.setString(2, failedStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				POSServiceRequest sr = new POSServiceRequest();
				
				sr.setPolicyNo(rs.getString("PolicyNo"));
				sr.setKeyRequestNo(rs.getString("KeyRequestNo"));
				sr.setRequestNo(rs.getString("RequestNo"));
				sr.setSubmitAgentCode(rs.getString("SubmittingAgentCode"));
				sr.setReqType(rs.getString("ReqType"));
				sr.setReqStatus(rs.getString("ReqStatus"));
				sr.setReqStatusDesc(rs.getString("ReqStatusDesc"));
				sr.setReqDate(rs.getDate("ReqDate"));
				sr.setLineOfBusiness(rs.getString("LineOfBusiness"));
				sr.setLastUpdateDate(rs.getDate("LastUpdateDate"));
				sr.setRowStatus(rs.getString("RowStatus"));
				sr.setTryCount(rs.getInt("TryCount"));
				sr.setReturnResult(rs.getString("ReturnResult"));
				
				serviceRequests.add(sr);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getPOSServiceRequestList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return serviceRequests;
	}
	
	public boolean updateServiceRequestRow(String policyNo, String requestNo, String reqType, String rowStatus, 
			int tryCount, String result) {
		boolean success = false;
		CommonFileUtil cu = new CommonFileUtil();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			if(!cu.isBlank(rowStatus) && tryCount != -1) {
				strSql = "update db_pos2..ubp_POSREQ01 set RowStatus = ?, TryCount = ?, ReturnResult = ? " +
						"where PolicyNo = ? and RequestNo = ? and ReqType = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setInt(2, tryCount);
				st.setString(3, result);
				st.setString(4, policyNo);
				st.setString(5, requestNo);
				st.setString(6, reqType);
				
			} else { // just update row status
				strSql = "update db_pos2..ubp_POSREQ01 set RowStatus = ? where PolicyNo = ? and RequestNo = ? " +
						"and ReqType = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setString(2, policyNo);
				st.setString(3, requestNo);
				st.setString(4, reqType);
			}
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateServiceRequestRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean archiveNotificationRow(String guid) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			strSql = "insert into db_iws..ubp_AgentNotificationHistory (GUID, NotificationType, AgentCode, PolicyNumber, " +
					"LineOfBusiness, OwnerName, ServiceRequestType, ClaimAmount, ClaimStatusCode, ClaimStatusDesc, " +
					"CoveredMember, HospitalName, ClaimNo, ClaimOccNo, RowStatus, TryCount, ReturnResult, CreateDate, " +
					"CreateUserId , NRIC , esb_time) " +
					"select GUID, NotificationType, AgentCode, PolicyNumber, LineOfBusiness, OwnerName, ServiceRequestType, " +
					"ClaimAmount, ClaimStatusCode, ClaimStatusDesc, CoveredMember, HospitalName, ClaimNo, ClaimOccNo, " +
					"RowStatus, TryCount, ReturnResult, CreateDate, CreateUserId , NRIC , esb_time " +
					"from db_iws..ubp_AgentNotification where GUID = ?";
				
			st = conn.prepareStatement(strSql);
			st.setString(1, guid);
			
			st.execute();
			
			strSql = "delete from db_iws..ubp_AgentNotification WHERE GUID = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, guid);
			
			st.execute();
			
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.archiveNotificationRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean archiveServiceRequestRow(String policyNo, String requestNo, String reqType) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			strSql = "insert into db_pos2..ubp_POSREQ01_hist (PolicyNo, KeyRequestNo, RequestNo, SubmittingAgentCode, " +
					"ReqType, ReqStatus, ReqStatusDesc, ReqDate, LineOfBusiness, LastUpdateDate, RowStatus, TryCount, " +
					"ReturnResult) " +
					"select PolicyNo, KeyRequestNo, RequestNo, SubmittingAgentCode, ReqType, ReqStatus, " +
					"ReqStatusDesc, ReqDate, LineOfBusiness, LastUpdateDate, RowStatus, TryCount, ReturnResult " +
					"from db_pos2..ubp_POSREQ01 where PolicyNo = ? and RequestNo = ? and ReqType = ?";
				
			st = conn.prepareStatement(strSql);
			st.setString(1, policyNo);
			st.setString(2, requestNo);
			st.setString(3, reqType);
			
			st.execute();
			
			strSql = "delete from db_pos2..ubp_POSREQ01 where PolicyNo = ? and RequestNo = ? and ReqType = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, policyNo);
			st.setString(2, requestNo);
			st.setString(3, reqType);
			
			st.execute();
			
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.archiveServiceRequestRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public List<NBAgentContact> getNBAgentContactList(String newStatus, String failedStatus) {
		List<NBAgentContact> agentContacts = new ArrayList<NBAgentContact>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		CommonFileUtil cfu = new CommonFileUtil();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select top 100 AGNTPFX, AGNTCOY, AGNTNUM, CLNTPFX, CLNTCOY, CLNTNUM, SURNAME, SECUITYNO, CLTRACE, " +
					"CLTSEX, CLTDOB, RMBLPHONE, RINTERNET, CLRRROLE, LOB, CHANNEL, GUID, RowStatus, TryCount, " +
					"ReturnResult from db_nb..tAGMUPDCON where (RowStatus = ? or RowStatus = ?)";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, newStatus);
			st.setString(2, failedStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				NBAgentContact ac = new NBAgentContact();
				
				ac.setAgentPrefix(rs.getString("AGNTPFX"));
				ac.setAgentCompany(rs.getString("AGNTCOY"));
				ac.setAgentNo(rs.getString("AGNTNUM"));
				ac.setClientPrefix(rs.getString("CLNTPFX"));
				ac.setClientCompany(rs.getString("CLNTCOY"));
				ac.setClientNo(rs.getString("CLNTNUM"));
				ac.setOwnerName(rs.getString("SURNAME"));
				ac.setOwnerIcNo(rs.getString("SECUITYNO"));
				ac.setRace(rs.getString("CLTRACE"));
				ac.setGender(rs.getString("CLTSEX"));
				ac.setDateOfBirth(!cfu.isBlank(rs.getString("CLTDOB"))? sdf.parse(rs.getString("CLTDOB")): null);
				ac.setMobileNo(rs.getString("RMBLPHONE"));
				ac.setEmailAddress(rs.getString("RINTERNET"));
				ac.setRole(rs.getString("CLRRROLE"));
				ac.setLineOfBusiness(rs.getString("LOB"));
				ac.setChannel(rs.getString("CHANNEL"));
				ac.setGuid(rs.getString("GUID"));
				ac.setRowStatus(rs.getString("RowStatus"));
				ac.setTryCount(rs.getInt("TryCount"));
				ac.setReturnResult(rs.getString("ReturnResult"));
				
				agentContacts.add(ac);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getNBAgentContactList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return agentContacts;
	}

	public boolean updateNBAgentContactRow(String guid, String rowStatus, int tryCount, String result) {
		boolean success = false;
		CommonFileUtil cu = new CommonFileUtil();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			if(!cu.isBlank(rowStatus) && tryCount != -1) {
				strSql = "update db_nb..tAGMUPDCON set RowStatus = ?, TryCount = ?, ReturnResult = ? " +
						"where GUID = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setInt(2, tryCount);
				st.setString(3, result);
				st.setString(4, guid);
				
			} else { // just update row status
				strSql = "update db_nb..tAGMUPDCON set RowStatus = ? where GUID = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setString(2, guid);
			}
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateNBAgentContactRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean archiveNBAgentContactRow(String guid) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			strSql = "insert into db_nb..tAGMUPDCONHistory (AGNTPFX, AGNTCOY, AGNTNUM, CLNTPFX, CLNTCOY, CLNTNUM, SURNAME, " +
					"SECUITYNO, CLTRACE, CLTSEX, CLTDOB, RMBLPHONE, RINTERNET, CLRRROLE, LOB, CHANNEL, GUID, RowStatus, " +
					"TryCount, ReturnResult) " +
					"select AGNTPFX, AGNTCOY, AGNTNUM, CLNTPFX, CLNTCOY, CLNTNUM, SURNAME, " +
					"SECUITYNO, CLTRACE, CLTSEX, CLTDOB, RMBLPHONE, RINTERNET, CLRRROLE, LOB, CHANNEL, GUID, RowStatus, " +
					"TryCount, ReturnResult " +
					"from db_nb..tAGMUPDCON where GUID = ?";
				
			st = conn.prepareStatement(strSql);
			st.setString(1, guid);
			
			st.execute();
			
			strSql = "delete from db_nb..tAGMUPDCON WHERE GUID = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, guid);
			
			st.execute();
			
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.archiveNBAgentContactRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public List<ClaimsData> getClaimsDataList(String newStatus, String failedStatus) {
		List<ClaimsData> claimsList = new ArrayList<ClaimsData>();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		CommonFileUtil cu = new CommonFileUtil();
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "select top 100 claim_type, name, claim_no, occurrence, clm_igl_no, clm_status_code, " +
					"clm_status_desc, clm_log_code, clm_log_desc, clm_log_date, agent_code, clm_status_code_group, " +
					"clm_status_code_desc, policy_no, pas_policy_no, clm_log_amt, hospital_name, line_of_buisiness, " +
					"RowStatus, TryCount, ReturnResult " +
					"from db_claims..ubp_tclaim_listing where (RowStatus = ? or RowStatus = ?) " +
					"order by claim_no, occurrence asc";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, newStatus);
			st.setString(2, failedStatus);
			
			rs = st.executeQuery();
			
			while(rs.next()) {
				ClaimsData cd = new ClaimsData();
				
				cd.setClaimType(rs.getString("claim_type"));
				cd.setInsuredPerson(rs.getString("name"));
				cd.setClaimNo(rs.getString("claim_no"));
				cd.setOccurrence(rs.getString("occurrence"));
				cd.setLogNo(rs.getString("clm_igl_no"));
				cd.setClaimStatusCode(rs.getString("clm_status_code"));
				cd.setClaimStatusDesc(rs.getString("clm_status_desc"));
				cd.setLogCode(rs.getString("clm_log_code"));
				cd.setLogDescription(rs.getString("clm_log_desc"));
				cd.setLogDate(rs.getDate("clm_log_date"));
				cd.setAgentNo(rs.getString("agent_code"));
				cd.setGroupStatusCode(rs.getString("clm_status_code_group"));
				cd.setGroupStatusDesc(rs.getString("clm_status_code_desc"));
				cd.setPolicyNoWithCheckDigit(rs.getString("policy_no"));
				cd.setPolicyNoWithoutCheckDigit(rs.getString("pas_policy_no"));
				cd.setClaimAmount(new BigDecimal(!cu.isBlank(rs.getString("clm_log_amt"))? rs.getString("clm_log_amt"): "0"));
				cd.setHospitalName(rs.getString("hospital_name"));
				cd.setLOB(rs.getString("line_of_buisiness"));
				cd.setRowStatus(rs.getString("RowStatus"));
				cd.setTryCount(rs.getInt("TryCount"));
				cd.setReturnResult(rs.getString("ReturnResult"));
				
				claimsList.add(cd);
			}
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.getClaimsDataList() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return claimsList;
	}

	public boolean updateClaimsDataRow(String claimNo, String occurrence, String rowStatus, int tryCount, String result) {
		boolean success = false;
		CommonFileUtil cu = new CommonFileUtil();
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			if(!cu.isBlank(rowStatus) && tryCount != -1) {
				strSql = "update db_claims..ubp_tclaim_listing set RowStatus = ?, TryCount = ?, ReturnResult = ? " +
						"where claim_no = ? and occurrence = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setInt(2, tryCount);
				st.setString(3, result);
				st.setString(4, claimNo);
				st.setString(5, occurrence);
				
			} else { // just update row status
				strSql = "update db_claims..ubp_tclaim_listing set RowStatus = ? where claim_no = ? and occurrence = ?";
				
				st = conn.prepareStatement(strSql);
				st.setString(1, rowStatus);
				st.setString(2, claimNo);
				st.setString(3, occurrence);
			}
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateClaimsDataRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean archiveClaimsDataRow(String claimNo, String occurrence) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			strSql = "insert into db_claims..ubp_tclaim_listing_hist (claim_type, name, claim_no, occurrence, clm_igl_no, " +
					"clm_status_code, clm_status_desc, clm_log_code, clm_log_desc, clm_log_date, agent_code, " +
					"clm_status_code_group, clm_status_code_desc, policy_no, pas_policy_no, clm_log_amt, hospital_name, " +
					"line_of_buisiness, RowStatus, TryCount, ReturnResult) " +
					"select claim_type, name, claim_no, occurrence, clm_igl_no, clm_status_code, " +
					"clm_status_desc, clm_log_code, clm_log_desc, clm_log_date, agent_code, clm_status_code_group, " +
					"clm_status_code_desc, policy_no, pas_policy_no, clm_log_amt, hospital_name, line_of_buisiness, " +
					"RowStatus, TryCount, ReturnResult " +
					"from db_claims..ubp_tclaim_listing where claim_no = ? and occurrence = ?";
				
			st = conn.prepareStatement(strSql);
			st.setString(1, claimNo);
			st.setString(2, occurrence);
			
			st.execute();
			
			strSql = "delete from db_claims..ubp_tclaim_listing where claim_no = ? and occurrence = ?";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, claimNo);
			st.setString(2, occurrence);
			
			st.execute();
			
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.archiveClaimsDataRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean updateUBPTableAllRow(String rowStatus, int tryCount, String result, String tableName) {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("nb");
        	
			String strSql = "";
			
			strSql = "update " + tableName + " set RowStatus = ?, TryCount = ?, ReturnResult = ? " +
					"where (RowStatus = ? or RowStatus = ?)";
			
			st = conn.prepareStatement(strSql);
			st.setString(1, rowStatus);
			st.setInt(2, tryCount);
			st.setString(3, result);
			st.setString(4, "PROCESS");
			st.setString(5, "FAILED");
			
			st.execute();
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.updateUBPTableAllRow() - " + tableName + 
						" duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
	
	public boolean deleteTaxInvImgRow() {
		boolean success = false;
		
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;
		
		long start = System.currentTimeMillis();
		
        try {
        	conn = DBUtil.getConnection("bicor");
        	
        	String deleteSQL = "DELETE FROM tbl_TaxInvImg";
			st = conn.prepareStatement(deleteSQL);
			
			st.executeUpdate();
			
			success = true;
			
		} catch(Exception io) {
			io.printStackTrace();
			
        } finally {
			try {
				if (st != null) st.close();
				if (rs != null) rs.close();
				conn.close();
				
			} catch(Exception ex){}
			
			if(showTime)
				System.out.println("DBCommon.deleteTaxInvImgRow() duration: " + GenericUtil.calculateTime(start) + "s");
		}
		
		return success;
	}
}
