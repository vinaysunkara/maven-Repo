package com.aia.common.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyInfo", propOrder = {
    "companyCode", "policyNo", "insuredName", "faceAmount", "policyDate",
    "planName", "issueDate","issueDateMS", "expiryDate", "insuredAge",
    "ageAdmitted", "gender", "currency", "insuredMykad", "ownerName", 
    "ownerMykad", "ownerAge", "ownerGender", "policyDesc",
    "gstAmount", "premiumAmount", "totalAmount", "insuredEmail", "coverages",
    "paymentType","paymentTypeWord","paymentTypeBM","paymentTypeWordBM","annualCommission","maturityDateCICare",
    "occupationClass" , "maturityDateCIandMedBasic"
})
@XmlRootElement(name = "PolicyInfo")
public class PolicyInfo {

	@XmlElement(required = true) private String companyCode;
	@XmlElement(required = true) private String policyNo;
	@XmlElement(required = true) private String insuredName;
	@XmlElement(required = true) private BigDecimal faceAmount;
	@XmlElement(required = true) private Date policyDate;
	@XmlElement(required = true) private String planName;
	@XmlElement(required = true) private Date issueDate;
	@XmlElement(required = true) private String issueDateMS;
	@XmlElement(required = true) private Date expiryDate;
	@XmlElement(required = true) private Integer insuredAge;
	@XmlElement(required = true) private String ageAdmitted;
	@XmlElement(required = true) private String gender;
	@XmlElement(required = true) private String currency;
	@XmlElement(required = true) private String insuredMykad;
	@XmlElement(required = true) private String ownerName;
	@XmlElement(required = true) private String ownerMykad;
	@XmlElement(required = true) private Integer ownerAge;
	@XmlElement(required = true) private String ownerGender;
	@XmlElement(required = true) private String policyDesc;
	@XmlElement(required = true) private BigDecimal gstAmount;
	@XmlElement(required = true) private BigDecimal premiumAmount;
	@XmlElement(required = true) private BigDecimal totalAmount;
	@XmlElement(required = true) private String insuredEmail;
	
	@XmlElement(required = true) private List<PolCoverage> coverages;
	@XmlElement(required = true) private String paymentType;
	@XmlElement(required = true) private String paymentTypeWord;
	@XmlElement(required = true) private String paymentTypeBM;
	@XmlElement(required = true) private String paymentTypeWordBM;
	@XmlElement(required = true) private BigDecimal annualCommission;
	@XmlElement(required = true) private Date maturityDateCICare;
	@XmlElement(required = true) private String occupationClass;
	@XmlElement(required = true) private Date maturityDateCIandMedBasic;
	
	/**
	 * @return the issueDateMS
	 */
	public String getIssueDateMS() {
		return issueDateMS;
	}

	/**
	 * @param issueDateMS the issueDateMS to set
	 */
	public void setIssueDateMS(String issueDateMS) {
		this.issueDateMS = issueDateMS;
	}
	
	public Date getMaturityDateCICare() {
		return maturityDateCICare;
	}

	public void setMaturityDateCICare(Date maturityDateCICare) {
		this.maturityDateCICare = maturityDateCICare;
	}

	public String getPaymentTypeBM() {
		return paymentTypeBM;
	}

	public void setPaymentTypeBM(String paymentTypeBM) {
		this.paymentTypeBM = paymentTypeBM;
	}
	
	public String getPaymentTypeWordBM() {
		return paymentTypeWordBM;
	}

	public void setPaymentTypeWordBM(String paymentTypeWordBM) {
		this.paymentTypeWordBM = paymentTypeWordBM;
	}

	public String getPaymentTypeWord() {
		return paymentTypeWord;
	}

	public void setPaymentTypeWord(String paymentTypeWord) {
		this.paymentTypeWord = paymentTypeWord;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	private String policyId;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public BigDecimal getFaceAmount() {
		return faceAmount;
	}

	public void setFaceAmount(BigDecimal faceAmount) {
		this.faceAmount = faceAmount;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getInsuredAge() {
		return insuredAge;
	}

	public void setInsuredAge(Integer insuredAge) {
		this.insuredAge = insuredAge;
	}

	public String getAgeAdmitted() {
		return ageAdmitted;
	}

	public void setAgeAdmitted(String ageAdmitted) {
		this.ageAdmitted = ageAdmitted;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getPolicyDesc() {
		return policyDesc;
	}

	public void setPolicyDesc(String policyDesc) {
		this.policyDesc = policyDesc;
	}

	public BigDecimal getGstAmount() {
		return gstAmount;
	}

	public void setGstAmount(BigDecimal gstAmount) {
		this.gstAmount = gstAmount;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<PolCoverage> getCoverages() {
		return coverages;
	}

	public void setCoverages(List<PolCoverage> coverages) {
		this.coverages = coverages;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getInsuredMykad() {
		return insuredMykad;
	}

	public void setInsuredMykad(String insuredMykad) {
		this.insuredMykad = insuredMykad;
	}

	public String getOwnerMykad() {
		return ownerMykad;
	}

	public void setOwnerMykad(String ownerMykad) {
		this.ownerMykad = ownerMykad;
	}

	public Integer getOwnerAge() {
		return ownerAge;
	}

	public void setOwnerAge(Integer ownerAge) {
		this.ownerAge = ownerAge;
	}

	public String getOwnerGender() {
		return ownerGender;
	}

	public void setOwnerGender(String ownerGender) {
		this.ownerGender = ownerGender;
	}

	public String getInsuredEmail() {
		return insuredEmail;
	}

	public void setInsuredEmail(String insuredEmail) {
		this.insuredEmail = insuredEmail;
	}

	/**
	 * @return the annualCommission
	 */
	public BigDecimal getAnnualCommission() {
		return annualCommission;
	}

	/**
	 * @param annualCommission the annualCommission to set
	 */
	public void setAnnualCommission(BigDecimal annualCommission) {
		this.annualCommission = annualCommission;
	}

	/**
	 * @return the maturityDateCIandMedBasic
	 */
	public Date getMaturityDateCIandMedBasic() {
		return maturityDateCIandMedBasic;
	}

	/**
	 * @param maturityDateCIandMedBasic the maturityDateCIandMedBasic to set
	 */
	public void setMaturityDateCIandMedBasic(Date maturityDateCIandMedBasic) {
		this.maturityDateCIandMedBasic = maturityDateCIandMedBasic;
	}

	/**
	 * @return the occupationClass
	 */
	public String getOccupationClass() {
		return occupationClass;
	}

	/**
	 * @param occupationClass the occupationClass to set
	 */
	public void setOccupationClass(String occupationClass) {
		this.occupationClass = occupationClass;
	}


}
