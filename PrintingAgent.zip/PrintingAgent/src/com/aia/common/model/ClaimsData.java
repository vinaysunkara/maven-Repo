package com.aia.common.model;

import java.math.BigDecimal;
import java.util.Date;

public class ClaimsData {
	private String agentPrefix;
	private String agentCompany;
	private String agentNo;
	private String claimType;
	private String insuredPerson;
	private String claimPrefix;
	private String claimCompany;
	private String claimNo;
	private String occurrence;
	private String logNo;
	private String claimStatusCode;
	private String claimStatusDesc;
	private String logCode;
	private String logDescription;
	private Date logDate;
	private String policyNoWithCheckDigit;
	private String policyNoWithoutCheckDigit;
	private String LOB;
	private String groupStatusCode;
	private String groupStatusDesc;
	private BigDecimal claimAmount;
	private String hospitalName;
	private String channel;
	private String rowStatus;
	private int tryCount;
	private String returnResult;

	public String getAgentPrefix() {
		return agentPrefix;
	}

	public void setAgentPrefix(String agentPrefix) {
		this.agentPrefix = agentPrefix;
	}

	public String getAgentCompany() {
		return agentCompany;
	}

	public void setAgentCompany(String agentCompany) {
		this.agentCompany = agentCompany;
	}

	public String getAgentNo() {
		return agentNo;
	}

	public void setAgentNo(String agentNo) {
		this.agentNo = agentNo;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getInsuredPerson() {
		return insuredPerson;
	}

	public void setInsuredPerson(String insuredPerson) {
		this.insuredPerson = insuredPerson;
	}

	public String getClaimPrefix() {
		return claimPrefix;
	}

	public void setClaimPrefix(String claimPrefix) {
		this.claimPrefix = claimPrefix;
	}

	public String getClaimCompany() {
		return claimCompany;
	}

	public void setClaimCompany(String claimCompany) {
		this.claimCompany = claimCompany;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getOccurrence() {
		return occurrence;
	}

	public void setOccurrence(String occurrence) {
		this.occurrence = occurrence;
	}

	public String getLogNo() {
		return logNo;
	}

	public void setLogNo(String logNo) {
		this.logNo = logNo;
	}

	public String getClaimStatusCode() {
		return claimStatusCode;
	}

	public void setClaimStatusCode(String claimStatusCode) {
		this.claimStatusCode = claimStatusCode;
	}

	public String getClaimStatusDesc() {
		return claimStatusDesc;
	}

	public void setClaimStatusDesc(String claimStatusDesc) {
		this.claimStatusDesc = claimStatusDesc;
	}

	public String getLogCode() {
		return logCode;
	}

	public void setLogCode(String logCode) {
		this.logCode = logCode;
	}

	public String getLogDescription() {
		return logDescription;
	}

	public void setLogDescription(String logDescription) {
		this.logDescription = logDescription;
	}

	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}

	public String getPolicyNoWithCheckDigit() {
		return policyNoWithCheckDigit;
	}

	public void setPolicyNoWithCheckDigit(String policyNoWithCheckDigit) {
		this.policyNoWithCheckDigit = policyNoWithCheckDigit;
	}

	public String getPolicyNoWithoutCheckDigit() {
		return policyNoWithoutCheckDigit;
	}

	public void setPolicyNoWithoutCheckDigit(String policyNoWithoutCheckDigit) {
		this.policyNoWithoutCheckDigit = policyNoWithoutCheckDigit;
	}

	public String getLOB() {
		return LOB;
	}

	public void setLOB(String lOB) {
		LOB = lOB;
	}

	public String getGroupStatusCode() {
		return groupStatusCode;
	}

	public void setGroupStatusCode(String groupStatusCode) {
		this.groupStatusCode = groupStatusCode;
	}

	public String getGroupStatusDesc() {
		return groupStatusDesc;
	}

	public void setGroupStatusDesc(String groupStatusDesc) {
		this.groupStatusDesc = groupStatusDesc;
	}

	public BigDecimal getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(BigDecimal claimAmount) {
		this.claimAmount = claimAmount;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getRowStatus() {
		return rowStatus;
	}

	public void setRowStatus(String rowStatus) {
		this.rowStatus = rowStatus;
	}

	public int getTryCount() {
		return tryCount;
	}

	public void setTryCount(int tryCount) {
		this.tryCount = tryCount;
	}

	public String getReturnResult() {
		return returnResult;
	}

	public void setReturnResult(String returnResult) {
		this.returnResult = returnResult;
	}
}
