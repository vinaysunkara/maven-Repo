package com.aia.common.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolCoverage", propOrder = {
    "coverageName", "formNo", "expiryDate", "benefitAmount", "premiumAmount", "ceasedDate","maturityDateCICare",
    "maturityDateCIandMedBasic"
})
@XmlRootElement(name = "PolCoverage")
public class PolCoverage {


	@XmlElement(required = true) private String coverageName;
	@XmlElement(required = true) private String formNo;
	@XmlElement(required = true) private Date expiryDate;
	@XmlElement(required = true) private BigDecimal benefitAmount;
	@XmlElement(required = true) private BigDecimal premiumAmount;
	@XmlElement(required = true) private Date ceasedDate;
	@XmlElement(required = true) private Date maturityDateCICare;
	@XmlElement(required = true) private Date maturityDateCIandMedBasic;
	
	public Date getMaturityDateCICare() {
		return maturityDateCICare;
	}

	public void setMaturityDateCICare(Date maturityDateCICare) {
		this.maturityDateCICare = maturityDateCICare;
	}
	
	public String getCoverageName() {
		return coverageName;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public String getFormNo() {
		return formNo;
	}

	public void setFormNo(String formNo) {
		this.formNo = formNo;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public BigDecimal getBenefitAmount() {
		return benefitAmount;
	}

	public void setBenefitAmount(BigDecimal benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Date getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(Date ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	/**
	 * @return the maturityDateCIandMedBasic
	 */
	public Date getMaturityDateCIandMedBasic() {
		return maturityDateCIandMedBasic;
	}

	/**
	 * @param maturityDateCIandMedBasic the maturityDateCIandMedBasic to set
	 */
	public void setMaturityDateCIandMedBasic(Date maturityDateCIandMedBasic) {
		this.maturityDateCIandMedBasic = maturityDateCIandMedBasic;
	}
}
