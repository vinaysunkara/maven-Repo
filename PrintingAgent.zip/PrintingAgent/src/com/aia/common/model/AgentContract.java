package com.aia.common.model;

import java.util.Date;

public class AgentContract {
	private String nameAndId;
	private String trxId;
	private String agentRank;
	private String licenseProd;
	private String contractType;
	private String programType;
	private Date contractDate;
	private String agentName;
	private String idNo;
	private String address1;
	private String address2;
	private String address3;
	private String postcode;
	private String state;
	private String agentEmail;
	private String agencyCode;
	private String agentCode;
	private Date effectiveDate;
	private String stsCode;
	private Date applicantSignDate;
	private String applicantSign;
	private String witnessName;
	private String witnessIdNo;
	private Date witnessSignDate;
	private String witnessSign;
	private String emailTo;
	private String emailCc;
	private String city;
	private String contractDateString;
	private String contractId;
	private String addr1;
	private String addr2;
	private String addr3;

	public String getAgentRank() {
		return agentRank;
	}

	public void setAgentRank(String agentRank) {
		this.agentRank = agentRank;
	}

	public String getLicenseProd() {
		return licenseProd;
	}

	public void setLicenseProd(String licenseProd) {
		this.licenseProd = licenseProd;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	public Date getContractDate() {
		return contractDate;
	}

	public void setContractDate(Date contractDate) {
		this.contractDate = contractDate;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAgentEmail() {
		return agentEmail;
	}

	public void setAgentEmail(String agentEmail) {
		this.agentEmail = agentEmail;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getStsCode() {
		return stsCode;
	}

	public void setStsCode(String stsCode) {
		this.stsCode = stsCode;
	}

	public Date getApplicantSignDate() {
		return applicantSignDate;
	}

	public void setApplicantSignDate(Date applicantSignDate) {
		this.applicantSignDate = applicantSignDate;
	}

	public String getApplicantSign() {
		return applicantSign;
	}

	public void setApplicantSign(String applicantSign) {
		this.applicantSign = applicantSign;
	}

	public String getWitnessName() {
		return witnessName;
	}

	public void setWitnessName(String witnessName) {
		this.witnessName = witnessName;
	}

	public String getWitnessIdNo() {
		return witnessIdNo;
	}

	public void setWitnessIdNo(String witnessIdNo) {
		this.witnessIdNo = witnessIdNo;
	}

	public Date getWitnessSignDate() {
		return witnessSignDate;
	}

	public void setWitnessSignDate(Date witnessSignDate) {
		this.witnessSignDate = witnessSignDate;
	}

	public String getWitnessSign() {
		return witnessSign;
	}

	public void setWitnessSign(String witnessSign) {
		this.witnessSign = witnessSign;
	}

	public String getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}

	public String getEmailCc() {
		return emailCc;
	}

	public void setEmailCc(String emailCc) {
		this.emailCc = emailCc;
	}

	public String getNameAndId() {
		return nameAndId;
	}

	public void setNameAndId(String nameAndId) {
		this.nameAndId = nameAndId;
	}

	public String getTrxId() {
		return trxId;
	}

	public void setTrxId(String trxId) {
		this.trxId = trxId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContractDateString() {
		return contractDateString;
	}

	public void setContractDateString(String contractDateString) {
		this.contractDateString = contractDateString;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}
}
