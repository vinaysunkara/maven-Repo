package com.aia.common.model;

import java.util.Date;

public class POSServiceRequest {
	private String policyNo;
	private String keyRequestNo;
	private String requestNo;
	private String submitAgentCode;
	private String reqType;
	private String reqStatus;
	private String reqStatusDesc;
	private Date reqDate;
	private String lineOfBusiness;
	private Date lastUpdateDate;
	private String rowStatus;
	private int tryCount;
	private String returnResult;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getKeyRequestNo() {
		return keyRequestNo;
	}

	public void setKeyRequestNo(String keyRequestNo) {
		this.keyRequestNo = keyRequestNo;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getSubmitAgentCode() {
		return submitAgentCode;
	}

	public void setSubmitAgentCode(String submitAgentCode) {
		this.submitAgentCode = submitAgentCode;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getReqStatus() {
		return reqStatus;
	}

	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}

	public String getReqStatusDesc() {
		return reqStatusDesc;
	}

	public void setReqStatusDesc(String reqStatusDesc) {
		this.reqStatusDesc = reqStatusDesc;
	}

	public Date getReqDate() {
		return reqDate;
	}

	public void setReqDate(Date reqDate) {
		this.reqDate = reqDate;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getRowStatus() {
		return rowStatus;
	}

	public void setRowStatus(String rowStatus) {
		this.rowStatus = rowStatus;
	}

	public int getTryCount() {
		return tryCount;
	}

	public void setTryCount(int tryCount) {
		this.tryCount = tryCount;
	}

	public String getReturnResult() {
		return returnResult;
	}

	public void setReturnResult(String returnResult) {
		this.returnResult = returnResult;
	}
}
