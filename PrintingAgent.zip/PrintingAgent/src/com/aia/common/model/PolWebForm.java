package com.aia.common.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolWebForm", propOrder = {
    "policyNo", "serialNo", "typePri", "typeSec", "rcDate", "WithOriSignedForm","AppAuthorizeBankStaffID","appBankBranch","appHseLoanNo","appCCSSRefno",
    "LAPremiumPayable","appStaffName","appWitnessName","appWitnessIc","appWitnessDate","appName","appIcNew","appIcOther","APPNATIONALITY","appDob",
    "appAge","appGender","appMarital","APPOCCNATURE","appOcc","appOccclass","appAddLine1","appAddLine2",
    "appAddLine3","appAddPostcode","appAddState","AppCountry","appTelHp","appEmailAddress","APPFOREIGNERCLF","APPFOREIGNERFT",
    "appWasi","appConditionalHibah","appNomineeRel","appOptin","appFATCAUSPersonCircumstances","appFATCAUSPersonDataWaiver","appSignDated","appq1Aht",
    "appq1bWt","appq1cWtChg","appq2","appq3","appDetails","appFinancierName","applnAmtHse","appRepayPeriodHse",
    "appInterimPeriod","appPremiumFinanced","appIntRateHse","appFinancierSignDated",
    "appNameNominee","appIcNewNominee","appIcOtherNominee","appDobNominee","appAgeNominee","appAddLine1Nominee","appAddLine2Nominee",
    "appAddLine3Nominee","appAddPostcodeNominee","appAddStateNominee","appSellingAgent","appCompanyName", "appCompanyRegNo","appAddOffLine1","appAddOffLine2","appAddOffLine3",
    "appAddOffPostCode", "appAddOffCountry","appTelOffNo","appTelMobileNo","appUsTaxPayerID","appParentAppID","appLnAmtMdtaciHse","appCRS",
    "appCRSCountry1","appCRSTin1","appCRSReason1", "appCRSCountry2","appCRSTin2","appCRSReason2","appCRSCountry3","appCRSTin3","appCRSReason3","appCRSCountry4",
    "appCRSTin4","appCRSReason4","appCRSCountry5","appCRSTin5","appCRSReason5","CRSReasonOptj2","CRSReasonj2","nonCRSReasonoptj3","nonCRSReasonj3Other","appLASumAssured",
    "appLASinglePrem","appTotalContributionCIMRTT","appAddOffState","appj4Option","appCoverageTerm"
})
@XmlRootElement(name = "PolWebForm")
public class PolWebForm {
	

	@XmlElement(required = true) private String policyNo; 
	@XmlElement(required = true) private String serialNo;
	@XmlElement(required = true) private String typePri;
	@XmlElement(required = true) private String typeSec;
	@XmlElement(required = true) private Date rcDate;
	@XmlElement(required = true) private String WithOriSignedForm;
	@XmlElement(required = true) private String AppAuthorizeBankStaffID;
	@XmlElement(required = true) private String appBankBranch;
	@XmlElement(required = true) private String appHseLoanNo;
	@XmlElement(required = true) private String appCCSSRefno;
	@XmlElement(required = true) private BigDecimal LAPremiumPayable;
	@XmlElement(required = true) private String appStaffName;
	@XmlElement(required = true) private String appWitnessName;
	@XmlElement(required = true) private String appWitnessIc;
	@XmlElement(required = true) private Date appWitnessDate;
	@XmlElement(required = true) private String appName;
	@XmlElement(required = true) private String appIcNew;
	@XmlElement(required = true) private String appIcOther;
	@XmlElement(required = true) private String appNATIONALITY;
	@XmlElement(required = true) private Date appDob;
	@XmlElement(required = true) private String appAge;
	@XmlElement(required = true) private String appGender;
	@XmlElement(required = true) private String appMarital;
	@XmlElement(required = true) private String appOCCNATURE;
	@XmlElement(required = true) private String appOcc;
	@XmlElement(required = true) private String appOccclass;
	@XmlElement(required = true) private String appAddLine1;
	@XmlElement(required = true) private String appAddLine2;
	@XmlElement(required = true) private String appAddLine3;
	@XmlElement(required = true) private String appAddPostcode;
	@XmlElement(required = true) private String appAddState;
	@XmlElement(required = true) private String AppCountry;
	@XmlElement(required = true) private String appTelHp;
	@XmlElement(required = true) private String appEmailAddress;
	@XmlElement(required = true) private String appFOREIGNERCLF;
	@XmlElement(required = true) private String appFOREIGNERFT;
	@XmlElement(required = true) private String appWasi;
	@XmlElement(required = true) private String appConditionalHibah;
	@XmlElement(required = true) private String appNomineeRel;
	@XmlElement(required = true) private String appOptin;
	@XmlElement(required = true) private String appFATCAUSPersonCircumstances;
	@XmlElement(required = true) private String appFATCAUSPersonDataWaiver;
	@XmlElement(required = true) private Date appSignDated;
	@XmlElement(required = true) private String appq1Aht;
	@XmlElement(required = true) private String appq1bWt;
	@XmlElement(required = true) private String appq1cWtChg;
	@XmlElement(required = true) private String appq2;
	@XmlElement(required = true) private String appq3;
	@XmlElement(required = true) private String appDetails;
	@XmlElement(required = true) private String appFinancierName;
	@XmlElement(required = true) private BigDecimal applnAmtHse;
	@XmlElement(required = true) private int appRepayPeriodHse;
	@XmlElement(required = true) private int appInterimPeriod;
	@XmlElement(required = true) private String appPremiumFinanced;
	@XmlElement(required = true) private BigDecimal appIntRateHse;
	@XmlElement(required = true) private Date appFinancierSignDated;
	@XmlElement(required = true) private BigDecimal laPremiumPayable;

	
	@XmlElement(required = true) private String appNameNominee;
	@XmlElement(required = true) private String appIcNewNominee;
	@XmlElement(required = true) private String appIcOtherNominee;
	@XmlElement(required = true) private Date appDobNominee;
	@XmlElement(required = true) private String appAgeNominee;
	@XmlElement(required = true) private String appAddLine1Nominee;
	@XmlElement(required = true) private String appAddLine2Nominee;
	@XmlElement(required = true) private String appAddLine3Nominee;
	@XmlElement(required = true) private String appAddPostcodeNominee;
	@XmlElement(required = true) private String appAddStateNominee;
	@XmlElement(required = true) private String appSellingAgent;
	
	//--------------------added new field----------------
	@XmlElement(required=true) private String appCompanyName;
	@XmlElement(required=true) private String appCompanyRegNo;
	@XmlElement(required=true) private String appAddOffLine1;
	@XmlElement(required=true) private String appAddOffLine2;
	@XmlElement(required=true) private String appAddOffLine3;
	@XmlElement(required=true) private String appAddOffPostCode;
	@XmlElement(required=true) private String appAddOffCountry;
	@XmlElement(required=true) private String appAddOffState;
	
	@XmlElement(required=true) private String appTelOffNo;
	@XmlElement(required=true) private String appTelMobileNo;
	@XmlElement(required=true) private String appUsTaxPayerID;
	@XmlElement(required=true) private String appParentAppID;
	@XmlElement(required=true) private String appLnAmtMdtaciHse;
	@XmlElement(required=true) private BigDecimal appLASumAssured;
	@XmlElement(required=true) private BigDecimal appLASinglePrem;
	@XmlElement(required = true) private String appCoverageTerm;;
	@XmlElement(required=true) private BigDecimal appTotalContributionCIMRTT;
	
	@XmlElement(required=true) private String appCRS;
	@XmlElement(required=true) private String appCRSCountry1;
	@XmlElement(required=true) private String appCRSTin1;
	@XmlElement(required=true) private String appCRSReason1;
	@XmlElement(required=true) private String appCRSCountry2;
	@XmlElement(required=true) private String appCRSTin2;
	@XmlElement(required=true) private String appCRSReason2;
	@XmlElement(required=true) private String appCRSCountry3;
	@XmlElement(required=true) private String appCRSTin3;
	@XmlElement(required=true) private String appCRSReason3;
	@XmlElement(required=true) private String appCRSCountry4;
	@XmlElement(required=true) private String appCRSTin4;
	@XmlElement(required=true) private String appCRSReason4;
	@XmlElement(required=true) private String appCRSCountry5;
	@XmlElement(required=true) private String appCRSTin5;
	@XmlElement(required=true) private String appCRSReason5;
	
	@XmlElement(required=true) private String CRSReasonOptj2;
	@XmlElement(required=true) private String CRSReasonj2;
	
	
	@XmlElement(required=true) private String nonCRSReasonoptj3;
	@XmlElement(required=true) private String nonCRSReasonj3Other;
	@XmlElement(required=true) private String appj4Option;

	public String getAppCRS() {
		return appCRS;
	}
	public void setAppCRS(String appCRS) {
		this.appCRS = appCRS;
	}
	public String getAppCRSCountry1() {
		return appCRSCountry1;
	}
	public void setAppCRSCountry1(String appCRSCountry1) {
		this.appCRSCountry1 = appCRSCountry1;
	}
	public String getAppCRSTin1() {
		return appCRSTin1;
	}
	public void setAppCRSTin1(String appCRSTin1) {
		this.appCRSTin1 = appCRSTin1;
	}
	public String getAppCRSReason1() {
		return appCRSReason1;
	}
	public void setAppCRSReason1(String appCRSReason1) {
		this.appCRSReason1 = appCRSReason1;
	}
	public String getAppCRSCountry2() {
		return appCRSCountry2;
	}
	public void setAppCRSCountry2(String appCRSCountry2) {
		this.appCRSCountry2 = appCRSCountry2;
	}
	public String getAppCRSTin2() {
		return appCRSTin2;
	}
	public void setAppCRSTin2(String appCRSTin2) {
		this.appCRSTin2 = appCRSTin2;
	}
	public String getAppCRSReason2() {
		return appCRSReason2;
	}
	public void setAppCRSReason2(String appCRSReason2) {
		this.appCRSReason2 = appCRSReason2;
	}
	public String getAppCRSCountry3() {
		return appCRSCountry3;
	}
	public void setAppCRSCountry3(String appCRSCountry3) {
		this.appCRSCountry3 = appCRSCountry3;
	}
	public String getAppCRSTin3() {
		return appCRSTin3;
	}
	public void setAppCRSTin3(String appCRSTin3) {
		this.appCRSTin3 = appCRSTin3;
	}
	public String getAppCRSReason3() {
		return appCRSReason3;
	}
	public void setAppCRSReason3(String appCRSReason3) {
		this.appCRSReason3 = appCRSReason3;
	}
	public String getAppCRSCountry4() {
		return appCRSCountry4;
	}
	public void setAppCRSCountry4(String appCRSCountry4) {
		this.appCRSCountry4 = appCRSCountry4;
	}
	public String getAppCRSTin4() {
		return appCRSTin4;
	}
	public void setAppCRSTin4(String appCRSTin4) {
		this.appCRSTin4 = appCRSTin4;
	}
	public String getAppCRSReason4() {
		return appCRSReason4;
	}
	public void setAppCRSReason4(String appCRSReason4) {
		this.appCRSReason4 = appCRSReason4;
	}
	public String getAppCRSCountry5() {
		return appCRSCountry5;
	}
	public void setAppCRSCountry5(String appCRSCountry5) {
		this.appCRSCountry5 = appCRSCountry5;
	}
	public String getAppCRSTin5() {
		return appCRSTin5;
	}
	public void setAppCRSTin5(String appCRSTin5) {
		this.appCRSTin5 = appCRSTin5;
	}
	public String getAppCRSReason5() {
		return appCRSReason5;
	}
	public void setAppCRSReason5(String appCRSReason5) {
		this.appCRSReason5 = appCRSReason5;
	}
	public String getCRSReasonOptj2() {
		return CRSReasonOptj2;
	}
	public void setCRSReasonOptj2(String cRSReasonOptj2) {
		CRSReasonOptj2 = cRSReasonOptj2;
	}
	public String getCRSReasonj2() {
		return CRSReasonj2;
	}
	public void setCRSReasonj2(String cRSReasonj2) {
		CRSReasonj2 = cRSReasonj2;
	}
	public String getNonCRSReasonoptj3() {
		return nonCRSReasonoptj3;
	}
	public void setNonCRSReasonoptj3(String nonCRSReasonoptj3) {
		this.nonCRSReasonoptj3 = nonCRSReasonoptj3;
	}
	public String getNonCRSReasonj3Other() {
		return nonCRSReasonj3Other;
	}
	public void setNonCRSReasonj3Other(String nonCRSReasonj3Other) {
		this.nonCRSReasonj3Other = nonCRSReasonj3Other;
	}
	
	public String getAppCompanyName() {
		return appCompanyName;
	}
	public void setAppCompanyName(String appCompanyName) {
		this.appCompanyName = appCompanyName;
	}
	public String getAppCompanyRegNo() {
		return appCompanyRegNo;
	}
	public void setAppCompanyRegNo(String appCompanyRegNo) {
		this.appCompanyRegNo = appCompanyRegNo;
	}
	public String getAppAddOffLine1() {
		return appAddOffLine1;
	}
	public void setAppAddOffLine1(String appAddOffLine1) {
		this.appAddOffLine1 = appAddOffLine1;
	}
	public String getAppAddOffLine2() {
		return appAddOffLine2;
	}
	public void setAppAddOffLine2(String appAddOffLine2) {
		this.appAddOffLine2 = appAddOffLine2;
	}
	public String getAppAddOffLine3() {
		return appAddOffLine3;
	}
	public void setAppAddOffLine3(String appAddOffLine3) {
		this.appAddOffLine3 = appAddOffLine3;
	}
	public String getAppAddOffPostCode() {
		return appAddOffPostCode;
	}
	public void setAppAddOffPostCode(String appAddOffPostCode) {
		this.appAddOffPostCode = appAddOffPostCode;
	}
	public String getAppAddOffCountry() {
		return appAddOffCountry;
	}
	public void setAppAddOffCountry(String appAddOffCountry) {
		this.appAddOffCountry = appAddOffCountry;
	}
	
	public String getAppTelOffNo() {
		return appTelOffNo;
	}
	public void setAppTelOffNo(String appTelOffNo) {
		this.appTelOffNo = appTelOffNo;
	}
	public String getAppTelMobileNo() {
		return appTelMobileNo;
	}
	public void setAppTelMobileNo(String appTelMobileNo) {
		this.appTelMobileNo = appTelMobileNo;
	}
	public String getAppUsTaxPayerID() {
		return appUsTaxPayerID;
	}
	public void setAppUsTaxPayerID(String appUsTaxPayerID) {
		this.appUsTaxPayerID = appUsTaxPayerID;
	}
	public String getAppParentAppID() {
		return appParentAppID;
	}
	public void setAppParentAppID(String appParentAppID) {
		this.appParentAppID = appParentAppID;
	}
	public String getAppLnAmtMdtaciHse() {
		return appLnAmtMdtaciHse;
	}
	public void setAppLnAmtMdtaciHse(String appLnAmtMdtaciHse) {
		this.appLnAmtMdtaciHse = appLnAmtMdtaciHse;
	}
	/**
	 * @return the appq2
	 */
	public String getAppq2() {
		return appq2;
	}
	/**
	 * @param appq2 the appq2 to set
	 */
	public void setAppq2(String appq2) {
		this.appq2 = appq2;
	}
	/**
	 * @return the appq3
	 */
	public String getAppq3() {
		return appq3;
	}
	/**
	 * @param appq3 the appq3 to set
	 */
	public void setAppq3(String appq3) {
		this.appq3 = appq3;
	}
	/**
	 * @return the appDetails
	 */
	public String getAppDetails() {
		return appDetails;
	}
	/**
	 * @param appDetails the appDetails to set
	 */
	public void setAppDetails(String appDetails) {
		this.appDetails = appDetails;
	}
	/**
	 * @return the appFinancierName
	 */
	public String getAppFinancierName() {
		return appFinancierName;
	}
	/**
	 * @param appFinancierName the appFinancierName to set
	 */
	public void setAppFinancierName(String appFinancierName) {
		this.appFinancierName = appFinancierName;
	}
	/**
	 * @return the applnAmtHse
	 */
	public BigDecimal getApplnAmtHse() {
		return applnAmtHse;
	}
	/**
	 * @param applnAmtHse the applnAmtHse to set
	 */
	public void setApplnAmtHse(BigDecimal applnAmtHse) {
		this.applnAmtHse = applnAmtHse;
	}
	/**
	 * @return the appRepayPeriodHse
	 */
	public int getAppRepayPeriodHse() {
		return appRepayPeriodHse;
	}
	/**
	 * @param appRepayPeriodHse the appRepayPeriodHse to set
	 */
	public void setAppRepayPeriodHse(int appRepayPeriodHse) {
		this.appRepayPeriodHse = appRepayPeriodHse;
	}
	/**
	 * @return the appInterimPeriod
	 */
	public int getAppInterimPeriod() {
		return appInterimPeriod;
	}
	/**
	 * @param appInterimPeriod the appInterimPeriod to set
	 */
	public void setAppInterimPeriod(int appInterimPeriod) {
		this.appInterimPeriod = appInterimPeriod;
	}
	/**
	 * @return the appPremiumFinanced
	 */
	public String getAppPremiumFinanced() {
		return appPremiumFinanced;
	}
	/**
	 * @param appPremiumFinanced the appPremiumFinanced to set
	 */
	public void setAppPremiumFinanced(String appPremiumFinanced) {
		this.appPremiumFinanced = appPremiumFinanced;
	}
	/**
	 * @return the appIntRateHse
	 */
	public BigDecimal getAppIntRateHse() {
		return appIntRateHse;
	}
	/**
	 * @param appIntRateHse the appIntRateHse to set
	 */
	public void setAppIntRateHse(BigDecimal appIntRateHse) {
		this.appIntRateHse = appIntRateHse;
	}
	/**
	 * @return the appFinancierSignDated
	 */
	public Date getAppFinancierSignDated() {
		return appFinancierSignDated;
	}
	/**
	 * @param appFinancierSignDated the appFinancierSignDated to set
	 */
	public void setAppFinancierSignDated(Date appFinancierSignDated) {
		this.appFinancierSignDated = appFinancierSignDated;
	}
	//	@XmlElement(required = true) private Date maturityDateCICare;
	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}
	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}
	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	/**
	 * @return the appIcNew
	 */
	public String getAppIcNew() {
		return appIcNew;
	}
	/**
	 * @param appIcNew the appIcNew to set
	 */
	public void setAppIcNew(String appIcNew) {
		this.appIcNew = appIcNew;
	}
	/**
	 * @return the appIcOther
	 */
	public String getAppIcOther() {
		return appIcOther;
	}
	/**
	 * @param appIcOther the appIcOther to set
	 */
	public void setAppIcOther(String appIcOther) {
		this.appIcOther = appIcOther;
	}

	/**
	 * @return the appDob
	 */
	public Date getAppDob() {
		return appDob;
	}
	/**
	 * @param appDob the appDob to set
	 */
	public void setAppDob(Date appDob) {
		this.appDob = appDob;
	}

	/**
	 * @return the appGender
	 */
	public String getAppGender() {
		return appGender;
	}
	/**
	 * @param appGender the appGender to set
	 */
	public void setAppGender(String appGender) {
		this.appGender = appGender;
	}
	/**
	 * @return the appMarital
	 */
	public String getAppMarital() {
		return appMarital;
	}
	/**
	 * @param appMarital the appMarital to set
	 */
	public void setAppMarital(String appMarital) {
		this.appMarital = appMarital;
	}

	/**
	 * @return the appOcc
	 */
	public String getAppOcc() {
		return appOcc;
	}
	/**
	 * @param appOcc the appOcc to set
	 */
	public void setAppOcc(String appOcc) {
		this.appOcc = appOcc;
	}
	/**
	 * @return the appOccclass
	 */
	public String getAppOccclass() {
		return appOccclass;
	}
	/**
	 * @param appOccclass the appOccclass to set
	 */
	public void setAppOccclass(String appOccclass) {
		this.appOccclass = appOccclass;
	}
	/**
	 * @return the appAddLine1
	 */
	public String getAppAddLine1() {
		return appAddLine1;
	}
	/**
	 * @param appAddLine1 the appAddLine1 to set
	 */
	public void setAppAddLine1(String appAddLine1) {
		this.appAddLine1 = appAddLine1;
	}
	/**
	 * @return the appAddLine2
	 */
	public String getAppAddLine2() {
		return appAddLine2;
	}
	/**
	 * @param appAddLine2 the appAddLine2 to set
	 */
	public void setAppAddLine2(String appAddLine2) {
		this.appAddLine2 = appAddLine2;
	}
	/**
	 * @return the appAddLine3
	 */
	public String getAppAddLine3() {
		return appAddLine3;
	}
	/**
	 * @param appAddLine3 the appAddLine3 to set
	 */
	public void setAppAddLine3(String appAddLine3) {
		this.appAddLine3 = appAddLine3;
	}
	/**
	 * @return the appAddPostcode
	 */
	public String getAppAddPostcode() {
		return appAddPostcode;
	}
	/**
	 * @param appAddPostcode the appAddPostcode to set
	 */
	public void setAppAddPostcode(String appAddPostcode) {
		this.appAddPostcode = appAddPostcode;
	}
	/**
	 * @return the appAddState
	 */
	public String getAppAddState() {
		return appAddState;
	}
	/**
	 * @param appAddState the appAddState to set
	 */
	public void setAppAddState(String appAddState) {
		this.appAddState = appAddState;
	}
	/**
	 * @return the appCountry
	 */
	public String getAppCountry() {
		return AppCountry;
	}
	/**
	 * @param appCountry the appCountry to set
	 */
	public void setAppCountry(String appCountry) {
		AppCountry = appCountry;
	}
	/**
	 * @return the appTelHp
	 */
	public String getAppTelHp() {
		return appTelHp;
	}
	/**
	 * @param appTelHp the appTelHp to set
	 */
	public void setAppTelHp(String appTelHp) {
		this.appTelHp = appTelHp;
	}
	/**
	 * @return the appEmailAddress
	 */
	public String getAppEmailAddress() {
		return appEmailAddress;
	}
	/**
	 * @param appEmailAddress the appEmailAddress to set
	 */
	public void setAppEmailAddress(String appEmailAddress) {
		this.appEmailAddress = appEmailAddress;
	}


	/**
	 * @return the appNATIONALITY
	 */
	public String getAppNATIONALITY() {
		return appNATIONALITY;
	}
	/**
	 * @param appNATIONALITY the appNATIONALITY to set
	 */
	public void setAppNATIONALITY(String appNATIONALITY) {
		this.appNATIONALITY = appNATIONALITY;
	}
	/**
	 * @return the appAge
	 */
	public String getAppAge() {
		return appAge;
	}
	/**
	 * @param appAge the appAge to set
	 */
	public void setAppAge(String appAge) {
		this.appAge = appAge;
	}
	/**
	 * @return the appOCCNATURE
	 */
	public String getAppOCCNATURE() {
		return appOCCNATURE;
	}
	/**
	 * @param appOCCNATURE the appOCCNATURE to set
	 */
	public void setAppOCCNATURE(String appOCCNATURE) {
		this.appOCCNATURE = appOCCNATURE;
	}
	/**
	 * @return the appFOREIGNERCLF
	 */
	public String getAppFOREIGNERCLF() {
		return appFOREIGNERCLF;
	}
	/**
	 * @param appFOREIGNERCLF the appFOREIGNERCLF to set
	 */
	public void setAppFOREIGNERCLF(String appFOREIGNERCLF) {
		this.appFOREIGNERCLF = appFOREIGNERCLF;
	}
	/**
	 * @return the appFOREIGNERFT
	 */
	public String getAppFOREIGNERFT() {
		return appFOREIGNERFT;
	}
	/**
	 * @param appFOREIGNERFT the appFOREIGNERFT to set
	 */
	public void setAppFOREIGNERFT(String appFOREIGNERFT) {
		this.appFOREIGNERFT = appFOREIGNERFT;
	}
	/**
	 * @return the appq1Aht
	 */
	public String getAppq1Aht() {
		return appq1Aht;
	}
	/**
	 * @param appq1Aht the appq1Aht to set
	 */
	public void setAppq1Aht(String appq1Aht) {
		this.appq1Aht = appq1Aht;
	}
	/**
	 * @return the appq1bWt
	 */
	public String getAppq1bWt() {
		return appq1bWt;
	}
	/**
	 * @param appq1bWt the appq1bWt to set
	 */
	public void setAppq1bWt(String appq1bWt) {
		this.appq1bWt = appq1bWt;
	}
	/**
	 * @return the appq1cWtChg
	 */
	public String getAppq1cWtChg() {
		return appq1cWtChg;
	}
	/**
	 * @param appq1cWtChg the appq1cWtChg to set
	 */
	public void setAppq1cWtChg(String appq1cWtChg) {
		this.appq1cWtChg = appq1cWtChg;
	}
	/**
	 * @return the laPremiumPayable
	 */
	public BigDecimal getLaPremiumPayable() {
		return laPremiumPayable;
	}
	/**
	 * @param laPremiumPayable the laPremiumPayable to set
	 */
	public void setLaPremiumPayable(BigDecimal laPremiumPayable) {
		this.laPremiumPayable = laPremiumPayable;
	}
	/**
	 * @return the appWasi
	 */
	public String getAppWasi() {
		return appWasi;
	}
	/**
	 * @param appWasi the appWasi to set
	 */
	public void setAppWasi(String appWasi) {
		this.appWasi = appWasi;
	}
	/**
	 * @return the appConditionalHibah
	 */
	public String getAppConditionalHibah() {
		return appConditionalHibah;
	}
	/**
	 * @param appConditionalHibah the appConditionalHibah to set
	 */
	public void setAppConditionalHibah(String appConditionalHibah) {
		this.appConditionalHibah = appConditionalHibah;
	}
	/**
	 * @return the appNomineeRel
	 */
	public String getAppNomineeRel() {
		return appNomineeRel;
	}
	/**
	 * @param appNomineeRel the appNomineeRel to set
	 */
	public void setAppNomineeRel(String appNomineeRel) {
		this.appNomineeRel = appNomineeRel;
	}
	/**
	 * @return the appOptin
	 */
	public String getAppOptin() {
		return appOptin;
	}
	/**
	 * @param appOptin the appOptin to set
	 */
	public void setAppOptin(String appOptin) {
		this.appOptin = appOptin;
	}
	/**
	 * @return the appFATCAUSPersonCircumstances
	 */
	public String getAppFATCAUSPersonCircumstances() {
		return appFATCAUSPersonCircumstances;
	}
	/**
	 * @param appFATCAUSPersonCircumstances the appFATCAUSPersonCircumstances to set
	 */
	public void setAppFATCAUSPersonCircumstances(
			String appFATCAUSPersonCircumstances) {
		this.appFATCAUSPersonCircumstances = appFATCAUSPersonCircumstances;
	}
	/**
	 * @return the appFATCAUSPersonDataWaiver
	 */
	public String getAppFATCAUSPersonDataWaiver() {
		return appFATCAUSPersonDataWaiver;
	}
	/**
	 * @param appFATCAUSPersonDataWaiver the appFATCAUSPersonDataWaiver to set
	 */
	public void setAppFATCAUSPersonDataWaiver(String appFATCAUSPersonDataWaiver) {
		this.appFATCAUSPersonDataWaiver = appFATCAUSPersonDataWaiver;
	}
	/**
	 * @return the appSignDated
	 */
	public Date getAppSignDated() {
		return appSignDated;
	}
	/**
	 * @param appSignDated the appSignDated to set
	 */
	public void setAppSignDated(Date appSignDated) {
		this.appSignDated = appSignDated;
	}
	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	/**
	 * @return the serialNo
	 */
	public String getSerialNo() {
		return serialNo;
	}
	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	/**
	 * @return the typePri
	 */
	/**
	 * @return the typePri
	 */
	public String getTypePri() {
		return typePri;
	}
	/**
	 * @param typePri the typePri to set
	 */
	public void setTypePri(String typePri) {
		this.typePri = typePri;
	}
	/**
	 * @return the typeSec
	 */
	public String getTypeSec() {
		return typeSec;
	}
	/**
	 * @param typeSec the typeSec to set
	 */
	public void setTypeSec(String typeSec) {
		this.typeSec = typeSec;
	}
	/**
	 * @return the rcDate
	 */
	public Date getRcDate() {
		return rcDate;
	}
	/**
	 * @param rcDate the rcDate to set
	 */
	public void setRcDate(Date rcDate) {
		this.rcDate = rcDate;
	}
	/**
	 * @return the withOriSignedForm
	 */
	public String getWithOriSignedForm() {
		return WithOriSignedForm;
	}
	/**
	 * @param withOriSignedForm the withOriSignedForm to set
	 */
	public void setWithOriSignedForm(String withOriSignedForm) {
		WithOriSignedForm = withOriSignedForm;
	}
	/**
	 * @return the appAuthorizeBankStaffID
	 */
	public String getAppAuthorizeBankStaffID() {
		return AppAuthorizeBankStaffID;
	}
	/**
	 * @param appAuthorizeBankStaffID the appAuthorizeBankStaffID to set
	 */
	public void setAppAuthorizeBankStaffID(String appAuthorizeBankStaffID) {
		AppAuthorizeBankStaffID = appAuthorizeBankStaffID;
	}
	/**
	 * @return the appBankBranch
	 */
	public String getAppBankBranch() {
		return appBankBranch;
	}
	/**
	 * @param appBankBranch the appBankBranch to set
	 */
	public void setAppBankBranch(String appBankBranch) {
		this.appBankBranch = appBankBranch;
	}
	/**
	 * @return the appHseLoanNo
	 */
	public String getAppHseLoanNo() {
		return appHseLoanNo;
	}
	/**
	 * @param appHseLoanNo the appHseLoanNo to set
	 */
	public void setAppHseLoanNo(String appHseLoanNo) {
		this.appHseLoanNo = appHseLoanNo;
	}
	/**
	 * @return the appCCSSRefno
	 */
	public String getAppCCSSRefno() {
		return appCCSSRefno;
	}
	/**
	 * @param appCCSSRefno the appCCSSRefno to set
	 */
	public void setAppCCSSRefno(String appCCSSRefno) {
		this.appCCSSRefno = appCCSSRefno;
	}
	/**
	 * @return the lAPremiumPayable
	 */
	public BigDecimal getLAPremiumPayable() {
		return LAPremiumPayable;
	}
	/**
	 * @param lAPremiumPayable the lAPremiumPayable to set
	 */
	public void setLAPremiumPayable(BigDecimal lAPremiumPayable) {
		LAPremiumPayable = lAPremiumPayable;
	}
	/**
	 * @return the appStaffName
	 */
	public String getAppStaffName() {
		return appStaffName;
	}
	/**
	 * @param appStaffName the appStaffName to set
	 */
	public void setAppStaffName(String appStaffName) {
		this.appStaffName = appStaffName;
	}
	/**
	 * @return the appWitnessName
	 */
	public String getAppWitnessName() {
		return appWitnessName;
	}
	/**
	 * @param appWitnessName the appWitnessName to set
	 */
	public void setAppWitnessName(String appWitnessName) {
		this.appWitnessName = appWitnessName;
	}
	/**
	 * @return the appWitnessIc
	 */
	public String getAppWitnessIc() {
		return appWitnessIc;
	}
	/**
	 * @param appWitnessIc the appWitnessIc to set
	 */
	public void setAppWitnessIc(String appWitnessIc) {
		this.appWitnessIc = appWitnessIc;
	}
	/**
	 * @return the appWitnessDate
	 */
	public Date getAppWitnessDate() {
		return appWitnessDate;
	}
	/**
	 * @param appWitnessDate the appWitnessDate to set
	 */
	public void setAppWitnessDate(Date appWitnessDate) {
		this.appWitnessDate = appWitnessDate;
	}
	

	/**
	 * @return the appNameNominee
	 */
	public String getAppNameNominee() {
		return appNameNominee;
	}
	/**
	 * @param appNameNominee the appNameNominee to set
	 */
	public void setAppNameNominee(String appNameNominee) {
		this.appNameNominee = appNameNominee;
	}
	/**
	 * @return the appIcNewNominee
	 */
	public String getAppIcNewNominee() {
		return appIcNewNominee;
	}
	/**
	 * @param appIcNewNominee the appIcNewNominee to set
	 */
	public void setAppIcNewNominee(String appIcNewNominee) {
		this.appIcNewNominee = appIcNewNominee;
	}
	/**
	 * @return the appIcOtherNominee
	 */
	public String getAppIcOtherNominee() {
		return appIcOtherNominee;
	}
	/**
	 * @param appIcOtherNominee the appIcOtherNominee to set
	 */
	public void setAppIcOtherNominee(String appIcOtherNominee) {
		this.appIcOtherNominee = appIcOtherNominee;
	}
	/**
	 * @return the appDobNominee
	 */
	public Date getAppDobNominee() {
		return appDobNominee;
	}
	/**
	 * @param appDobNominee the appDobNominee to set
	 */
	public void setAppDobNominee(Date appDobNominee) {
		this.appDobNominee = appDobNominee;
	}
	/**
	 * @return the appAgeNominee
	 */
	public String getAppAgeNominee() {
		return appAgeNominee;
	}
	/**
	 * @param appAgeNominee the appAgeNominee to set
	 */
	public void setAppAgeNominee(String appAgeNominee) {
		this.appAgeNominee = appAgeNominee;
	}
	/**
	 * @return the appAddLine1Nominee
	 */
	public String getAppAddLine1Nominee() {
		return appAddLine1Nominee;
	}
	/**
	 * @param appAddLine1Nominee the appAddLine1Nominee to set
	 */
	public void setAppAddLine1Nominee(String appAddLine1Nominee) {
		this.appAddLine1Nominee = appAddLine1Nominee;
	}
	/**
	 * @return the appAddLine2Nominee
	 */
	public String getAppAddLine2Nominee() {
		return appAddLine2Nominee;
	}
	/**
	 * @param appAddLine2Nominee the appAddLine2Nominee to set
	 */
	public void setAppAddLine2Nominee(String appAddLine2Nominee) {
		this.appAddLine2Nominee = appAddLine2Nominee;
	}
	/**
	 * @return the appAddLine3Nominee
	 */
	public String getAppAddLine3Nominee() {
		return appAddLine3Nominee;
	}
	/**
	 * @param appAddLine3Nominee the appAddLine3Nominee to set
	 */
	public void setAppAddLine3Nominee(String appAddLine3Nominee) {
		this.appAddLine3Nominee = appAddLine3Nominee;
	}
	/**
	 * @return the appAddPostcodeNominee
	 */
	public String getAppAddPostcodeNominee() {
		return appAddPostcodeNominee;
	}
	/**
	 * @param appAddPostcodeNominee the appAddPostcodeNominee to set
	 */
	public void setAppAddPostcodeNominee(String appAddPostcodeNominee) {
		this.appAddPostcodeNominee = appAddPostcodeNominee;
	}
	/**
	 * @return the appAddStateNominee
	 */
	public String getAppAddStateNominee() {
		return appAddStateNominee;
	}
	/**
	 * @param appAddStateNominee the appAddStateNominee to set
	 */
	public void setAppAddStateNominee(String appAddStateNominee) {
		this.appAddStateNominee = appAddStateNominee;
	}
	public String getAppSellingAgent() {
		return appSellingAgent;
	}
	public void setAppSellingAgent(String appSellingAgent) {
		this.appSellingAgent = appSellingAgent;
	}
	public BigDecimal getAppLASumAssured() {
		return appLASumAssured;
	}
	public void setAppLASumAssured(BigDecimal appLASumAssured) {
		this.appLASumAssured = appLASumAssured;
	}
	public BigDecimal getAppLASinglePrem() {
		return appLASinglePrem;
	}
	public void setAppLASinglePrem(BigDecimal appLASinglePrem) {
		this.appLASinglePrem = appLASinglePrem;
	}
	public String getAppAddOffState() {
		return appAddOffState;
	}
	public void setAppAddOffState(String appAddOffState) {
		this.appAddOffState = appAddOffState;
	}
	public BigDecimal getAppTotalContributionCIMRTT() {
		return appTotalContributionCIMRTT;
	}
	public void setAppTotalContributionCIMRTT(BigDecimal appTotalContributionCIMRTT) {
		this.appTotalContributionCIMRTT = appTotalContributionCIMRTT;
	}
	
	public String getAppj4Option() {
		return appj4Option;
	}
	public void setAppj4Option(String appj4Option) {
		this.appj4Option = appj4Option;
	}
	public String getAppCoverageTerm() {
		return appCoverageTerm;
	}
	public void setAppCoverageTerm(String appCoverageTerm) {
		this.appCoverageTerm = appCoverageTerm;
	}
	
	
}
