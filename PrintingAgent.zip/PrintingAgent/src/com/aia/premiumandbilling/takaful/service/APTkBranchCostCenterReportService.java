package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.premiumandbilling.common.branchcostcenter.model.BranchCostCenter;
import com.aia.premiumandbilling.common.branchcostcenter.model.BranchCostCenterGrandTotalAmnt;
import com.aia.premiumandbilling.common.branchcostcenter.model.BranchCostCenterSubTotalAmnt;
import com.aia.premiumandbilling.common.branchcostcenter.model.BranchCstCenterTbleData;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

public class APTkBranchCostCenterReportService extends Thread {
	   
	
	private Thread t;

	public void run() {
		genReport();
		
	}

	public void genReport(){
		HashMap<Integer,List<BranchCostCenter>> branchCstCenterListDetails=	getBranchCstCenterTbleData();
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> branchCstCenterdataRS=getBranchCstCenterReportDetails();
		int noFiles=branchCstCenterdataRS.size();
		for(int i=0;i<noFiles;i++) {
			HashMap<String, Object> dataSource=new HashMap<String, Object>();
			
			List<BranchCostCenter> branchCstCenterTbleDataList=branchCstCenterListDetails.get(i);
            HashMap<Integer, HashMap<String, Object>> branchCstCenterMaindata=branchCstCenterdataRS.get(i);
			for (int a = 0; a <branchCstCenterMaindata.size(); a++) {
				dataSource.putAll(branchCstCenterMaindata.get(a));
			}
			dataSource.put("listBranchCostCenter", branchCstCenterTbleDataList);
			uploadReport(dataSource);
			
			}
		
	}
	
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		try {
			 String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg";
			  String logo= FilenameUtils.normalize(imgpath, true); 
			  dataSource.put("logo",logo);
			
			
			//JRBeanCollectionDataSource beandataSource = new JRBeanCollectionDataSource(listBranchCostCenter);
			 String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			 //System.out.println("templet  :"+dataSource.get("templetType"));
			 String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_BrhCostCentre";
				
			 String pdfOutputpath="D:\\Test_Write\\jasperPDf\\premium\\takafull\\";
				String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
				String templetId=null;
				String jrMainReportFullReadpath=null;
				String jrSubReportFullReadpath =null;
				if(dataSource.get("templetType").equals("GI")){
				    templetId="AIAGIB001";
					jrMainReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\takaful\\branchcostCenter\\BranchCostCenter.jasper";
				    jrSubReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\takaful\\branchcostCenter\\BranchCostCenterSubReport.jasper";
				}else{
					templetId="AIACON001";
					jrMainReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\takaful\\branchcostCenter\\BranchCostCenter.jasper";
					jrSubReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\takaful\\branchcostCenter\\BranchCostCenterSubReport.jasper";
					}
				FileInputStream mainreportinputStream = new FileInputStream(jrMainReportFullReadpath);
	            JasperReport subreport = (JasperReport)JRLoader.loadObjectFromFile(jrSubReportFullReadpath);
	            dataSource.put("branchCostCenterSubReport", subreport);
	     	JasperPrint jasperPrint = JasperFillManager.fillReport(mainreportinputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
			//JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,datasource, beandataSource);// for compiled Report .jrxml file
			
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println(templetId+" ===> PDF Generated..."+pdfFullOutputPath);
			mainreportinputStream.close();
			outputStream.close();
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e.toString());
		}
	}
	public HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getBranchCstCenterReportDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\BranchAndCostCenterReport.txt";
		
		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> branchCstCenterdataRS = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

		
		HashMap<Integer, HashMap<String, Object>> branchCstCenterdata = new HashMap<Integer, HashMap<String, Object>>();
		
		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Branch cost Center Report Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					HashMap<String, Object> branchCstCenter = new HashMap<String, Object>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						branchCstCenter = new HashMap<String, Object>();
						branchCstCenterdata = new HashMap<Integer, HashMap<String, Object>>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")) {
							branchCstCenter.put("policyHolder",data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
							branchCstCenter.put("subsidiary",data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
							branchCstCenter.put("policyNum",data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							branchCstCenter.put("policyPeriod",data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
							branchCstCenter.put("billNum",data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
							branchCstCenter.put("dateOfIssue",data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
							branchCstCenter.put("billingPeriod",data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
							branchCstCenter.put("billingFrequecy",data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
							branchCstCenter.put("adjustmentFrequency",data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
							branchCstCenter.put("printHardCp",data[13] != null&& data[13].length() > 0 ? data[13].trim(): "");
							branchCstCenter.put("templetType",data[14] != null&& data[14].length() > 0 ? data[14].trim(): "");
						}
					if(data[0].equalsIgnoreCase("0001")){
						branchCstCenterdata.put(cuurline, branchCstCenter);
						cuurline++;
						branchCstCenterdataRS.put(pdfgencount, branchCstCenterdata);
					}
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[BranchCstCenterService.getBranchCstCenterReportDetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return branchCstCenterdataRS;
	}
	
	
	HashMap<Integer,List<BranchCostCenter>> getBranchCstCenterTbleData(){
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\BranchAndCostCenterReport.txt";
		
		HashMap<Integer,List<BranchCostCenter>> branchCstCenterListDetails = new HashMap<Integer, List<BranchCostCenter>>();
		
		List<BranchCostCenter> branchCostCenterList = new  ArrayList<BranchCostCenter>();
		List<BranchCstCenterTbleData> branchCstCenterTbleDataList = new  ArrayList<BranchCstCenterTbleData>();
		List<BranchCostCenterSubTotalAmnt> branchCostCenterSubTotalAmntList=	new	ArrayList<BranchCostCenterSubTotalAmnt>();
		List<BranchCostCenterGrandTotalAmnt> branchCostCenterGrandTotalAmntList=	new	ArrayList<BranchCostCenterGrandTotalAmnt>();
		
		
		BufferedReader br = null;
		FileReader fr = null;
		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No TkBranchCostCenter Flat file ");
			} else {
				String sCurrentLine;
				int pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					BranchCostCenter branchCostCenter=new BranchCostCenter();
					BranchCstCenterTbleData branchCstCenterTbleData=new BranchCstCenterTbleData();
					BranchCostCenterSubTotalAmnt branchCostCenterSubTotalAmnt=new	BranchCostCenterSubTotalAmnt();
					BranchCostCenterGrandTotalAmnt branchCostCenterGrandTotalAmnt=new BranchCostCenterGrandTotalAmnt();
					//boolean add = false;
					if (sCurrentLine.contains("****")) {
						branchCostCenter=new BranchCostCenter();
						branchCostCenterList = new  ArrayList<BranchCostCenter>();
						pdfgencount++;
					}
					String data[] = sCurrentLine.split("\\|");
					if (data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("2H")) {
							 branchCostCenter.setBranchName(data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
							 branchCstCenterTbleDataList = new  ArrayList<BranchCstCenterTbleData>();
							 branchCostCenterSubTotalAmntList=	new	ArrayList<BranchCostCenterSubTotalAmnt>();
							 branchCostCenterGrandTotalAmntList=	new	ArrayList<BranchCostCenterGrandTotalAmnt>();
					}if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("3D")) {
								branchCstCenterTbleData.setCostCenter(data[2] != null && data[2].length() > 0 ? data[2].trim() : "");
								branchCstCenterTbleData.setEmpCount(Long.parseLong(data[3] != null && data[3].length() > 0 ? data[3].trim() : ""));
								branchCstCenterTbleData.setEmpPremium(data[4] != null && data[4].length() > 0 ? data[4].trim() : "");
								branchCstCenterTbleData.setEmpAdminVitalityFee(data[5] != null && data[5].length() > 0 ? data[5].trim() : "");
								branchCstCenterTbleData.setSpouseCount(Long.parseLong(data[6] != null && data[6].length() > 0 ? data[6].trim() : ""));
	                            branchCstCenterTbleData.setSpousePremium(data[7] != null && data[7].length() > 0 ? data[7].trim() : "");
	                            branchCstCenterTbleData.setSpouseAdminVitalityFee(data[8] != null && data[8].length() > 0 ? data[8].trim() : "");
	                            branchCstCenterTbleData.setChildCount(Long.parseLong(data[9] != null && data[9].length() > 0 ? data[9].trim() : ""));
	                            branchCstCenterTbleData.setChildPremium(data[10] != null && data[10].length() > 0 ? data[10].trim() : "");
	                            branchCstCenterTbleData.setChildAdminVitalityFee(data[11] != null && data[11].length() > 0 ? data[11].trim() : "");
	                            branchCstCenterTbleData.setTotalCount(Long.parseLong(data[12] != null && data[12].length() > 0 ? data[12].trim() : ""));
	                            branchCstCenterTbleData.setTotalPremium(data[13] != null && data[13].length() > 0 ? data[13].trim() : "");
	                            branchCstCenterTbleData.setTotalAdminVitalityFee(data[14] != null && data[14].length() > 0 ? data[14].trim() : "");
	                            branchCstCenterTbleData.setTotalSt(data[15] != null && data[15].length() > 0 ? data[15].trim() : "");
	                            branchCstCenterTbleData.setTotalPremiumAdminVitalitySt(data[16] != null && data[16].length() > 0 ? data[16].trim() : "");
	                            branchCstCenterTbleDataList.add(branchCstCenterTbleData);
	                         }
					    	 branchCostCenter.setBranchCstCenterTbleData(branchCstCenterTbleDataList);
						     if(data[0].equalsIgnoreCase("0004") && data[1].equalsIgnoreCase("1S")) {
					    		 branchCostCenterSubTotalAmnt.setSubTtlEmpCount(Long.parseLong(data[2] != null&& data[2].length() > 0 ? data[2].trim(): ""));
					    		 branchCostCenterSubTotalAmnt.setSubTtlEmpPremium(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlEmpAdminVitalityFee(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlSpouseCount(Long.parseLong(data[5] != null&& data[5].length() > 0 ? data[5].trim(): ""));
							     branchCostCenterSubTotalAmnt.setSubTtlSpousePremium(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlSpouseAdminVitalityFee(data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlChildCount(Long.parseLong(data[8] != null&& data[8].length() > 0 ? data[8].trim(): ""));
					    		 branchCostCenterSubTotalAmnt.setSubTtlChildPremium(data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlChildAdminVitalityFee(data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlTotalCount(Long.parseLong(data[11] != null&& data[11].length() > 0 ? data[11].trim(): ""));
					    		 branchCostCenterSubTotalAmnt.setSubTtlTotalPremium(data[12] != null&& data[12].length() > 0 ? data[12].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlTotalAdminVitalityFee(data[13] != null&& data[13].length() > 0 ? data[13].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlTotalSt(data[14] != null&& data[14].length() > 0 ? data[14].trim(): "");
					    		 branchCostCenterSubTotalAmnt.setSubTtlTotalPremiumAdminVitalityFee(data[15] != null&& data[15].length() > 0 ? data[15].trim(): "");
					    		 branchCostCenterSubTotalAmntList.add(branchCostCenterSubTotalAmnt);
					    	 }
					    	 branchCostCenter.setBranchCostCenterSubTotalAmnt(branchCostCenterSubTotalAmntList);
					    	 if(data[0].equalsIgnoreCase("0005") && data[1].equalsIgnoreCase("1G")) {
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlEmpCount(Long.parseLong(data[2] != null&& data[2].length() > 0 ? data[2].trim(): ""));
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlEmpPremium(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlEmpAdminVitalityFee(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlSpouseCount(Long.parseLong(data[5] != null&& data[5].length() > 0 ? data[5].trim(): ""));
							     branchCostCenterGrandTotalAmnt.setGrandTtlSpousePremium(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlSpouseAdminVitalityFee(data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlChildCount(Long.parseLong(data[8] != null&& data[8].length() > 0 ? data[8].trim(): ""));
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlChildPremium(data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlChildAdminVitalityFee(data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlTotalCount(Long.parseLong(data[11] != null&& data[11].length() > 0 ? data[11].trim(): ""));
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlTotalPremium(data[12] != null&& data[12].length() > 0 ? data[12].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlTotalAdminVitalityFee(data[13] != null&& data[13].length() > 0 ? data[13].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlTotalSt(data[14] != null&& data[14].length() > 0 ? data[14].trim(): "");
					    		 branchCostCenterGrandTotalAmnt.setGrandTtlTotalPremiumAdminVitalityFee(data[15] != null&& data[15].length() > 0 ? data[15].trim(): "");
					    		 branchCostCenterGrandTotalAmntList.add(branchCostCenterGrandTotalAmnt);
					    	 }
					    	 branchCostCenter.setBranchCostCenterGrandTotalAmnt(branchCostCenterGrandTotalAmntList);
					   if (data[0].equalsIgnoreCase("0002")) {
							branchCostCenterList.add(branchCostCenter);
							branchCstCenterListDetails.put(pdfgencount, branchCostCenterList);
						}
				}
			}
                     
		} catch (Exception e) {
			System.out.println(
					"[TkBranchCostCenterReportService.getBranchCstCenterTbleData()] Exception: " + e.toString());
			e.printStackTrace();
		}
		return branchCstCenterListDetails;
	}

	
// for negative or  positive value
/*public String String value){
	String v=value.trim();
	char firstchar=v.charAt(0);
	char c='(';
	if(c==firstchar){
		String negativevalue=v.replace("(", "-").replace(")", "");
		return negativevalue;
	}else{
		return value;
	}
}
*/
public void startBatch() {
	System.out.println("Starting thread ");

	if (t == null) {
		t = new Thread(this);
		t.start();
	}
}

public static void main(String args[]) {
	APTkBranchCostCenterReportService b = new APTkBranchCostCenterReportService();
	b.startBatch();
	System.out.println("startedd.....");
}

}
