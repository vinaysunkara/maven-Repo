package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.common.utility.BytesToStringUtil;
import com.aia.premiumandbilling.common.invoice.model.InvoiceTabledata;

import net.sf.jasperreports.engine.JREmptyDataSource;

//import org.apache.commons.io.FilenameUtils;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;



public class APTkInvoiceService extends Thread {
	private Thread t;

	public void run() {
		generatePdf();
	}

	public  void generatePdf() {
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> ListinvoiceRSdetails = getInvoicDetails();
		HashMap<Integer, List<InvoiceTabledata>> invoiceTabledataListDetails=	getInvoicTableData();
		int noFiles = ListinvoiceRSdetails.size();
        for (int i = 0; i < noFiles; i++) {
			HashMap<Integer, HashMap<String, Object>> invoiceRS = ListinvoiceRSdetails.get(i);
			List<InvoiceTabledata> invoiceTabledataList=invoiceTabledataListDetails.get(i);
			HashMap<String, Object> dataSource=new HashMap<String, Object>();
			
			for (int a = 0; a <invoiceRS.size(); a++) {
				HashMap<String, Object> details = invoiceRS.get(a);
				dataSource.putAll(details);
			}
			dataSource.put("InvoiceTabledatadatasource", invoiceTabledataList);
			upLoadReport(dataSource);
				
		}
	}
	
	public  void upLoadReport(HashMap<String, Object> dataSource) {
		try {
			   String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo",logo);	
			//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
		
			 String  templetId="APTK001";
				String pdfOutputRootPath="D:\\Test_Write\\jasperPDf\\premium\\takafull\\";
				String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_Invoice";
				String	pdfFullOutputPath=pdfOutputRootPath+""+pdfname+".pdf";
				
				 String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				 String jrFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\Invoice\\invoice.jasper";
		
			
			
	       // InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
			FileInputStream inputStream = new FileInputStream(jrFullReadpath);
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);

		  //JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,params,new JREmptyDataSource());// for compiled Report .jasper file
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println(templetId+"==> PDF Generated..."+pdfFullOutputPath);
			//String pdfstringdata=BytesToStringUtil.getString(pdfFullOutputPath);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} finally {

		}
	}

	public static HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getInvoicDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\invoice.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<String, Object>> invoicresult = new HashMap<Integer, HashMap<String, Object>>();
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> listInvoiceDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Invoice Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					HashMap<String, Object> invoice = new HashMap<String, Object>();
					if (cuurline == 0 || sCurrentLine.contains("****")) {
						invoice = new HashMap<String, Object>();
						invoicresult = new HashMap<Integer, HashMap<String, Object>>();
						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
					
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("01")) {
							invoice.put("companyName", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
							invoice.put("addressLine1", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							invoice.put("addressLine2", data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
							invoice.put("addressLine3", data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
							invoice.put("addressLine4", data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
							invoice.put("addressLine5", data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
							invoice.put("printHardCp", data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
							invoice.put("templetType", data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
							invoice.put("bankName","Citibank Account No.");
							invoice.put("bankAcNo","0111279063");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("02")) {
							invoice.put("billNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
							invoice.put("dateOfIssue", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							invoice.put("billingPeriod", data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
							invoice.put("paymentDueDate", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("03")) {
							invoice.put("policyHolder", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("04") ) {
							invoice.put("subsidiary",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("05") ) {
							invoice.put("policyNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("06")) {
							invoice.put("policyPeriod", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("07") ) {
							invoice.put("poNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
                        } 
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1T")&& data[2].equalsIgnoreCase("01") ) {
							invoice.put("totalAmtExSt", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							invoice.put("totalAmtSt", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
							invoice.put("totalAmountInclSt", data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1S") && data[2].equalsIgnoreCase("01")) {
							invoice.put("reasonOfbilling", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1R")&& data[2].equalsIgnoreCase("01") ) {
							invoice.put("email",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
						}
					
					if (data[0].equalsIgnoreCase("0001")) {
						invoicresult.put(cuurline, invoice);
						cuurline++;
						listInvoiceDetails.put(pdfgencount, invoicresult);
					}
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[Invoice.getInvoicedetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listInvoiceDetails;
	}
	
	public static HashMap<Integer, List<InvoiceTabledata>> getInvoicTableData() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\invoice.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<InvoiceTabledata> invoiceTabledataList = new  ArrayList<InvoiceTabledata>();
		HashMap<Integer,List<InvoiceTabledata>> invoiceTabledataListDetails = new HashMap<Integer, List<InvoiceTabledata>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Invoice Flat file ");
			} else {
				String sCurrentLine;
				int pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					InvoiceTabledata invoiceTabledata=new InvoiceTabledata();
				
					if (  sCurrentLine.contains("****")) {
						invoiceTabledata=new InvoiceTabledata();
						invoiceTabledataList = new  ArrayList<InvoiceTabledata>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
					}
					
					String data[]=sCurrentLine.split("\\|");
					 for(int i=0; i<data.length;i++) {
						 if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1D")){
							 	 invoiceTabledata.setDescription( data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
								 invoiceTabledata.setBillType(data[5] != null && data[5].length() > 0 ? data[5].trim() : "");
								 invoiceTabledata.setAmountExSt(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
								 invoiceTabledata.setAmountSt(data[7] != null && data[7].length() > 0 ? data[7].trim() : "");
								 invoiceTabledata.setAmountInclSt( data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
						}
					}
						 if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1D")){
							 invoiceTabledataList.add(invoiceTabledata);
							 invoiceTabledataListDetails.put(pdfgencount, invoiceTabledataList);
					 }
					
					
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[Invoice.getInvoicedetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return invoiceTabledataListDetails;
	}
	
	
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		APTkInvoiceService invoice = new APTkInvoiceService();
		invoice.startBatch();
		System.out.println("startedd.....");
	}
}