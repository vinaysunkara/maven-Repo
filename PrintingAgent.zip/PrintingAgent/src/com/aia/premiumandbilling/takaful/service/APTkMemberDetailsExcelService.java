package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.aia.premiumandbilling.common.memberdetailsexcel.model.MemberDetails;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;

@SuppressWarnings("deprecation")
public class APTkMemberDetailsExcelService extends Thread {
	private Thread t;

	public void run() {
		generateExcelReport();
	}
   private void generateExcelReport(){
	List<MemberDetails> listmemberDetails = getMemberDetails();
	String excelOutputPath = "D:\\Test_Write\\jasperPDf\\premium\\takafull\\memberDetailsExcel.xlsx";
	//String filename = "memberdetailsExcel2.xlsx";
	//MemberDetailsExcelUtil.upLoadExcel(listmemberDetails, excelOutputPath);
	String[] column={"Policy Number","Company Name","Bill Number","Employee Name","Employee\nNRIC/Passport No.","Employee ID",
			"Employee Age","Member Name","Membership No.","Relationship","Plan No.","Plan Description","Product Code","Product Description","Branch","Cost Centre","Proposed Sum Assured",
			"Accepted Sum Assured","Increase/Decrease Sum Assured","Underwriting Status","Premium (RM)","Loading Premium (EM Loading + OA Loading)","Service Tax on Premium (6%)","Admin/Vitality Fee (RM)",
			"Service Tax on Admin/Vitality Fee (6%)","Effective Date","Premium From","Premium To","Movement Type","Seq No"};

		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("memberDetails");

		Font headerfont = sheet.getWorkbook().createFont();
		headerfont.setBold(true);
		headerfont.setFontHeightInPoints((short) 9);
		CellStyle headercellStyle = sheet.getWorkbook().createCellStyle();
		headercellStyle.setFont(headerfont);
		// cellStyle.setAlignment(HorizontalAlignment.CENTER);
		headercellStyle.setVerticalAlignment(VerticalAlignment.TOP);

		
		  
		Row hedderRow = sheet.createRow(0);
		hedderRow.setHeight((short) (1.5 * sheet.getDefaultRowHeight()));
		for (int i = 0; i < column.length; i++) {
		Cell cell = hedderRow.createCell(i);
			cell.setCellValue(column[i]);
			cell.setCellStyle(headercellStyle);
			//System.out.println(i+"."+column[i]);
		}
		
		Font font = sheet.getWorkbook().createFont();
		font.setFontHeightInPoints((short) 9);
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
		cellStyle.setWrapText(true);
		cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
		cellStyle.setFont(font);
		int rowCount = 1;
		// data row
		for (MemberDetails memberdata : listmemberDetails) {
			Row row = sheet.createRow(rowCount++);
			row.setHeight((short) (1 * sheet.getDefaultRowHeight()));
			createDataRow(memberdata, row, cellStyle);
		}
		for (int i = 0; i < column.length; i++) {
			sheet.autoSizeColumn(i);
		}
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(excelOutputPath);
			workbook.write(outputStream);
			System.out.println("excel created .... :" + excelOutputPath);
		} catch (Exception e) {
			System.out.println("Exception in APTkMemberDetailsExcelService.getMemberDetails() :" + e.toString());
		} finally {
			try {
				outputStream.close();
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}    
	
	}
   
   private static void createDataRow(MemberDetails memberDetails,Row row, CellStyle cellStyle) {
		
	    Cell cell_0= row.createCell(0);
	    cell_0.setCellStyle(cellStyle);
	    cell_0.setCellValue(memberDetails.getPolicyNum());
	    
	    Cell cell_1 = row.createCell(1);
	    cell_1.setCellStyle(cellStyle);
	    //cell_1.setCellValue(memberDetails.getBillNum());
	    cell_1.setCellValue(memberDetails.getCompany());
	    
	    Cell cell2 = row.createCell(2);
	    cell2.setCellStyle(cellStyle);
	   // cell2.setCellValue(memberDetails.getCompany());
	    cell2.setCellValue(memberDetails.getBillNum());
			
	    Cell cell3 = row.createCell(3);
	    cell3.setCellStyle(cellStyle);
	    cell3.setCellValue(memberDetails.getEmpName());
	    
	    Cell cell4 = row.createCell(4);
	    cell4.setCellStyle(cellStyle);
	    cell4.setCellValue(memberDetails.getEmpInricPasprtNum());
	    
	    Cell cell5 = row.createCell(5);
	    cell5.setCellStyle(cellStyle);
	    cell5.setCellValue(memberDetails.getEmpId());
	    
	    Cell cell6 = row.createCell(6);
	    cell6.setCellStyle(cellStyle);
	    cell6.setCellValue(memberDetails.getEmpAge());
	    
	    Cell cell7 = row.createCell(7);
	    cell7.setCellStyle(cellStyle);
	    cell7.setCellValue(memberDetails.getMemName());
	    
	    Cell cell8 = row.createCell(8);
	    cell8.setCellStyle(cellStyle);
	    cell8.setCellValue(memberDetails.getMemberShipNum());
	    
	    Cell cell9 = row.createCell(9);
	    cell9.setCellStyle(cellStyle);
	    cell9.setCellValue(memberDetails.getRelationship());
			
	    Cell cell_10 = row.createCell(10);
	    cell_10.setCellStyle(cellStyle);
	    cell_10.setCellValue(memberDetails.getPlanNum());
			 
	    Cell cell_11 = row.createCell(11);
	    cell_11.setCellStyle(cellStyle);
	    cell_11.setCellValue(memberDetails.getPlanDscr());
	    
	    Cell cell_12 = row.createCell(12);
	    cell_12.setCellStyle(cellStyle);
	    cell_12.setCellValue(memberDetails.getProdCode());
	    
	    Cell cell_13 = row.createCell(13);
	    cell_13.setCellStyle(cellStyle);
	    cell_13.setCellValue(memberDetails.getProdDscr());
	    
	    Cell cell_14 = row.createCell(14);
	    cell_14.setCellStyle(cellStyle);
	    cell_14.setCellValue(memberDetails.getBranch());
	    
	    Cell cell_15 = row.createCell(15);
	    cell_15.setCellStyle(cellStyle);
	    cell_15.setCellValue(memberDetails.getCostCenter());
	    
	    Cell cell_16 = row.createCell(16);
	    cell_16.setCellStyle(cellStyle);
	    cell_16.setCellValue(memberDetails.getProposedSumAssured());
	    
	    Cell cell_17 = row.createCell(17);
	    cell_17.setCellStyle(cellStyle);
	    cell_17.setCellValue(memberDetails.getAcceptedSumAssured());
	    
	    Cell cell_18 = row.createCell(18);
	    cell_18.setCellStyle(cellStyle);
	    cell_18.setCellValue(memberDetails.getIncreOrDecreSumAssured());
	    
	    Cell cell_19 = row.createCell(19);
	    cell_19.setCellStyle(cellStyle);
	    cell_19.setCellValue(memberDetails.getUnderwritingStatus());
			 
	    Cell cell_20 = row.createCell(20);
	    cell_20.setCellStyle(cellStyle);
	    cell_20.setCellValue(memberDetails.getPremium());
	    
	    Cell cell_21 = row.createCell(21);
	    cell_21.setCellStyle(cellStyle);
	    cell_21.setCellValue(memberDetails.getLoadingPremium());
	    
	    Cell cell_22 = row.createCell(22);
	    cell_22.setCellStyle(cellStyle);
	    cell_22.setCellValue(memberDetails.getServiceTaxonPremium());
	    
	    Cell cell_23 = row.createCell(23);
	    cell_23.setCellStyle(cellStyle);
	    cell_23.setCellValue(memberDetails.getAdminVitalityFee());
	    
	    Cell cell_24 = row.createCell(24);
	    cell_24.setCellStyle(cellStyle);
	    cell_24.setCellValue(memberDetails.getServiceTaxonAdminVitalityFee());
	    
	    Cell cell_25 = row.createCell(25);
	    cell_25.setCellStyle(cellStyle);
	    cell_25.setCellValue(memberDetails.getEffectiveDate());
	    
	    Cell cell_26 = row.createCell(26);
	    cell_26.setCellStyle(cellStyle);
	    cell_26.setCellValue(memberDetails.getPremiumFrom());
	    
	    Cell cell_27 = row.createCell(27);
	    cell_27.setCellStyle(cellStyle);
	    cell_27.setCellValue(memberDetails.getPremiumTo());
	    
	    Cell cell_28 = row.createCell(28);
	    cell_28.setCellStyle(cellStyle);
	    cell_28.setCellValue(memberDetails.getMovementType());
	    
	    Cell cell_29 = row.createCell(29);
	    cell_29.setCellStyle(cellStyle);
	    cell_29.setCellValue(memberDetails.getSeqNum());
	    	    
	   }
   
   

	private List<MemberDetails> getMemberDetails() {
		List<MemberDetails> listmemberDetails = new ArrayList<MemberDetails>();

		String filerReadPath = "D:\\Test_Read\\txtFiles\\conventional\\memberdetailsExcel.txt";
		BufferedReader br = null;
		FileReader fr = null;

		try {
			fr = new FileReader(filerReadPath);
			br = new BufferedReader(fr);

			if (br == null || br.equals(null)) {
				System.out.println("No Debit Flat File....");
			} else {
				String sCurrentline;
				while ((sCurrentline = br.readLine()) != null) {
					MemberDetails memberDetails = new MemberDetails();
					String data[] = sCurrentline.split("\\|");
				
						if (data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")) {
								memberDetails.setPolicyNum(data[2].length() > 0 ? data[2].trim() : "");
								memberDetails.setBillNum(data[3].length() > 0 ? data[3].trim() : "");
								memberDetails.setCompany(data[4].length() > 0 ? data[4].trim() : "");
								memberDetails.setEmpName(data[5].length() > 0 ? data[5].trim() : "");
								memberDetails.setEmpInricPasprtNum(data[6].length() > 0 ? data[6].trim() : "");
								memberDetails.setEmpId(data[7].length() > 0 ? data[7].trim() : "");
								memberDetails.setEmpAge(data[8].length() > 0 ? data[8].trim() : "");
								memberDetails.setMemName(data[9].length() > 0 ? data[9].trim() : "");
								memberDetails.setMemberShipNum(data[10].length() > 0 ? data[10].trim() : "");
								memberDetails.setRelationship(data[11].length() > 0 ? data[11].trim() : "");
								memberDetails.setPlanNum(data[12].length() > 0 ? data[12].trim() : "");
								memberDetails.setPlanDscr(data[13].length() > 0 ? data[13].trim() : "");
								memberDetails.setProdCode(data[14].length() > 0 ? data[14].trim() : "");
								memberDetails.setProdDscr(data[15].length() > 0 ? data[15].trim() : "");
								memberDetails.setBranch(data[16].length() > 0 ? data[16].trim() : "");
								memberDetails.setCostCenter(data[17].length() > 0 ? data[17].trim() : "");
								memberDetails.setProposedSumAssured(data[18].length() > 0 ? data[18].trim() : "");
								memberDetails.setAcceptedSumAssured(data[19].length() > 0 ? data[19].trim() : "");
								memberDetails.setIncreOrDecreSumAssured(data[20].length() > 0 ? data[20].trim() : "");
								memberDetails.setUnderwritingStatus(data[21].length() > 0 ? data[21].trim() : "");
								memberDetails.setPremium(data[22].length() > 0 ? data[22].trim() : "");
								memberDetails.setLoadingPremium(data[23].length() > 0 ? data[23].trim() : "");
								memberDetails.setServiceTaxonPremium(data[24].length() > 0 ? data[24].trim() : "");
								memberDetails.setAdminVitalityFee(data[25].length() > 0 ? data[25].trim() : "");
								memberDetails.setServiceTaxonAdminVitalityFee(data[26].length() > 0 ? data[26].trim() : "");
								memberDetails.setEffectiveDate(data[27].length() > 0 ? data[27].trim() : "");
								memberDetails.setPremiumFrom(data[28].length() > 0 ? data[28].trim() : "");
								memberDetails.setPremiumTo(data[29].length() > 0 ? data[29].trim() : "");
								memberDetails.setMovementType(data[30].length() > 0 ? data[30].trim() : "");
								//memberDetails.setSeqNum(data[31].length() > 0 ? data[31].trim() : "");
								listmemberDetails.add(memberDetails);
					}
				}

			}

		} catch (Exception e) {
			System.out.println(
					"[MemberClaimeDetailsListingExcelService.getMemberClimeDetails()]  Exception : " + e.toString());
		}
		return listmemberDetails;
	}
	     
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		APTkMemberDetailsExcelService s = new APTkMemberDetailsExcelService();
		s.startBatch();
		System.out.println("startedd.....");
	}
}
