package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.premiumandbilling.common.commisionstatement.model.CommissionStatementTableData;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

public class APTkCommisionStatementService extends Thread{
	private Thread t;

	public void run() {
		genReport();
	}

	public void genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> commissionStatementdataRS=getCommissionStatementDetails();
		HashMap<Integer,List<CommissionStatementTableData>> commissionStatementTbleDataListDetails=	getCommissionStatementTableData();
		int noFiles=commissionStatementdataRS.size();
		System.out.println("pdf files :"+noFiles);
		for(int i=0;i<noFiles;i++) {
			HashMap<Integer, HashMap<String, Object>> commissionStatementdata=commissionStatementdataRS.get(i);
			List<CommissionStatementTableData> commissionStatementTbleDataList=commissionStatementTbleDataListDetails.get(i);
			
			HashMap<String, Object> dataSource=new HashMap<String, Object>();
			
			for (int a = 0; a <commissionStatementdata.size(); a++) {
				HashMap<String, Object> details = commissionStatementdata.get(a);
				dataSource.putAll(details);
			}
			for(CommissionStatementTableData c:commissionStatementTbleDataList){
				System.out.println(c.getProduct()+"  "+c.getDescription()+"  "+c.getCommission()+"  "+c.getAmount());
				
			}
			dataSource.put("commissionStatementTbleDataList", commissionStatementTbleDataList);
			uploadReport(dataSource);
		}
	}
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		try {
			 String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo",logo);
			   
			
			System.out.println("Total amount : "+dataSource.get("totalAmnt"));
			String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_CommStmt";
			String pdfOutputpath="D:\\Test_Write\\jasperPDf\\premium\\takafull\\";
			String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
			
			String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			String jrFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\commissionStatement\\CommStmt.jasper";
			String  jrSubReportFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\commissionStatement\\commissionStmtSubReport.jasper";
			//JRBeanCollectionDataSource beandataSource = new JRBeanCollectionDataSource(commissionStatementTbleDataList);
			 
	       FileInputStream inputStream = new FileInputStream(jrFullReadpath);
	      // FileInputStream inputStream = new FileInputStream(jrSubReportFullReadpath);
			
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
	      
		   JasperReport subreport = (JasperReport)JRLoader.loadObjectFromFile(jrSubReportFullReadpath);
           
		   dataSource.put("commissionStmtSubReport",subreport);
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
			//JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, beandataSource);// for compiled Report .jrxml file

			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println("PDF Generated..."+pdfFullOutputPath);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} finally {

		}
	}
	
	
	
	public HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getCommissionStatementDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\Commissionstmnt.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> commissionStatementdataRS = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();
		HashMap<Integer, HashMap<String, Object>> commissionStatementdata = new HashMap<Integer, HashMap<String, Object>>();
		
		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No CommissionStatement Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					// System.out.println("getDebitDetails() : sCurrentLine "+sCurrentLine);
					Boolean add = false;
					HashMap<String, Object> commissionStatement = new HashMap<String, Object>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						commissionStatement = new HashMap<String, Object>();
						commissionStatementdata = new HashMap<Integer, HashMap<String, Object>>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
					for (int i = 0; i < data.length; i++) {
						if (data[0].equalsIgnoreCase("0001")||data[0].equalsIgnoreCase("0003")) {
							add = true;
						} // System.out.println(data[i]);

						
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==2) {
							commissionStatement.put("companyName",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==3) {
							commissionStatement.put("address1",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==4) {
							commissionStatement.put("address2",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==5) {
							commissionStatement.put("address3",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==6) {
							commissionStatement.put("address4",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==7) {
							commissionStatement.put("address5",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==8) {
							commissionStatement.put("address6",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")&&i==9) {
							commissionStatement.put("printHardCp",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==2) {
							commissionStatement.put("policyHolder",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==3) {
							commissionStatement.put("subsidiary",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==4) {
							commissionStatement.put("policyNum",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==5) {
							commissionStatement.put("policyPeriod",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==6) {
							commissionStatement.put("billNum",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==7) {
							commissionStatement.put("dateOfIssue",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")&&i==8) {
							commissionStatement.put("billingPeriod",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("1T")&&i==3) {
								commissionStatement.put("totalAmnt",data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
						}
						
						
					}
					if(add){
						commissionStatementdata.put(cuurline, commissionStatement);
						cuurline++;
						commissionStatementdataRS.put(pdfgencount, commissionStatementdata);
					}
					
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[CommissionStatementService.getCommissionStatementDetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return commissionStatementdataRS;
	}
	
	
	
	private HashMap<Integer, List<CommissionStatementTableData>> getCommissionStatementTableData() {

		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\Commissionstmnt.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<CommissionStatementTableData> commissionStatementTableDataList = new  ArrayList<CommissionStatementTableData>();
		HashMap<Integer,List<CommissionStatementTableData>> commissionStatementTableDataListListDetails = new HashMap<Integer, List<CommissionStatementTableData>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No CommissionStatement Flat file ");
			} else {
				String sCurrentLine;
				int currentLint = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					CommissionStatementTableData commissionStatementTbleData=new CommissionStatementTableData();
					if (currentLint == 0 || sCurrentLine.contains("****")) {
						commissionStatementTbleData=new CommissionStatementTableData();
						commissionStatementTableDataList = new  ArrayList<CommissionStatementTableData>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						currentLint = 0;
					}
					
					String data[]=sCurrentLine.split("\\|");
					 for(int i=0; i<data.length;i++) {
						 if(data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
								if(i==2) {
									//branchCstCenterTbleData.setCostCenter(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
									commissionStatementTbleData.setProduct(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==3) {
									//branchCstCenterTbleData.setCostCenter(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
									commissionStatementTbleData.setDescription(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==4) {
									//branchCstCenterTbleData.setCostCenter(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
									commissionStatementTbleData.setCommission(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
								}
								if(i==5) {
									//branchCstCenterTbleData.setCostCenter(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
									commissionStatementTbleData.setAmount(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
								}
							}
						
					 }
					 if(data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
						 commissionStatementTableDataList.add(commissionStatementTbleData);
							
						}
					 currentLint++;
					 commissionStatementTableDataListListDetails.put(pdfgencount, commissionStatementTableDataList);
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[CommissionStatementService.getcommissionStatementTbleData] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return commissionStatementTableDataListListDetails;
	}
	
	
	
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		APTkCommisionStatementService c = new APTkCommisionStatementService();
		c.startBatch();
		System.out.println("startedd.....");
	}
}
