package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.aia.premiumandbilling.conventional.memberclaimedetailsexcell.model.MemberClaimeDetailsExcel;


public class APTkMemberClaimeDetailsListingExcelService extends Thread {
	private Thread t;
	
	public void run() {
		
		generateExcelReport();
		/*List<MemberClaimeDetails> listmemberClimeDetails=getMemberClimeDetails();
		
		String excelOutputPath ="D:\\Test_Write\\excels\\MemberClimeDetailsListingExcel.xls";
		MemberClaimeDetailsListingExcelUtil.uploadExcel(listmemberClimeDetails, excelOutputPath);
		*/
	           /*  for(MemberClimeDetails memberClimeDetails:listmemberClimeDetails) {
	            	 System.out.println(memberClimeDetails);
	             }*/
	}
	
	
	 private void generateExcelReport(){
		 String excelOutputPath = "D:\\Test_Write\\jasperPDf\\premium\\takafull\\MemberClimeDetailsListingExcel.xlsx";
			
			List<MemberClaimeDetailsExcel> listmemberClimeDetails = getMemberClimeDetails();
			//String filename = "memberdetailsExcel2.xlsx";
			//MemberDetailsExcelUtil.upLoadExcel(listmemberDetails, excelOutputPath);
			String[] column={"Certificate Number","Company Name","Billing Month \n [MM/YYYY]","Bill Number","Claim No.","Employee Name","Employee \n NRIC/Passport No.","Employee ID",
					"Claimant Name","Membership No.","Relationship","Plan No.","Plan Description","Product Code","Product Description","Branch","Cost Centre","Visit Date","Provider","Claim Type",
					"ASO Billed Amount (RM)"," Claims Paid Amount (RM)","Claim Paid Date"};

				Workbook workbook = new XSSFWorkbook();
				Sheet sheet = workbook.createSheet("memberDetails");

				Font headerfont = sheet.getWorkbook().createFont();
				headerfont.setBold(true);
				headerfont.setFontHeightInPoints((short) 9);
				CellStyle headercellStyle = sheet.getWorkbook().createCellStyle();
				headercellStyle.setWrapText(true);
				headercellStyle.setFont(headerfont);
				// cellStyle.setAlignment(HorizontalAlignment.CENTER);
				headercellStyle.setVerticalAlignment(VerticalAlignment.TOP);

				Row hedderRow = sheet.createRow(0);
				hedderRow.setHeight((short) (1.5 * sheet.getDefaultRowHeight()));
				for (int i = 0; i < column.length; i++) {
				Cell cell = hedderRow.createCell(i);
					cell.setCellValue(column[i]);
					cell.setCellStyle(headercellStyle);
					//System.out.println(i+"."+column[i]);
				}
				
				Font font = sheet.getWorkbook().createFont();
				font.setFontHeightInPoints((short) 9);
				CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
				cellStyle.setWrapText(true);
				cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
				cellStyle.setFont(font);
				int rowCount = 1;
				// data row
				for (MemberClaimeDetailsExcel memberdata : listmemberClimeDetails) {
					Row row = sheet.createRow(rowCount++);
					row.setHeight((short) (1 * sheet.getDefaultRowHeight()));
					createDataRow(memberdata, row, cellStyle);
				}
				for (int i = 0; i < column.length; i++) {
					sheet.autoSizeColumn(i);
				}
				FileOutputStream outputStream = null;
				try {
					outputStream = new FileOutputStream(excelOutputPath);
					workbook.write(outputStream);
					System.out.println("excel created .... :" + excelOutputPath);
				} catch (Exception e) {
					System.out.println("Exception in MemberClimeDetailsExcelService.getMemberClimeDetails() :" + e.toString());
				} finally {
					try {
						outputStream.close();
						workbook.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}    
			
			}

private static void createDataRow(MemberClaimeDetailsExcel memberclimedata,Row row, CellStyle cellStyle) {
	
    
    Cell cell_0= row.createCell(0);
    cell_0.setCellStyle(cellStyle);
    cell_0.setCellValue(memberclimedata.getPolicyNum());
    
    Cell cell_1 = row.createCell(1);
    cell_1.setCellStyle(cellStyle);
    cell_1.setCellValue(memberclimedata.getCompanyName());
    
    Cell cell2 = row.createCell(2);
    cell2.setCellStyle(cellStyle);
    cell2.setCellValue(memberclimedata.getBillingMonth());
		
    Cell cell3 = row.createCell(3);
    cell3.setCellStyle(cellStyle);
    cell3.setCellValue(memberclimedata.getBillNum());
    
    Cell cell4 = row.createCell(4);
    cell4.setCellStyle(cellStyle);
    cell4.setCellValue(memberclimedata.getClaimNum());
    
    Cell cell5 = row.createCell(5);
    cell5.setCellStyle(cellStyle);
    cell5.setCellValue(memberclimedata.getEmpName());
    
    Cell cell6 = row.createCell(6);
    cell6.setCellStyle(cellStyle);
    cell6.setCellValue(memberclimedata.getEmpIcOrPsprtNUm());
    
    Cell cell7 = row.createCell(7);
    cell7.setCellStyle(cellStyle);
    cell7.setCellValue(memberclimedata.getEmpId());
    
    Cell cell8 = row.createCell(8);
    cell8.setCellStyle(cellStyle);
    cell8.setCellValue(memberclimedata.getClaimantName());
    
    Cell cell9 = row.createCell(9);
    cell9.setCellStyle(cellStyle);
    cell9.setCellValue(memberclimedata.getMembersh());
		
    Cell cell_10 = row.createCell(10);
    cell_10.setCellStyle(cellStyle);
    cell_10.setCellValue(memberclimedata.getRelationShip());
		 
    Cell cell_11 = row.createCell(11);
    cell_11.setCellStyle(cellStyle);
    cell_11.setCellValue(memberclimedata.getPlanNum());
    
    Cell cell_12 = row.createCell(12);
    cell_12.setCellStyle(cellStyle);
    cell_12.setCellValue(memberclimedata.getPlandescr());
    
    Cell cell_13 = row.createCell(13);
    cell_13.setCellStyle(cellStyle);
    cell_13.setCellValue(memberclimedata.getProdCode());
    
    Cell cell_14 = row.createCell(14);
    cell_14.setCellStyle(cellStyle);
    cell_14.setCellValue(memberclimedata.getProdDescr());
    
    Cell cell_15 = row.createCell(15);
    cell_15.setCellStyle(cellStyle);
    cell_15.setCellValue(memberclimedata.getBranch());
    
    Cell cell_16 = row.createCell(16);
    cell_16.setCellStyle(cellStyle);
    cell_16.setCellValue(memberclimedata.getCostCentre());
    
    Cell cell_17 = row.createCell(17);
    cell_17.setCellStyle(cellStyle);
    cell_17.setCellValue(memberclimedata.getVisitDate());
    
    Cell cell_18 = row.createCell(18);
    cell_18.setCellStyle(cellStyle);
    cell_18.setCellValue(memberclimedata.getProvider());
    
    Cell cell_19 = row.createCell(19);
    cell_19.setCellStyle(cellStyle);
    cell_19.setCellValue(memberclimedata.getClaimeType());
		 
    Cell cell_20 = row.createCell(20);
    cell_20.setCellStyle(cellStyle);
    cell_20.setCellValue(memberclimedata.getAsoBillAmt());
    
    Cell cell_21 = row.createCell(21);
    cell_21.setCellStyle(cellStyle);
    cell_21.setCellValue(memberclimedata.getAsoclaimsPaid());
    
    Cell cell_22 = row.createCell(22);
    cell_22.setCellStyle(cellStyle);
    cell_22.setCellValue(memberclimedata.getClaimPaid());
   }
	

	public static List<MemberClaimeDetailsExcel>	getMemberClimeDetails(){
		List<MemberClaimeDetailsExcel> listmemberClimeDetails = new ArrayList<MemberClaimeDetailsExcel>();
		
		 String filerReadPath = "D:\\Test_Read\\txtFiles\\conventional\\MemberclimeDetailsExcel.txt";
		 BufferedReader br = null;
			 FileReader fr = null;
		
		try {
			fr=new FileReader(filerReadPath);
			br=new BufferedReader(fr);
			
		if(br==null || br.equals(null)) {
			System.out.println("No MemberClaimeDetails Flat File....");
		}else {
			String sCurrentline;
			int currentLine=0;
			while((sCurrentline=br.readLine())!=null) {
				//System.out.println(sCurrentline);
				MemberClaimeDetailsExcel memberClimeDetails=new MemberClaimeDetailsExcel();
				
			    String data[]=sCurrentline.split("\\|");
			   if(!data[0].equalsIgnoreCase("SUB")){
					memberClimeDetails.setPolicyNum(data[0]);
					memberClimeDetails.setCompanyName(data[1]);
					memberClimeDetails.setBillingMonth(data[2]);
					memberClimeDetails.setBillNum(data[3]);
					memberClimeDetails.setClaimNum(data[4]);
					memberClimeDetails.setEmpName(data[5]);
					memberClimeDetails.setEmpIcOrPsprtNUm(data[6]);
					memberClimeDetails.setEmpId(data[7]);
					memberClimeDetails.setClaimantName(data[8]);
					memberClimeDetails.setMembersh(data[9]);
					memberClimeDetails.setRelationShip(data[10]);
					memberClimeDetails.setPlanNum(data[11]);
					memberClimeDetails.setPlandescr(data[12]);
					memberClimeDetails.setProdCode(data[13]);
					memberClimeDetails.setProdDescr(data[14]);
					memberClimeDetails.setBranch(data[15]);
					memberClimeDetails.setCostCentre(data[16]);
					memberClimeDetails.setVisitDate(data[17]);
					memberClimeDetails.setProvider(data[18]);
					memberClimeDetails.setClaimeType(data[19]);
					memberClimeDetails.setAsoBillAmt(data[20]);
					memberClimeDetails.setAsoclaimsPaid(data[21]);
					memberClimeDetails.setClaimPaid(data[22]);
			   }
				if(currentLine!=0   ) {
					 listmemberClimeDetails.add(memberClimeDetails);
				}
				  currentLine++;
			}
			System.out.println("No of Rows : "+currentLine);
			
		}
			
		}catch(Exception e) {
			System.out.println("[MemberClaimeDetailsListingExcelService.getMemberClimeDetails()]  Exception : "+e.toString());
		}
		
			return listmemberClimeDetails;
		}
	
	// for negative or  positive value
	public String getValue(String value){
		String v=value.trim();
		char firstchar=v.charAt(0);
		char c='(';
		if(c==firstchar){
			String negativevalue=v.replace("(", "-").replace(")", "");
			return negativevalue;
		}else{
			return value;
		}
	}
	
	public void startBatch() {
		System.out.println("Starting thread ");
		
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}
 public static void main(String args[]) {
	 APTkMemberClaimeDetailsListingExcelService memberClimeExcelService=new APTkMemberClaimeDetailsListingExcelService();
	 memberClimeExcelService.startBatch();
	 System.out.println("startedd.....");
 }
	
	
}