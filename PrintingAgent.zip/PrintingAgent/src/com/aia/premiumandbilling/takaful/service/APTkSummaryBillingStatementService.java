package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.premiumandbilling.conventional.summarybilling.model.AnnualPremiumRatesTb1;
import com.aia.premiumandbilling.conventional.summarybilling.model.AnnualPremiumRatesTb2;
import com.aia.premiumandbilling.conventional.summarybilling.model.AnnualPremiumRatesTb3;
import com.aia.premiumandbilling.conventional.summarybilling.model.BillingStatementGroupHealthTbData;
import com.aia.premiumandbilling.conventional.summarybilling.model.BillingStatementGroupTermLifeTbdata;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

public class APTkSummaryBillingStatementService extends Thread {
	
	
	private Thread t;

	public void run() {
		
		genReport();
	}


public void	genReport(){
	HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> billingStatementRSDetails=getSummaryBillingSattementDetails();
	HashMap<Integer, List<BillingStatementGroupHealthTbData>> billStatementGHListDetails=getBillingStatementGroupHealthTbData();
	HashMap<Integer, List<BillingStatementGroupTermLifeTbdata>> billStatementGTLListDetails=getBillingStatementGroupTermLifeTbdata();
	HashMap<Integer, List<AnnualPremiumRatesTb1>> annualPremiumRatesTb1ListDetails=getAnnualPremiumRatesTb1Data(); 
	HashMap<Integer, List<AnnualPremiumRatesTb2>> annualPremiumRatesTb2ListDetails=getAnnualPremiumRatesTb2Data(); 
	HashMap<Integer, List<AnnualPremiumRatesTb3>> annualPremiumRatesTb3ListDetails=getAnnualPremiumRatesTb3Data(); 
	
	int noFiles=billingStatementRSDetails.size();
	    for(int i=0; i<noFiles;i++){
	    	HashMap<Integer, HashMap<String, Object>> billingStatementRS=billingStatementRSDetails.get(i);
	    	 List<BillingStatementGroupHealthTbData> billStatementGHList=billStatementGHListDetails.get(i);
	    	 List<BillingStatementGroupTermLifeTbdata> billStatementGTLList=billStatementGTLListDetails.get(i);
	    	 List<AnnualPremiumRatesTb1> annualPremiumRatesTb1List=annualPremiumRatesTb1ListDetails.get(i);
	    	 List<AnnualPremiumRatesTb2> annualPremiumRatesTb2List=annualPremiumRatesTb2ListDetails.get(i);
		     List<AnnualPremiumRatesTb3> annualPremiumRatesTb3List=annualPremiumRatesTb3ListDetails.get(i);
	    	 		
	    	 
	    	 HashMap<String, Object> dataSource=new HashMap<String, Object>();
	    	for(int a=0;a<billingStatementRS.size();a++){
	    	        dataSource.putAll(billingStatementRS.get(a));
	    	}
	    	dataSource.put("groupHealthTbDataList", billStatementGHList);
	    	dataSource.put("groupTermLifeTbDataList", billStatementGTLList);
	    	dataSource.put("annualPremiumRatesTb1List", annualPremiumRatesTb1List);
	    	dataSource.put("annualPremiumRatesTb2List",annualPremiumRatesTb2List);
	    	dataSource.put("annualPremiumRatesTb3List",annualPremiumRatesTb3List);
	    	
	    	
	    	uploadReport(dataSource);
	    }
	
	}
	
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		try {
			String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo",logo);	
			
			String templetId="APTK001";
			String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_SummaryBillingStmt";
	    	String pdfOutputpath="D:\\Test_Write\\jasperPDf\\premium\\takafull\\";
	    	String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
	    
			
			//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(invoiceTabledataList);
			String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			String jrMainReportpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\SummarBillingStatement\\summaryBilling.jasper";
			
	       // InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
			FileInputStream inputStream = new FileInputStream(jrMainReportpath);
		  String summaryBillingGhsSubReport = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\SummarBillingStatement\\summaryBillingGhsSubReport.jasper";
		  String summaryBillingGTLSubReport = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\SummarBillingStatement\\summarybillingGTLSubreport.jasper";
		  JasperReport subReport1 = (JasperReport)JRLoader.loadObjectFromFile(summaryBillingGhsSubReport);
		  JasperReport subReport2 = (JasperReport)JRLoader.loadObjectFromFile(summaryBillingGTLSubReport);
		  dataSource.put("summaryBillingGhsSubReport", subReport1);
		  dataSource.put("summaryBillingGTLSubReport", subReport2);
				
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
			
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println(templetId+"====> PDF Generated..."+pdfFullOutputPath);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} 
	}

	public static HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getSummaryBillingSattementDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\SummaryBillingStatement.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<String, Object>> billingStatementRS = new HashMap<Integer, HashMap<String, Object>>();
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> billingStatementRSDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No BillingSattement Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					
					Boolean add = false;

					HashMap<String, Object> billingStatement = new HashMap<String, Object>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						billingStatement = new HashMap<String, Object>();
						billingStatementRS = new HashMap<Integer, HashMap<String, Object>>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
					for (int i = 0; i < data.length; i++) {
						if (data[0].equalsIgnoreCase("0001")||data[0].equalsIgnoreCase("0002")||data[0].equalsIgnoreCase("0004")) {
							add = true;
							
						} 
						if (data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")) {
								billingStatement.put("policyHolder", data[2] != null && data[2].length() > 0 ? data[2].trim(): "");
								billingStatement.put("subsidiary", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
								billingStatement.put("policyNum", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("policyPeriod", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("billNum", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("dateOfIssue", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
								billingStatement.put("billingPeriod", data[8] != null && data[8].length() > 0 ? data[8].trim(): "");
								billingStatement.put("billingFrequecy", data[9] != null && data[9].length() > 0 ? data[9].trim(): "");
								billingStatement.put("adjustmentFrequency", data[10] != null && data[10].length() > 0 ? data[10].trim(): "");
								billingStatement.put("printHardCp", data[11] != null && data[11].length() > 0 ? data[11].trim(): "");
						}if (data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("2H")&&data[2].equalsIgnoreCase("GHS")) {
								billingStatement.put("ghsGroup", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0004")&&data[1].equalsIgnoreCase("1T")&&data[2].equalsIgnoreCase("GHS")) {
								billingStatement.put("ghsTtlAmntExclStPremium", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("ghsTtlAmntExclStLoadingPremium", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("ghsTtlAmntExclStAdminVitalityFee", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("ghsTtlAmntExclStTtlPremiumAdminFee", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
						} 
						
						if (data[0].equalsIgnoreCase("0004")&&data[1].equalsIgnoreCase("2T")&&data[2].equalsIgnoreCase("GHS")) {
								billingStatement.put("ghsStPremium", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("ghsStLoadingPremium", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("ghsStAdminVitalityFee", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("ghsStTtlPremiumAdminFee", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
						} 
						if (data[0].equalsIgnoreCase("0004")&&data[1].equalsIgnoreCase("3T")&&data[2].equalsIgnoreCase("GHS")) {
								billingStatement.put("ghsTtlAmntInclStPremium", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("ghsTotalAmntInclStLoadingPremium", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("ghsTtlAmntInclStAdminVitalityFee", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("ghsTtlAmntInclStTtlPremiumAdminFee", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
							}
						if (data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("2H")&&data[2].equalsIgnoreCase("GTL")) {
								billingStatement.put("gtlGroup", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
						}
						if (data[0].equalsIgnoreCase("0004")&&data[1].equalsIgnoreCase("1T")&&data[2].equalsIgnoreCase("GTL")) {
								billingStatement.put("gtlTtlAmntExclStPremium", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("gtlTtlAmntExclStLoadingPremium", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("gtlTtlAmntExclStAdminVitalityFee", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("gtlTtlAmntExclStTtlPremiumAdminFee", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
						} 
						if (data[0].equalsIgnoreCase("0004")&&data[1].equalsIgnoreCase("2T")&&data[2].equalsIgnoreCase("GTL")) {
								billingStatement.put("gtlStPremium", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("gtlStLoadingPremium", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("gtlStAdminVitalityFee", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("gtlStTtlPremiumAdminFee", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
						} 

						if (data[0].equalsIgnoreCase("0004")&&data[1].equalsIgnoreCase("3T")&&data[2].equalsIgnoreCase("GTL")) {
								billingStatement.put("gtlTtlAmntInclStPremium", data[4] != null && data[4].length() > 0 ? data[4].trim(): "");
								billingStatement.put("gtlTtlAmntInclStLoadingPremium", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
								billingStatement.put("gtlTtlAmntInclStAdminVitalityFee", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
								billingStatement.put("gtlTtlAmntInclStTtlPremiumAdminFee", data[7] != null && data[7].length() > 0 ? data[7].trim(): "");
						} 
					}
					if (add) {
						billingStatementRS.put(cuurline, billingStatement);
						cuurline++;
						billingStatementRSDetails.put(pdfgencount, billingStatementRS);
					}
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[SummaryBillingStatementService.getSummaryBillingSattementDetails] Exception: "+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return billingStatementRSDetails;
	}
	public static HashMap<Integer, List<BillingStatementGroupHealthTbData>> getBillingStatementGroupHealthTbData() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\SummaryBillingStatement.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<BillingStatementGroupHealthTbData> billStatementGHList = new  ArrayList<BillingStatementGroupHealthTbData>();
		HashMap<Integer,List<BillingStatementGroupHealthTbData>> billStatementGHListDetails = new HashMap<Integer, List<BillingStatementGroupHealthTbData>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No BillingStatement Flat file ");
			} else {
				String sCurrentLine;
				int pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					BillingStatementGroupHealthTbData billStatementGH=new BillingStatementGroupHealthTbData();
					
				
					if ( sCurrentLine.contains("****")) {
						billStatementGH=new BillingStatementGroupHealthTbData();
						billStatementGHList = new  ArrayList<BillingStatementGroupHealthTbData>();
						pdfgencount++;
					}
					String data[]=sCurrentLine.split("\\|");
						 if (data[0].equalsIgnoreCase("0003")&& data[1].equalsIgnoreCase("3D")&& data[2].equalsIgnoreCase("GHS")){
								 billStatementGH.setGhsPlan(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
								 billStatementGH.setGhsPlanDscrp((data[4] != null&& data[4].length() > 0 ? data[4].trim(): ""));
								 billStatementGH.setGhsRelationShip((data[5] != null&& data[5].length() > 0 ? data[5].trim(): ""));
								 billStatementGH.setGhsProduct(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
								 billStatementGH.setGhsNumOfMemb((data[7] != null&& data[7].length() > 0 ? data[7].trim(): ""));
								 billStatementGH.setGhsProposedSumAssured(data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
								 billStatementGH.setGhsAcceptedSumAssured(data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
								 billStatementGH.setGhsPremium(data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
								 billStatementGH.setGhsLoadingPremium(data[11] != null&& data[11].length() > 0 ? data[11].trim(): "");
								 billStatementGH.setGhsAdminVitalityFee(data[12] != null&& data[12].length() > 0 ? data[12].trim(): "");
								 billStatementGH.setGhsTotalPremiumAdminFee(data[13] != null&& data[13].length() > 0 ? data[13].trim(): "");
						 }
						 if (data[0].equalsIgnoreCase("0003")&&data[1].equalsIgnoreCase("3D")&&data[2].equalsIgnoreCase("GHS")){
							 billStatementGHList.add(billStatementGH);
							 billStatementGHListDetails.put(pdfgencount, billStatementGHList);
						 } 
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[SummaryBillingStatementService.getBillingStatementGroupHealthTbData] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return billStatementGHListDetails;
	}public static HashMap<Integer, List<BillingStatementGroupTermLifeTbdata>> getBillingStatementGroupTermLifeTbdata() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\SummaryBillingStatement.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<BillingStatementGroupTermLifeTbdata> billStatementGTLList = new  ArrayList<BillingStatementGroupTermLifeTbdata>();
		HashMap<Integer,List<BillingStatementGroupTermLifeTbdata>> billStatementGTLListDetails = new HashMap<Integer, List<BillingStatementGroupTermLifeTbdata>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No SummaryBillingStatement Flat file ");
			} else {
				String sCurrentLine;
				int currentLint = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					BillingStatementGroupTermLifeTbdata billStatementGTL=new BillingStatementGroupTermLifeTbdata();
				boolean	add=false;
					if (currentLint == 0 || sCurrentLine.contains("****")) {
						billStatementGTL=new BillingStatementGroupTermLifeTbdata();
						billStatementGTLList = new  ArrayList<BillingStatementGroupTermLifeTbdata>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						currentLint = 0;
					}
					
					String data[]=sCurrentLine.split("\\|");
					 for(int i=0; i<data.length;i++) {
						 if(data[0].equalsIgnoreCase("0003")){
							 add=true;
							
						 }
						 if (data[0].equalsIgnoreCase("0003")&& data[1].equalsIgnoreCase("3D")&& data[2].equalsIgnoreCase("GTL")){
								
							 if(i==3) {
								 billStatementGTL.setGtlPlan(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==4) {
								 billStatementGTL.setGtlPlanDscrp(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==5) {
								 billStatementGTL.setGtlRelationShip((data[i] != null&& data[i].length() > 0 ? data[i].trim(): ""));
							 }
							 if(i==6) {
								 billStatementGTL.setGtlProduct(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==7) {
								 billStatementGTL.setGtlNumOfMem(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==8) {
								 billStatementGTL.setGtlproposedSumAssured(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==9) {
								 billStatementGTL.setGtlAcceptedSumAssured(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==10) {
								 billStatementGTL.setGtlPremium(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==11) {
								 billStatementGTL.setGtlLoadingPremium(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==12) {
								 billStatementGTL.setGtlAdminVetalityFee(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==13) {
								 billStatementGTL.setGtlTtlPremiumAdminFee(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
						 }			
					 }
					 if(add){
						 if (data[0].equalsIgnoreCase("0003")&&data[1].equalsIgnoreCase("3D")&&data[2].equalsIgnoreCase("GTL")){
							 billStatementGTLList.add(billStatementGTL);
						 } 
					 }
					 currentLint++;
					 billStatementGTLListDetails.put(pdfgencount, billStatementGTLList);
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[SummaryBillingStatementService.getBillingstatementGroupTermLifeTbdata] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return billStatementGTLListDetails;
	}
	
	public static HashMap<Integer, List<AnnualPremiumRatesTb1>> getAnnualPremiumRatesTb1Data() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\SummaryBillingStatement.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<AnnualPremiumRatesTb1> annualPremiumRatesTb1List = new  ArrayList<AnnualPremiumRatesTb1>();
		HashMap<Integer,List<AnnualPremiumRatesTb1>> annualPremiumRatesTb1ListDetails = new HashMap<Integer, List<AnnualPremiumRatesTb1>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No SummaryBillingStatement Flat file ");
			} else {
				String sCurrentLine;
				int currentLint = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					AnnualPremiumRatesTb1 annualPremiumRatesTb1=new AnnualPremiumRatesTb1();
				boolean	add=false;
				
					if (currentLint == 0 || sCurrentLine.contains("****")) {
						annualPremiumRatesTb1=new AnnualPremiumRatesTb1();
						annualPremiumRatesTb1List = new  ArrayList<AnnualPremiumRatesTb1>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						currentLint = 0;
					}
					
					String data[]=sCurrentLine.split("\\|");
					 for(int i=0; i<data.length;i++) {
						 if(data[0].equalsIgnoreCase("0005")){
							 add=true;
						 }
						 if (data[0].equalsIgnoreCase("0005")&& data[1].equalsIgnoreCase("5T")){
							 
							 if(i==2) {
								 annualPremiumRatesTb1.setAprTb1Plan(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==3) {
								 annualPremiumRatesTb1.setAprTb1Prod(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==4) {
								 annualPremiumRatesTb1.setAprTb1Emp(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==5) {
								 annualPremiumRatesTb1.setAprTb1EmpSpouse(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==6) {
								 annualPremiumRatesTb1.setAprTb1EmpChildren(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==7) {
								 annualPremiumRatesTb1.setAprTb1EmpFamily(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }

						 }
						
					 }
					 if(add){
						 if (data[0].equalsIgnoreCase("0005")&& data[1].equalsIgnoreCase("5T")){
							 annualPremiumRatesTb1List.add(annualPremiumRatesTb1);
							 
						 } 
					 }
					 currentLint++;
					 annualPremiumRatesTb1ListDetails.put(pdfgencount, annualPremiumRatesTb1List);
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[SummaryBillingStatementService.getAnnualPremiumRatesTb1Data] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return annualPremiumRatesTb1ListDetails;
	}
	public static HashMap<Integer, List<AnnualPremiumRatesTb2>> getAnnualPremiumRatesTb2Data() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\SummaryBillingStatement.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<AnnualPremiumRatesTb2> annualPremiumRatesTb2List = new  ArrayList<AnnualPremiumRatesTb2>();
		HashMap<Integer,List<AnnualPremiumRatesTb2>> annualPremiumRatesTb2ListDetails = new HashMap<Integer, List<AnnualPremiumRatesTb2>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No SummaryBillingStatement Flat file ");
			} else {
				String sCurrentLine;
				int currentLint = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					AnnualPremiumRatesTb2 annualPremiumRatesTb2=new AnnualPremiumRatesTb2();
				boolean	add=false;
					if (currentLint == 0 || sCurrentLine.contains("****")) {
						annualPremiumRatesTb2=new AnnualPremiumRatesTb2();
						annualPremiumRatesTb2List = new  ArrayList<AnnualPremiumRatesTb2>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						currentLint = 0;
					}
					
					String data[]=sCurrentLine.split("\\|");
					 for(int i=0; i<data.length;i++) {
						 if(data[0].equalsIgnoreCase("0006")){
							 add=true;
						 }
						 if (data[0].equalsIgnoreCase("0006")&& data[1].equalsIgnoreCase("6T")){
							 
							 if(i==2) {
								 annualPremiumRatesTb2.setAprTb2Plan(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==3) {
								 annualPremiumRatesTb2.setAprTb2Prod(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==4) {
								 annualPremiumRatesTb2.setAprTb2Emp(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==5) {
								 annualPremiumRatesTb2.setAprTb2EmpSpouse(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==6) {
								 annualPremiumRatesTb2.setAprTb2EmpChildren(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }
							 if(i==7) {
								 annualPremiumRatesTb2.setAprTb2EmpFamily(data[i] != null&& data[i].length() > 0 ? data[i].trim(): "");
							 }

						 }
						
					 }
					 if(add){
						 if (data[0].equalsIgnoreCase("0006")&& data[1].equalsIgnoreCase("6T")){
							 annualPremiumRatesTb2List.add(annualPremiumRatesTb2);
							 
						 } 
					 }
					 currentLint++;
					 annualPremiumRatesTb2ListDetails.put(pdfgencount, annualPremiumRatesTb2List);
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[SummaryBillingStatementService.getAnnualPremiumRatesTb2Data] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return annualPremiumRatesTb2ListDetails;
	}
	
	
	public static HashMap<Integer, List<AnnualPremiumRatesTb3>> getAnnualPremiumRatesTb3Data() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\SummaryBillingStatement.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<AnnualPremiumRatesTb3> annualPremiumRatesTb3List = new  ArrayList<AnnualPremiumRatesTb3>();
		HashMap<Integer,List<AnnualPremiumRatesTb3>> annualPremiumRatesTb3ListDetails = new HashMap<Integer, List<AnnualPremiumRatesTb3>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No SummaryBillingStatement Flat file ");
			} else {
				String sCurrentLine;
				int pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					AnnualPremiumRatesTb3 annualPremiumRatesTb3=new AnnualPremiumRatesTb3();
				
					if (sCurrentLine.contains("****")) {
						annualPremiumRatesTb3=new AnnualPremiumRatesTb3();
						annualPremiumRatesTb3List = new  ArrayList<AnnualPremiumRatesTb3>();
						pdfgencount++;
						
					}
					
					String data[]=sCurrentLine.split("\\|");
					 for(int i=0; i<data.length;i++) {
						 if (data[0].equalsIgnoreCase("0007")&& data[1].equalsIgnoreCase("7T")){
								 annualPremiumRatesTb3.setAprTb3Plan(data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
								 annualPremiumRatesTb3.setAprTb3Prod(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
								 annualPremiumRatesTb3.setAprTb3Rate(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							 }
						 }
						 if (data[0].equalsIgnoreCase("0007")&& data[1].equalsIgnoreCase("7T")){
							 annualPremiumRatesTb3List.add(annualPremiumRatesTb3);
						 } 
					 annualPremiumRatesTb3ListDetails.put(pdfgencount, annualPremiumRatesTb3List);
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[SummaryBillingStatementService.getAnnualPremiumRatesTb3Data] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return annualPremiumRatesTb3ListDetails;
	}
	
	
	// helps to get negative or passitive value 
	/*public String getValue(String value){
		String v=value.trim();
		char firstchar=v.charAt(0);
		char c='(';
		if(c==firstchar){
			String negativevalue=v.replace("(", "-").replace(")", "");
			return negativevalue;
		}else{
			return value;
		}
	}*/
	
	
	
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		APTkSummaryBillingStatementService sbs = new APTkSummaryBillingStatementService();
		sbs.startBatch();
		System.out.println("startedd.....");
	}
	
}
