package com.aia.premiumandbilling.takaful.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.premiumandbilling.common.creditnote.model.CreditNoteUtil;
import com.aia.premiumandbilling.common.creditnote.model.CreditTabledata;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class APTkCreditNoteService extends Thread {
private Thread t;
	
	public void run() {
		generatePdf();
		
	}
	
	private void generatePdf() {
		
		HashMap<Integer, HashMap<Integer, HashMap<String,  Object>>> listcreditRSdetails=getCreditDetails();
		HashMap<Integer, List<CreditTabledata>> creditTabledataDetails=getCreditTabledataDetails();
		int noFiles=listcreditRSdetails.size();
		for(int i=0; i<noFiles;i++) {
		
			HashMap<Integer, HashMap<String, Object>> creditRS	=listcreditRSdetails.get(i);
		
			HashMap<String, Object> datasource=new HashMap<String, Object>();
			for(int a=0;a<creditRS.size();a++) {
				HashMap<String, Object> details=creditRS.get(a);
				datasource.putAll(details);
			}
			
			datasource.put("creditTabledataList", creditTabledataDetails.get(i));
			uploadReport(datasource);
		}
	}
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		FileInputStream finputStream=null;
		FileOutputStream outputStream =null;
		try {
			
		//JRBeanCollectionDataSource creditTabledataListdataSource = new JRBeanCollectionDataSource(creditTabledataList);
			
			   String  templetId="APTK001";
				String pdfOutputRootPath="D:\\Test_Write\\jasperPDf\\premium\\takafull\\";
				String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_CN";
				String	pdfFullOutputPath=pdfOutputRootPath+""+pdfname+".pdf";
				
				 String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				 String jrFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\takaful\\creditnote\\creditNote.jasper";
			
			
			
		    finputStream = new FileInputStream(jrFullReadpath);
			//JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, creditTabledataListdataSource);// for compiled Report .jrxml file
	        String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo_tkf.jpg"; 
			String logo = FilenameUtils.normalize(imgpath, true); 
	        //System.out.println("image path"+image);
			dataSource.put("logo",logo);
	        JasperPrint jasperPrint = JasperFillManager.fillReport(finputStream,dataSource, new JREmptyDataSource() );// for compiled Report .jrxml file
			
			outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			
			System.out.println(templetId+"==> PDF Generated..."+pdfFullOutputPath);
			
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} finally {
			try {
				finputStream.close();
			    outputStream.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public static HashMap<Integer, List<CreditTabledata>> getCreditTabledataDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\Credit.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<CreditTabledata> creditTabledataList = new  ArrayList<CreditTabledata>();
		HashMap<Integer,List<CreditTabledata>> creditTabledataListDetails = new HashMap<Integer, List<CreditTabledata>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Credit Flat file ");
			} else {
				String sCurrentLine;
				int pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					CreditTabledata creditTabledata=new CreditTabledata();
					
					if (sCurrentLine.contains("****")) {
						creditTabledata=new CreditTabledata();
						creditTabledataList = new  ArrayList<CreditTabledata>();
						pdfgencount++;
					}
					String data[]=sCurrentLine.split("\\|");
						 if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1D")){
							 creditTabledata.setDescription( data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							 creditTabledata.setBillType(data[5] != null && data[5].length() > 0 ? data[5].trim() : "");
							 creditTabledata.setAmountExSt(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
							 creditTabledata.setAmountSt(data[7] != null && data[7].length() > 0 ? data[7].trim() : "");
							 creditTabledata.setAmountInclSt( data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
					}
					 if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1D")){
						 creditTabledataList.add(creditTabledata);
						 creditTabledataListDetails.put(pdfgencount, creditTabledataList);
					 }
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[APTkCreditNoteService.getDebitdetails] Exception: "+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return creditTabledataListDetails;
	}
	
	
	
public static HashMap<Integer,HashMap<Integer, HashMap<String, Object>>> getCreditDetails(){
	HashMap<Integer, HashMap<String, Object>> creditRS=new HashMap<Integer, HashMap<String, Object>>();
	HashMap<Integer,HashMap<Integer, HashMap<String, Object>>> listcreditRSdetails=new HashMap<Integer,HashMap<Integer, HashMap<String, Object>>>();
	 String filerReadPath ="D:\\Test_Read\\txtFiles\\conventional\\Credit.txt";
	 BufferedReader br = null;
		 FileReader fr = null;
	try {
		fr=new FileReader(filerReadPath);
		br=new BufferedReader(fr);
		
	if(br==null || br.equals(null)) {
		System.out.println("No credit Flat File....");
	}else {
		String sCurrentline;
		int currentLint=0, pdfGencount=0;
		while((sCurrentline=br.readLine())!=null) {
			HashMap<String, Object> creditdata=new HashMap<String, Object>();
			if(currentLint==0 || sCurrentline.contains("****")) {
				creditdata=new HashMap<String, Object>();
				creditRS=new HashMap<Integer, HashMap<String, Object>>();
				if(sCurrentline.contains("****")) {
					pdfGencount++;
				}
				currentLint=0;	
			}
		    String data[]=sCurrentline.split("\\|");
		    if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("01")) {
				creditdata.put("companyName", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
				creditdata.put("addressLine1", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
				creditdata.put("addressLine2", data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
				creditdata.put("addressLine3", data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
				creditdata.put("addressLine4", data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
				creditdata.put("addressLine5", data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
				creditdata.put("printHardCp", data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
				creditdata.put("templetType", data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
				creditdata.put("bankName","Citibank Account No.");
				creditdata.put("bankAcNo","0111279063");
		    }
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("02")) {
				creditdata.put("billNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
				creditdata.put("dateOfIssue", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
				creditdata.put("billingPeriod", data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
				creditdata.put("paymentDueDate", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("03")) {
				creditdata.put("policyHolder", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("04") ) {
				creditdata.put("subsidiary",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("05") ) {
				creditdata.put("policyNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("06")) {
				creditdata.put("policyPeriod", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("07") ) {
				creditdata.put("poNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
            } 
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1T")&& data[2].equalsIgnoreCase("01") ) {
				creditdata.put("totalAmtExSt", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
				creditdata.put("totalAmtSt", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
				creditdata.put("totalAmountInclSt", data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1S") && data[2].equalsIgnoreCase("01")) {
				creditdata.put("reasonOfbilling", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
			}
			if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1R")&& data[2].equalsIgnoreCase("01") ) {
				creditdata.put("email",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
			}
		
		   if(data[0].equalsIgnoreCase("0001")) {
			   creditRS.put(currentLint, creditdata);
			   currentLint++;
			   listcreditRSdetails.put(pdfGencount, creditRS);
		   }
		}
	}
		
	}catch(Exception e) {
		System.out.println("[APTkCreditNoteService.getcreditDetails()]  Exception : "+e.toString());
	}finally {
		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
		return listcreditRSdetails;
	}
	

	public void startBatch() {
		System.out.println("Starting thread ");
		
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}
 public static void main(String args[]) {
	 APTkCreditNoteService creditdata=new APTkCreditNoteService();
	 creditdata.startBatch();
	 System.out.println("startedd.....");
	 
 }
}