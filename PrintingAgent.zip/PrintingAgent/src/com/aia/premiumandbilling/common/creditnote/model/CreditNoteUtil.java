package com.aia.premiumandbilling.common.creditnote.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.aia.premiumandbilling.common.creditnote.model.CreditTabledata;

public class CreditNoteUtil {
public static CreditNote getCreditNoteitObject(HashMap<String, Object> creditdatasource,List<CreditTabledata> listOfCreditTabledata) {
	CreditNote credit=new CreditNote();
	credit.setCompanyName((String) creditdatasource.get("companyName"));
    credit.setBillNum((String) creditdatasource.get("billNum"));
	credit.setDateOfIssue((String) creditdatasource.get("dateOfIssue"));
	String billPeriod= (String) creditdatasource.get("billingPeriod");
	credit.setBillingPeriodStartDate(billPeriod.substring(0, 10).trim());
	credit.setBillingPeriodEndDate(billPeriod.substring(12,23).trim());
	credit.setPaymentDueDate((String) creditdatasource.get("paymentDueDate"));
	credit.setPolicyHolder((String) creditdatasource.get("policyHolder"));
	credit.setSubsidiary((String) creditdatasource.get("subsidiary"));
	credit.setPolicyNum((String) creditdatasource.get("policyNum"));
	String policyPeriod=(String) creditdatasource.get("policyPeriod");
	credit.setPolicyPeriodStartDate(policyPeriod.substring(0,10).trim());
	credit.setPoNum((String) creditdatasource.get("poNum"));
	
	List<String> billtype=new ArrayList<String>();
	for(CreditTabledata list:listOfCreditTabledata){
		billtype.add(list.getBillType());
	}
	//System.out.println("Bill Type :"+billtype);
	credit.setBillType(billtype);
	
	return credit;
}


}
