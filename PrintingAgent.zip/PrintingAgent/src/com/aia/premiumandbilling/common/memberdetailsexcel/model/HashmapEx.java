package com.aia.premiumandbilling.common.memberdetailsexcel.model;

import java.util.HashMap;
import java.util.Map;

public class HashmapEx {

	public static void main(String[] args) {
		
		HashMap<Integer,String> hashmap = new HashMap<Integer,String>();
		System.out.println("Initial list of elements: "+hashmap);  
		hashmap.put(100, "raju");
		hashmap.put(101, "king");
		hashmap.put(102, "ken");
		hashmap.put(103, "Norris");
		hashmap.put(104, "Lin");
		hashmap.put(105, "King");
		hashmap.put(106, "abc");
		hashmap.put(107, "cdef");
		
		System.out.println("After invoking put() method "+
		hashmap.entrySet().removeIf(entriess ->entriess.getValue().equals("")));  
		
		
	      for(Map.Entry<Integer,String> m:hashmap.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
		
	    System.out.println("After invoking putIfMethod() method "); 
	      hashmap.putIfAbsent(107, "ghij");
	      for(Map.Entry<Integer, String> hm:hashmap.entrySet())
	      {
	    	  System.out.println(hm.getKey()+" "+hm.getValue());
	      }
	      
	    HashMap<Integer,String> map=new HashMap<Integer,String>();  
	    map.put(108,"Ravi");  
	    map.putAll(hashmap);  
	    System.out.println("After invoking putAll() method ");  
	    for(Map.Entry m:map.entrySet()){    
	        System.out.println(m.getKey()+" "+m.getValue());    
	       }
		
	    System.out.println("Updated list of elements:");  
	     hashmap.replaceAll((Integer,String) -> "hhh");  
	     //hashmap.replaceAll((k,v) -> "Ajay");
	     for(Map.Entry m:hashmap.entrySet())  
	     {  
	        System.out.println(m.getKey()+" "+m.getValue());   
	     }  
	}
}
