package com.aia.premiumandbilling.common.branchcostcenter.model;

public class BranchCostCenterSubTotalAmnt {
	private String branch;
	
	private Long subTtlEmpCount;
	private String subTtlEmpPremium;
	private String subTtlEmpAdminVitalityFee;

	private Long subTtlSpouseCount;
	private String subTtlSpousePremium;
	private String subTtlSpouseAdminVitalityFee;

	private Long subTtlChildCount;
	private String subTtlChildPremium;
	private String subTtlChildAdminVitalityFee;

	private Long subTtlTotalCount;
	private String subTtlTotalPremium;
	private String subTtlTotalAdminVitalityFee;
	private String subTtlTotalSt;
	private String subTtlTotalPremiumAdminVitalityFee;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public Long getSubTtlEmpCount() {
		return subTtlEmpCount;
	}
	public void setSubTtlEmpCount(Long subTtlEmpCount) {
		this.subTtlEmpCount = subTtlEmpCount;
	}
	public String getSubTtlEmpPremium() {
		return subTtlEmpPremium;
	}
	public void setSubTtlEmpPremium(String subTtlEmpPremium) {
		this.subTtlEmpPremium = subTtlEmpPremium;
	}
	public String getSubTtlEmpAdminVitalityFee() {
		return subTtlEmpAdminVitalityFee;
	}
	public void setSubTtlEmpAdminVitalityFee(String subTtlEmpAdminVitalityFee) {
		this.subTtlEmpAdminVitalityFee = subTtlEmpAdminVitalityFee;
	}
	public Long getSubTtlSpouseCount() {
		return subTtlSpouseCount;
	}
	public void setSubTtlSpouseCount(Long subTtlSpouseCount) {
		this.subTtlSpouseCount = subTtlSpouseCount;
	}
	public String getSubTtlSpousePremium() {
		return subTtlSpousePremium;
	}
	public void setSubTtlSpousePremium(String subTtlSpousePremium) {
		this.subTtlSpousePremium = subTtlSpousePremium;
	}
	public String getSubTtlSpouseAdminVitalityFee() {
		return subTtlSpouseAdminVitalityFee;
	}
	public void setSubTtlSpouseAdminVitalityFee(String subTtlSpouseAdminVitalityFee) {
		this.subTtlSpouseAdminVitalityFee = subTtlSpouseAdminVitalityFee;
	}
	public Long getSubTtlChildCount() {
		return subTtlChildCount;
	}
	public void setSubTtlChildCount(Long subTtlChildCount) {
		this.subTtlChildCount = subTtlChildCount;
	}
	public String getSubTtlChildPremium() {
		return subTtlChildPremium;
	}
	public void setSubTtlChildPremium(String subTtlChildPremium) {
		this.subTtlChildPremium = subTtlChildPremium;
	}
	public String getSubTtlChildAdminVitalityFee() {
		return subTtlChildAdminVitalityFee;
	}
	public void setSubTtlChildAdminVitalityFee(String subTtlChildAdminVitalityFee) {
		this.subTtlChildAdminVitalityFee = subTtlChildAdminVitalityFee;
	}
	public Long getSubTtlTotalCount() {
		return subTtlTotalCount;
	}
	public void setSubTtlTotalCount(Long subTtlTotalCount) {
		this.subTtlTotalCount = subTtlTotalCount;
	}
	public String getSubTtlTotalPremium() {
		return subTtlTotalPremium;
	}
	public void setSubTtlTotalPremium(String subTtlTotalPremium) {
		this.subTtlTotalPremium = subTtlTotalPremium;
	}
	public String getSubTtlTotalAdminVitalityFee() {
		return subTtlTotalAdminVitalityFee;
	}
	public void setSubTtlTotalAdminVitalityFee(String subTtlTotalAdminVitalityFee) {
		this.subTtlTotalAdminVitalityFee = subTtlTotalAdminVitalityFee;
	}
	public String getSubTtlTotalSt() {
		return subTtlTotalSt;
	}
	public void setSubTtlTotalSt(String subTtlTotalSt) {
		this.subTtlTotalSt = subTtlTotalSt;
	}
	public String getSubTtlTotalPremiumAdminVitalityFee() {
		return subTtlTotalPremiumAdminVitalityFee;
	}
	public void setSubTtlTotalPremiumAdminVitalityFee(String subTtlTotalPremiumAdminVitalityFee) {
		this.subTtlTotalPremiumAdminVitalityFee = subTtlTotalPremiumAdminVitalityFee;
	}
	
	
}
