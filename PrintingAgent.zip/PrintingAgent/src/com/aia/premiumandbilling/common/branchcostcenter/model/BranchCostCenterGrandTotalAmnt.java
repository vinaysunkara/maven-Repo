package com.aia.premiumandbilling.common.branchcostcenter.model;

public class BranchCostCenterGrandTotalAmnt {
private Long	grandTtlEmpCount;
private String	grandTtlEmpPremium;
private String	grandTtlEmpAdminVitalityFee;

private Long	grandTtlSpouseCount;
private String	grandTtlSpousePremium;
private String	grandTtlSpouseAdminVitalityFee;

private Long	grandTtlChildCount;
private String	grandTtlChildPremium;
private String	grandTtlChildAdminVitalityFee;

private Long	grandTtlTotalCount;
private String	grandTtlTotalPremium;
private String	grandTtlTotalAdminVitalityFee;
private String	grandTtlTotalSt;
private String	grandTtlTotalPremiumAdminVitalityFee;
public Long getGrandTtlEmpCount() {
	return grandTtlEmpCount;
}
public void setGrandTtlEmpCount(Long grandTtlEmpCount) {
	this.grandTtlEmpCount = grandTtlEmpCount;
}
public String getGrandTtlEmpPremium() {
	return grandTtlEmpPremium;
}
public void setGrandTtlEmpPremium(String grandTtlEmpPremium) {
	this.grandTtlEmpPremium = grandTtlEmpPremium;
}
public String getGrandTtlEmpAdminVitalityFee() {
	return grandTtlEmpAdminVitalityFee;
}
public void setGrandTtlEmpAdminVitalityFee(String grandTtlEmpAdminVitalityFee) {
	this.grandTtlEmpAdminVitalityFee = grandTtlEmpAdminVitalityFee;
}
public Long getGrandTtlSpouseCount() {
	return grandTtlSpouseCount;
}
public void setGrandTtlSpouseCount(Long grandTtlSpouseCount) {
	this.grandTtlSpouseCount = grandTtlSpouseCount;
}
public String getGrandTtlSpousePremium() {
	return grandTtlSpousePremium;
}
public void setGrandTtlSpousePremium(String grandTtlSpousePremium) {
	this.grandTtlSpousePremium = grandTtlSpousePremium;
}
public String getGrandTtlSpouseAdminVitalityFee() {
	return grandTtlSpouseAdminVitalityFee;
}
public void setGrandTtlSpouseAdminVitalityFee(String grandTtlSpouseAdminVitalityFee) {
	this.grandTtlSpouseAdminVitalityFee = grandTtlSpouseAdminVitalityFee;
}
public Long getGrandTtlChildCount() {
	return grandTtlChildCount;
}
public void setGrandTtlChildCount(Long grandTtlChildCount) {
	this.grandTtlChildCount = grandTtlChildCount;
}
public String getGrandTtlChildPremium() {
	return grandTtlChildPremium;
}
public void setGrandTtlChildPremium(String grandTtlChildPremium) {
	this.grandTtlChildPremium = grandTtlChildPremium;
}
public String getGrandTtlChildAdminVitalityFee() {
	return grandTtlChildAdminVitalityFee;
}
public void setGrandTtlChildAdminVitalityFee(String grandTtlChildAdminVitalityFee) {
	this.grandTtlChildAdminVitalityFee = grandTtlChildAdminVitalityFee;
}
public Long getGrandTtlTotalCount() {
	return grandTtlTotalCount;
}
public void setGrandTtlTotalCount(Long grandTtlTotalCount) {
	this.grandTtlTotalCount = grandTtlTotalCount;
}
public String getGrandTtlTotalPremium() {
	return grandTtlTotalPremium;
}
public void setGrandTtlTotalPremium(String grandTtlTotalPremium) {
	this.grandTtlTotalPremium = grandTtlTotalPremium;
}
public String getGrandTtlTotalAdminVitalityFee() {
	return grandTtlTotalAdminVitalityFee;
}
public void setGrandTtlTotalAdminVitalityFee(String grandTtlTotalAdminVitalityFee) {
	this.grandTtlTotalAdminVitalityFee = grandTtlTotalAdminVitalityFee;
}
public String getGrandTtlTotalSt() {
	return grandTtlTotalSt;
}
public void setGrandTtlTotalSt(String grandTtlTotalSt) {
	this.grandTtlTotalSt = grandTtlTotalSt;
}
public String getGrandTtlTotalPremiumAdminVitalityFee() {
	return grandTtlTotalPremiumAdminVitalityFee;
}
public void setGrandTtlTotalPremiumAdminVitalityFee(String grandTtlTotalPremiumAdminVitalityFee) {
	this.grandTtlTotalPremiumAdminVitalityFee = grandTtlTotalPremiumAdminVitalityFee;
}


}
