package com.aia.premiumandbilling.common.memberdtails.model;

public class MembrDetailsGrandTotal {
	private String grandTtlPremium;
	private String grandTtlLoadingPremium;
	private String grandTtlAminVitlityFee;
	private String grandTtlSt;
	private String grandTtlTotalPrmiumOrAdminFee;
	public String getGrandTtlPremium() {
		return grandTtlPremium;
	}
	public void setGrandTtlPremium(String grandTtlPremium) {
		this.grandTtlPremium = grandTtlPremium;
	}
	public String getGrandTtlLoadingPremium() {
		return grandTtlLoadingPremium;
	}
	public void setGrandTtlLoadingPremium(String grandTtlLoadingPremium) {
		this.grandTtlLoadingPremium = grandTtlLoadingPremium;
	}
	public String getGrandTtlAminVitlityFee() {
		return grandTtlAminVitlityFee;
	}
	public void setGrandTtlAminVitlityFee(String grandTtlAminVitlityFee) {
		this.grandTtlAminVitlityFee = grandTtlAminVitlityFee;
	}
	public String getGrandTtlSt() {
		return grandTtlSt;
	}
	public void setGrandTtlSt(String grandTtlSt) {
		this.grandTtlSt = grandTtlSt;
	}
	public String getGrandTtlTotalPrmiumOrAdminFee() {
		return grandTtlTotalPrmiumOrAdminFee;
	}
	public void setGrandTtlTotalPrmiumOrAdminFee(String grandTtlTotalPrmiumOrAdminFee) {
		this.grandTtlTotalPrmiumOrAdminFee = grandTtlTotalPrmiumOrAdminFee;
	}

}
