package com.aia.premiumandbilling.common.memberdtails.model;

public class MembrDetailsSubTotal {
private String subTtlPremium;
private String subTtlLoadingPremium;
private String  subTtlAminVitlityFee;
private String subTtlSt;
private String  subTtlTotalPrmiumOrAdminFee;
public String getSubTtlPremium() {
	return subTtlPremium;
}
public void setSubTtlPremium(String subTtlPremium) {
	this.subTtlPremium = subTtlPremium;
}
public String getSubTtlLoadingPremium() {
	return subTtlLoadingPremium;
}
public void setSubTtlLoadingPremium(String subTtlLoadingPremium) {
	this.subTtlLoadingPremium = subTtlLoadingPremium;
}
public String getSubTtlAminVitlityFee() {
	return subTtlAminVitlityFee;
}
public void setSubTtlAminVitlityFee(String subTtlAminVitlityFee) {
	this.subTtlAminVitlityFee = subTtlAminVitlityFee;
}
public String getSubTtlSt() {
	return subTtlSt;
}
public void setSubTtlSt(String subTtlSt) {
	this.subTtlSt = subTtlSt;
}
public String getSubTtlTotalPrmiumOrAdminFee() {
	return subTtlTotalPrmiumOrAdminFee;
}
public void setSubTtlTotalPrmiumOrAdminFee(String subTtlTotalPrmiumOrAdminFee) {
	this.subTtlTotalPrmiumOrAdminFee = subTtlTotalPrmiumOrAdminFee;
}


}
