package com.aia.premiumandbilling.conventional.summarybilling.model;

public class AnnualPremiumRatesTb2 {
	private String aprTb2Plan;	
	private String aprTb2Prod;	
	private String aprTb2Emp;
	private String aprTb2EmpSpouse;	
	private String aprTb2EmpChildren;	
	private String aprTb2EmpFamily;
	public String getAprTb2Plan() {
		return aprTb2Plan;
	}
	public void setAprTb2Plan(String aprTb2Plan) {
		this.aprTb2Plan = aprTb2Plan;
	}
	public String getAprTb2Prod() {
		return aprTb2Prod;
	}
	public void setAprTb2Prod(String aprTb2Prod) {
		this.aprTb2Prod = aprTb2Prod;
	}
	public String getAprTb2Emp() {
		return aprTb2Emp;
	}
	public void setAprTb2Emp(String aprTb2Emp) {
		this.aprTb2Emp = aprTb2Emp;
	}
	public String getAprTb2EmpSpouse() {
		return aprTb2EmpSpouse;
	}
	public void setAprTb2EmpSpouse(String aprTb2EmpSpouse) {
		this.aprTb2EmpSpouse = aprTb2EmpSpouse;
	}
	public String getAprTb2EmpChildren() {
		return aprTb2EmpChildren;
	}
	public void setAprTb2EmpChildren(String aprTb2EmpChildren) {
		this.aprTb2EmpChildren = aprTb2EmpChildren;
	}
	public String getAprTb2EmpFamily() {
		return aprTb2EmpFamily;
	}
	public void setAprTb2EmpFamily(String aprTb2EmpFamily) {
		this.aprTb2EmpFamily = aprTb2EmpFamily;
	}	

}
