package com.aia.premiumandbilling.conventional.summarybilling.model;

public class AnnualPremiumRatesTb3 {
	private String aprTb3Plan;
	private String aprTb3Prod;
	private String aprTb3Rate;
	public String getAprTb3Plan() {
		return aprTb3Plan;
	}
	public void setAprTb3Plan(String aprTb3Plan) {
		this.aprTb3Plan = aprTb3Plan;
	}
	public String getAprTb3Prod() {
		return aprTb3Prod;
	}
	public void setAprTb3Prod(String aprTb3Prod) {
		this.aprTb3Prod = aprTb3Prod;
	}
	public String getAprTb3Rate() {
		return aprTb3Rate;
	}
	public void setAprTb3Rate(String aprTb3Rate) {
		this.aprTb3Rate = aprTb3Rate;
	}
	
	

}
