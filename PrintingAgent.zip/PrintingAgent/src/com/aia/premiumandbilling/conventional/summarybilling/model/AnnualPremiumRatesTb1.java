package com.aia.premiumandbilling.conventional.summarybilling.model;

public class AnnualPremiumRatesTb1 {
	
	
	private String aprTb1Plan;
	private String aprTb1Prod;
	private String aprTb1Emp;
	private String aprTb1EmpSpouse;
	private String aprTb1EmpChildren;
	private String aprTb1EmpFamily;
	public String getAprTb1Plan() {
		return aprTb1Plan;
	}
	public void setAprTb1Plan(String aprTb1Plan) {
		this.aprTb1Plan = aprTb1Plan;
	}
	public String getAprTb1Prod() {
		return aprTb1Prod;
	}
	public void setAprTb1Prod(String aprTb1Prod) {
		this.aprTb1Prod = aprTb1Prod;
	}
	public String getAprTb1Emp() {
		return aprTb1Emp;
	}
	public void setAprTb1Emp(String aprTb1Emp) {
		this.aprTb1Emp = aprTb1Emp;
	}
	public String getAprTb1EmpSpouse() {
		return aprTb1EmpSpouse;
	}
	public void setAprTb1EmpSpouse(String aprTb1EmpSpouse) {
		this.aprTb1EmpSpouse = aprTb1EmpSpouse;
	}
	public String getAprTb1EmpChildren() {
		return aprTb1EmpChildren;
	}
	public void setAprTb1EmpChildren(String aprTb1EmpChildren) {
		this.aprTb1EmpChildren = aprTb1EmpChildren;
	}
	public String getAprTb1EmpFamily() {
		return aprTb1EmpFamily;
	}
	public void setAprTb1EmpFamily(String aprTb1EmpFamily) {
		this.aprTb1EmpFamily = aprTb1EmpFamily;
	}
	

}
