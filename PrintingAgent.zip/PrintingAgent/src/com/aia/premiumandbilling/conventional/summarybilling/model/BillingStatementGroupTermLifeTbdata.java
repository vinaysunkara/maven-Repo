package com.aia.premiumandbilling.conventional.summarybilling.model;

public class BillingStatementGroupTermLifeTbdata {
	private String gtlPlan;
	private String gtlPlanDscrp;
	private String gtlRelationShip;
	private String gtlProduct;
	private String gtlNumOfMem;
	private String gtlproposedSumAssured;
	private String gtlAcceptedSumAssured;
	private String gtlPremium;
	private String gtlLoadingPremium;
	private String gtlAdminVetalityFee;
	private String gtlTtlPremiumAdminFee;
	public String getGtlPlan() {
		return gtlPlan;
	}
	public void setGtlPlan(String gtlPlan) {
		this.gtlPlan = gtlPlan;
	}
	public String getGtlPlanDscrp() {
		return gtlPlanDscrp;
	}
	public void setGtlPlanDscrp(String gtlPlanDscrp) {
		this.gtlPlanDscrp = gtlPlanDscrp;
	}
	public String getGtlRelationShip() {
		return gtlRelationShip;
	}
	public void setGtlRelationShip(String gtlRelationShip) {
		this.gtlRelationShip = gtlRelationShip;
	}
	public String getGtlProduct() {
		return gtlProduct;
	}
	public void setGtlProduct(String gtlProduct) {
		this.gtlProduct = gtlProduct;
	}
	public String getGtlNumOfMem() {
		return gtlNumOfMem;
	}
	public void setGtlNumOfMem(String gtlNumOfMem) {
		this.gtlNumOfMem = gtlNumOfMem;
	}
	public String getGtlproposedSumAssured() {
		return gtlproposedSumAssured;
	}
	public void setGtlproposedSumAssured(String gtlproposedSumAssured) {
		this.gtlproposedSumAssured = gtlproposedSumAssured;
	}
	public String getGtlAcceptedSumAssured() {
		return gtlAcceptedSumAssured;
	}
	public void setGtlAcceptedSumAssured(String gtlAcceptedSumAssured) {
		this.gtlAcceptedSumAssured = gtlAcceptedSumAssured;
	}
	public String getGtlPremium() {
		return gtlPremium;
	}
	public void setGtlPremium(String gtlPremium) {
		this.gtlPremium = gtlPremium;
	}
	public String getGtlLoadingPremium() {
		return gtlLoadingPremium;
	}
	public void setGtlLoadingPremium(String gtlLoadingPremium) {
		this.gtlLoadingPremium = gtlLoadingPremium;
	}
	public String getGtlAdminVetalityFee() {
		return gtlAdminVetalityFee;
	}
	public void setGtlAdminVetalityFee(String gtlAdminVetalityFee) {
		this.gtlAdminVetalityFee = gtlAdminVetalityFee;
	}
	public String getGtlTtlPremiumAdminFee() {
		return gtlTtlPremiumAdminFee;
	}
	public void setGtlTtlPremiumAdminFee(String gtlTtlPremiumAdminFee) {
		this.gtlTtlPremiumAdminFee = gtlTtlPremiumAdminFee;
	}
	
	
	
}
