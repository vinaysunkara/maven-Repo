package com.aia.premiumandbilling.conventional.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.io.FilenameUtils;
import com.aia.premiumandbilling.common.debit.model.DebitTabledata;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;


public class DebitNoteService extends Thread {

	private Thread t;

	public void run() {
		
		generatePdf();
	}

	static String companyName;
	
	public  void generatePdf() {
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> debitRSdetails = getDebitDetails();
		HashMap<Integer, List<DebitTabledata>> debitTabledataListDetails=getDebitTabledataDetails();
		int noFiles = debitRSdetails.size();

		//getConnection();
		
		HashMap<String, Object> debitRSData = null;
		for (int i = 0; i < noFiles; i++) {
			HashMap<Integer, HashMap<String, Object>> debitRS = debitRSdetails.get(i);
			
			HashMap<String, Object> dataSource=new HashMap<String, Object>();
			for (int a = 0; a <debitRS.size(); a++) {
				 debitRSData = debitRS.get(a);
				dataSource.putAll(debitRSData);
			}
			//getConnection(debitRSData);
			dataSource.put("debitTabledataList",debitTabledataListDetails.get(i) );
			
			uploadDebitReport(dataSource);
			//String pdfstringdata=BytesToStringUtil.getString(pdfFullOutputPath);
		//System.out.println("Encripted Pdf in to String Data  : "+pdfstringdata);
		}
	}


/*	public void getConnection(HashMap<String, Object> debitRSData)
	{
		 Connection connection = null;
	        Statement stmt = null;
	        try
	        {
	            Class.forName("com.mysql.jdbc.Driver");
	            connection = DriverManager
	                .getConnection("jdbc:mysql://localhost:3306/JDBCDemo", "root", "password");
	            stmt = connection.createStatement();
	            
	            //String firstName = debitRSData.
	            stmt.execute("INSERT INTO TableName (ID,COMPANY_NAME,LAST_NAME,STAT_CD) "
	                                + "VALUES (1,companyName,'Gupta',5)");
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        }
	       finally {
	            try {
	                stmt.close();
	                connection.close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	}*/
	
	
	public  void uploadDebitReport(HashMap<String, Object> dataSource) {
		FileInputStream finputStream=null;
		FileOutputStream outputStream =null;
		try {
			String pdfOutputRootPath="D:\\Test_Write\\jasperPDf\\conventional\\";
			String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_DN";
			String pdfFullOutputPath=pdfOutputRootPath+""+pdfname+".pdf";
			

			//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(debitTabledataList);
			String templetId=null;
			String jrFullReadpath=null;
			if(dataSource.get("templetType").equals("GI")){
			    templetId="AIAGIB001";
				 String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				 jrFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\generalinsurence\\debitnote\\debitNote.jasper";
			}else{
				 templetId="AIACON001";
				 String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
				 jrFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\conventional\\debitnote\\debitNote.jasper";
			}
			// InputStream inputStream =this.getClass().getResourceAsStream("/report.jasper");
		    finputStream = new FileInputStream(jrFullReadpath);
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
			
		    String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			String logo = FilenameUtils.normalize(imgpath, true); 
			dataSource.put("logo",logo);
			
			JasperPrint jasperPrint = JasperFillManager.fillReport(finputStream,dataSource,new JREmptyDataSource());
			outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println(templetId+"==> PDF Generated..."+pdfFullOutputPath);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} finally {
			try {
				finputStream.close();
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getDebitDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\Debit.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<String, Object>> invoicresult = new HashMap<Integer, HashMap<String, Object>>();
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> listDebitDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Debit Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					// System.out.println("getDebitDetails() : sCurrentLine "+sCurrentLine);
                  HashMap<String, Object> debit = new HashMap<String, Object>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						debit = new HashMap<String, Object>();
						invoicresult = new HashMap<Integer, HashMap<String, Object>>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
					
					//companyName =data[3];
					
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("01")) {
						debit.put("companyName", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
						debit.put("addressLine1", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
						debit.put("addressLine2", data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
						debit.put("addressLine3", data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
						debit.put("addressLine4", data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
						debit.put("addressLine5", data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
						debit.put("printHardCp", data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
						debit.put("templetType", data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
						debit.put("bankName","Citibank Account No.");
						debit.put("bankAcNo","0111279063");
					
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("02")) {
						debit.put("billNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
						debit.put("dateOfIssue", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
						debit.put("billingPeriod", data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
						debit.put("paymentDueDate", data[6] != null && data[6].length() > 0 ? data[6].trim(): "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("03")) {
						debit.put("policyHolder", data[3] != null && data[3].length() > 0 ? data[3].trim(): "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("04") ) {
						debit.put("subsidiary",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("05") ) {
						debit.put("policyNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("06")) {
						debit.put("policyPeriod", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")&& data[2].equalsIgnoreCase("07") ) {
						debit.put("poNum",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
                    } 
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1T")&& data[2].equalsIgnoreCase("01") ) {
						debit.put("totalAmtExSt", data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
						debit.put("totalAmtSt", data[5] != null && data[5].length() > 0 ? data[5].trim(): "");
						debit.put("totalAmountInclSt", data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1S") && data[2].equalsIgnoreCase("01")) {
						debit.put("reasonOfbilling", data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					}
					if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1R")&& data[2].equalsIgnoreCase("01") ) {
						debit.put("email",data[3] != null && data[3].length() > 0 ? data[3].trim() : "");
					}
				   if (data[0].equalsIgnoreCase("0001")) {
						invoicresult.put(cuurline, debit);
						cuurline++;
						listDebitDetails.put(pdfgencount, invoicresult);
					}
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[Debit.getDebitdetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listDebitDetails;
	}
	
	
	public static HashMap<Integer, List<DebitTabledata>> getDebitTabledataDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\debit.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<DebitTabledata> debitTabledataList = new  ArrayList<DebitTabledata>();
		HashMap<Integer,List<DebitTabledata>> debitTabledataListDetails = new HashMap<Integer, List<DebitTabledata>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Debit Flat file ");
			} else {
				String sCurrentLine;
				int currentLint = 0, pdfgencount = 0;
				while ((sCurrentLine = br.readLine()) != null) {
					DebitTabledata debitTabledata=new DebitTabledata();
					
					if (currentLint == 0 || sCurrentLine.contains("****")) {
						debitTabledata=new DebitTabledata();
						debitTabledataList = new  ArrayList<DebitTabledata>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						currentLint = 0;
					}
					
					String data[]=sCurrentLine.split("\\|");
						 if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1D")){
							  debitTabledata.setDescription( data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							  debitTabledata.setBillType(data[5] != null && data[5].length() > 0 ? data[5].trim() : "");
							  debitTabledata.setAmountExSt(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
							  debitTabledata.setAmountSt(data[7] != null && data[7].length() > 0 ? data[7].trim() : "");
							  debitTabledata.setAmountInclSt( data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
						}
						 if (data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1D")){
						 debitTabledataList.add(debitTabledata);
						 debitTabledataListDetails.put(pdfgencount, debitTabledataList);
						}
					
				}
			
			}

		} catch (FileNotFoundException e) {
			System.out.println("[Debit.getDebitdetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return debitTabledataListDetails;
	}
	
	
	
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		DebitNoteService debit = new DebitNoteService();
		debit.startBatch();
		System.out.println("startedd.....");
	}
}