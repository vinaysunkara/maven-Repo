package com.aia.premiumandbilling.conventional.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import org.apache.commons.io.FilenameUtils;

import com.aia.premiumandbilling.common.memberdtails.model.MemberDetails;
import com.aia.premiumandbilling.common.memberdtails.model.MemberDetilsTableData;
import com.aia.premiumandbilling.common.memberdtails.model.MembrDetailsGrandTotal;
import com.aia.premiumandbilling.common.memberdtails.model.MembrDetailsSubTotal;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

public class MemrDetailsService {
	
	//For Vitality 
	String vitalityFlag = null;
	String flag = null;
	ArrayList<String> al= new ArrayList<String> ();
	
		
	public void genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> membrDetailsdataRS=getMembrDetailsReportDetails();
		HashMap<Integer, List<MemberDetails>> memberDetailsListRS= getMemberDetailsTableDetails();
							
		int noFile=membrDetailsdataRS.size();
		for(int i=0; i<noFile;i++){
			HashMap<String, Object> dataSource =new HashMap<String, Object>();
			HashMap<Integer, HashMap<String, Object>> membrDetailsdata=membrDetailsdataRS.get(i);
			for(int j=0; j<membrDetailsdata.size();j++){
				dataSource.putAll(membrDetailsdata.get(j));
			}
			dataSource.put("memberDetilsList", memberDetailsListRS.get(i));
			uploadReport(dataSource);
	  }	
	
	}
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		try {
			//JRBeanCollectionDataSource beandataSource = new JRBeanCollectionDataSource(listBranchCostCenter);
			String path="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
		    String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_memberDetails";
				String pdfOutputpath="D:\\Test_Write\\jasperPDf\\";
				String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
				String templetId=null;
				String jrMainReportFullReadpath=null;
				String jrSubReportFullReadpath =null;
				//For vitalityFlag condition	
			for(String flag:al)
				{

				if(dataSource.get("templetType").equals("GI")){
					if(flag.equalsIgnoreCase("Y"))
					{
						templetId="AIAGIB001";
						jrMainReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\generalinsurence\\memberdtails\\memberdeatls.jasper";
						jrSubReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\generalinsurence\\memberdtails\\memberDetailsSubReport.jasper";
					}
					else{
						
						templetId="AIAGIB001";
						jrMainReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\generalinsurence\\memberdtails\\memberdeatls_vitality.jasper";
						jrSubReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\generalinsurence\\memberdtails\\memberDetailsSubReport_vitality.jasper";
					}
				    
					}else{
						if(flag.equalsIgnoreCase("Y"))	{
							templetId="AIACON001";
							jrMainReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\conventional\\memberdtails\\memberdeatls.jasper";
							jrSubReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\conventional\\memberdtails\\memberDetailsSubReport.jasper";
						} else
						{
							templetId="AIACON001";
							jrMainReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\conventional\\memberdtails\\memberdeatls_vitality.jasper";
							jrSubReportFullReadpath = path+"PrintingAgentReports\\premiumandbilling\\conventional\\memberdtails\\memberDetailsSubReport_vitality.jasper";
						}
						
						}
				
				
			
				
	       FileInputStream mainreportinputStream = new FileInputStream(jrMainReportFullReadpath);
	       JasperReport subreport = (JasperReport)JRLoader.loadObjectFromFile(jrSubReportFullReadpath);
	       dataSource.put("memberDetilsSubReport", subreport);
		  //JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
	       String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
		   String image= FilenameUtils.normalize(imgpath, true); 
		   dataSource.put("image",image);
			JasperPrint jasperPrint = JasperFillManager.fillReport(mainreportinputStream,dataSource, new JREmptyDataSource());
			//JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,datasource, beandataSource);//
			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println(templetId+" PDF Generated..."+pdfFullOutputPath);
			mainreportinputStream.close();
			outputStream.close();
				}
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} 
	}
	
	public HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getMembrDetailsReportDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\MEMBER_DETAILS__updated.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> membrDetailsdataRS = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();
		HashMap<Integer, HashMap<String, Object>> membrDetailsdata = new HashMap<Integer, HashMap<String, Object>>();
		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No MemberDetils Report Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					// System.out.println("getDebitDetails() : sCurrentLine "+sCurrentLine);
			//	boolean  add=false;
					HashMap<String, Object> membrDetails = new HashMap<String, Object>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						membrDetails = new HashMap<String, Object>();
						membrDetailsdata = new HashMap<Integer, HashMap<String, Object>>();
						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					
					String[] data = sCurrentLine.split("\\|");
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")) {
								membrDetails.put("policyHolder",data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
							    membrDetails.put("subsidiary",data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
							    membrDetails.put("policyNum",data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							    membrDetails.put("policyPeriod",data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
							    membrDetails.put("billNum",data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
							    membrDetails.put("dateOfIssue",data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
							    membrDetails.put("billingPeriod",data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
							    membrDetails.put("billingFrequecy",data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
							    membrDetails.put("adjustmentFrequency",data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
							    membrDetails.put("printHardCp",data[11] != null&& data[11].length() > 0 ? data[11].trim(): "");
							    membrDetails.put("templetType",data[12] != null&& data[12].length() > 0 ? data[12].trim(): "");
							    //For Vitality||Admin fee 
							    membrDetails.put("Vitality fee",data[15] != null&& data[15].length() > 0 ? data[15].trim(): "");
							    if(membrDetails.containsKey("Vitality fee"))
							    {
							    	vitalityFlag=(String) membrDetails.get("Vitality fee");
							    	al.add(vitalityFlag);
							    	System.out.println("vitalityFalg : "+vitalityFlag);
							    }
							    
						}
						
						//END For Vitality 
						//Iterator hmIterator = membrDetails.entrySet().iterator(); 
					
					
				/*		while (hmIterator.hasNext()) { 
				            Map.Entry mapElement = (Map.Entry)hmIterator.next(); 
				           // int marks = ((int)mapElement.getValue() + 10); 
				            
				             flag = ((String)mapElement.getValue());
				            System.out.println(flag);
				            
				            
				           // System.out.println(mapElement.getKey() + " : " + marks); 
				        }*/ 
						
						//End For Vitality 
						if(data[0].equalsIgnoreCase("0001")&& data[1].equalsIgnoreCase("1H")){
							membrDetailsdata.put(cuurline, membrDetails);
							cuurline++;
							membrDetailsdataRS.put(pdfgencount, membrDetailsdata);
						}
				}
			}

		} catch (Exception e) {
			System.out.println("[MembrDetailsSrvice.getMembrDetailsReportDetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		}finally{
			try {
				br.close();
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return membrDetailsdataRS;
	}
	public HashMap<Integer, List<MemberDetails>> getMemberDetailsTableDetails(){
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\MEMBER_DETAILS__updated.txt";
		HashMap<Integer, List<MemberDetails>> memberDetailsListRS=new HashMap<Integer, List<MemberDetails>>();
		List<MemberDetails> memberDetailsList=new ArrayList<MemberDetails>();
		List<MemberDetilsTableData> memberDetilsTableDataList=new ArrayList<MemberDetilsTableData>();
		List<MembrDetailsSubTotal> membrDetailsSubTotalList=new ArrayList<MembrDetailsSubTotal>();
		List<MembrDetailsGrandTotal> membrDetailsGrandTotalList=new ArrayList<MembrDetailsGrandTotal>();
		BufferedReader br = null;
		FileReader fr = null;
		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Member Details Flat file ");
			} else {
				String sCurrentLine;
				int pdfgencount = 0;
				while ((sCurrentLine = br.readLine()) != null) {
					MemberDetails membrDetails = new MemberDetails();
					MemberDetilsTableData memberDetilsTableData=new MemberDetilsTableData();
					MembrDetailsSubTotal membrDetailsSubTotal=new MembrDetailsSubTotal();
					MembrDetailsGrandTotal membrDetailsGrandTotal=new MembrDetailsGrandTotal();
					//boolean add = false;
					if (sCurrentLine.contains("****")) {
						membrDetails = new MemberDetails();
						memberDetailsList=new ArrayList<MemberDetails>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						
					}

					String data[] = sCurrentLine.split("\\|");
					
						if (data[0].equalsIgnoreCase("0002")) {
							memberDetilsTableDataList=new ArrayList<MemberDetilsTableData>();
							membrDetailsSubTotalList=new ArrayList<MembrDetailsSubTotal>();
							membrDetailsGrandTotalList=new ArrayList<MembrDetailsGrandTotal>();
						
						}

						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")) {
							memberDetilsTableData.setMemberNameOrNum(data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
							memberDetilsTableData.setAge(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
							memberDetilsTableData.setRel(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
							memberDetilsTableData.setPlan(data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
							memberDetilsTableData.setProduct(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
							memberDetilsTableData.setProposedSumassure(data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
							memberDetilsTableData.setAcceptedSumassure(data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
							memberDetilsTableData.setIncreasedOrDecrSumassure(data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
							memberDetilsTableData.setUwStatus(data[10] != null&& data[10].length() > 0 ? data[10].trim(): "");
							memberDetilsTableData.setPremium(data[11] != null&& data[11].length() > 0 ? data[11].trim(): "");
							memberDetilsTableData.setLoadingPremium(data[12] != null&& data[12].length() > 0 ? data[12].trim(): "");
							memberDetilsTableData.setAdminVitlityFee(data[13] != null&& data[13].length() > 0 ? data[13].trim(): "");
							memberDetilsTableData.setSt(data[14] != null&& data[14].length() > 0 ? data[14].trim(): "");
							memberDetilsTableData.setTotalPrmiumOrAdminFee(data[15] != null&& data[15].length() > 0 ? data[15].trim(): "");
							memberDetilsTableData.setEffectiveDate(data[16] != null&& data[16].length() > 0 ? data[16].trim(): "");	
							memberDetilsTableData.setMovementType(data[17] != null&& data[17].length() > 0 ? data[17].trim(): "");	
							memberDetilsTableDataList.add(memberDetilsTableData);
							
						}
						membrDetails.setMemberDetilsTableData(memberDetilsTableDataList);
						 
					    	 if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1T")) {
					    		 membrDetailsSubTotal.setSubTtlPremium(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					    		 membrDetailsSubTotal.setSubTtlLoadingPremium(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
					    		 membrDetailsSubTotal.setSubTtlAminVitlityFee(data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
					    		 membrDetailsSubTotal.setSubTtlSt(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
					    		 membrDetailsSubTotal.setSubTtlTotalPrmiumOrAdminFee(data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
					    		 
					    		 membrDetailsSubTotalList.add(membrDetailsSubTotal);
					    	 }
					    	    	
					    	 membrDetails.setMembrDetailsSubTotal(membrDetailsSubTotalList);
					    	
					  	 if(data[0].equalsIgnoreCase("0004")) {
					    		 membrDetailsGrandTotal.setGrandTtlPremium(data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
					    		 membrDetailsGrandTotal.setGrandTtlLoadingPremium(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					    		 membrDetailsGrandTotal.setGrandTtlAminVitlityFee(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
					    		 membrDetailsGrandTotal.setGrandTtlSt(data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
					    		 membrDetailsGrandTotal.setGrandTtlTotalPrmiumOrAdminFee(data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
					    		 
					    		 membrDetailsGrandTotalList.add(membrDetailsGrandTotal);
					    	 }
					    	 membrDetails.setMembrDetailsGrandTotal(membrDetailsGrandTotalList);
					    	 
					   if (data[0].equalsIgnoreCase("0002")) {
						   memberDetailsList.add(membrDetails);
						   memberDetailsListRS.put(pdfgencount, memberDetailsList);
						}
				}
			}
                     
		} catch (Exception e) {
			System.out.println(
					"[BranchCostCenterReportService.getBranchCstCenterTbleData()] Exception: " + e.toString());
			e.printStackTrace();
		}
		return memberDetailsListRS;
		
	}
	
	public static void main(String args[]){
		MemrDetailsService m=new MemrDetailsService();
		m.genReport();
		
	}
	
}
