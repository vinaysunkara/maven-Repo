package com.aia.premiumandbilling.conventional.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.aia.premiumandbilling.common.commisionstatement.model.CommissionStatementTableData;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

public class CommisionStatementService extends Thread{

	private Thread t;

	public void run() {
		genReport();
	}

	public void genReport(){
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> commissionStatementdataRS=getCommissionStatementDetails();
		HashMap<Integer,List<CommissionStatementTableData>> commissionStatementTbleDataListDetails=	getCommissionStatementTableData();
		int noFiles=commissionStatementdataRS.size();
		System.out.println("pdf files :"+noFiles);
		for(int i=0;i<noFiles;i++) {
			HashMap<Integer, HashMap<String, Object>> commissionStatementdata=commissionStatementdataRS.get(i);
			List<CommissionStatementTableData> commissionStatementTbleDataList=commissionStatementTbleDataListDetails.get(i);
			
			HashMap<String, Object> dataSource=new HashMap<String, Object>();
			
			for (int a = 0; a <commissionStatementdata.size(); a++) {
				HashMap<String, Object> details = commissionStatementdata.get(a);
				dataSource.putAll(details);
			}
			for(CommissionStatementTableData c:commissionStatementTbleDataList){
				System.out.println(c.getProduct()+"  "+c.getDescription()+"  "+c.getCommission()+"  "+c.getAmount());
				
			}
			dataSource.put("commissionStatementTbleDataList", commissionStatementTbleDataList);
			uploadReport(dataSource);
		}
	}
	
	public  void uploadReport(HashMap<String, Object> dataSource) {
		try {
			 String imgpath=this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath()+"../../img/logo.jpg"; 
			   String logo= FilenameUtils.normalize(imgpath, true); 
			   dataSource.put("logo",logo);
			   
			
			System.out.println("Total amount : "+dataSource.get("totalAmnt"));
			String pdfname=dataSource.get("policyNum")+"_"+dataSource.get("billNum")+"_CommStmt";
			String pdfOutputpath="D:\\Test_Write\\jasperPDf\\premium\\conventional\\";
			String pdfFullOutputPath=pdfOutputpath+""+pdfname+".pdf";
			
			String jrReadpath="D:\\Users\\itt0284\\JaspersoftWorkspace\\";
			String jrFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\conventional\\commissionStatement\\CommStmt.jasper";
			String  jrSubReportFullReadpath = jrReadpath+"PrintingAgentReports\\premiumandbilling\\conventional\\commissionStatement\\commissionStmtSubReport.jasper";
			//JRBeanCollectionDataSource beandataSource = new JRBeanCollectionDataSource(commissionStatementTbleDataList);
			 
	       FileInputStream inputStream = new FileInputStream(jrFullReadpath);
	      // FileInputStream inputStream = new FileInputStream(jrSubReportFullReadpath);
			
			//JasperReport jasperReport =JasperCompileManager.compileReport(inputStream);
	      
		   JasperReport subreport = (JasperReport)JRLoader.loadObjectFromFile(jrSubReportFullReadpath);
           
		   dataSource.put("commissionStmtSubReport",subreport);
			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, new JREmptyDataSource());// for compiled Report .jrxml file
			//JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,dataSource, beandataSource);// for compiled Report .jrxml file

			FileOutputStream outputStream = new FileOutputStream(pdfFullOutputPath);
			JasperExportManager.exportReportToPdfStream(jasperPrint,outputStream);
			System.out.println("PDF Generated..."+pdfFullOutputPath);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} 
	}
	
	
	
	public HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> getCommissionStatementDetails() {
		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\Commissionstmnt.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<Integer, HashMap<String, Object>>> commissionStatementdataRS = new HashMap<Integer, HashMap<Integer, HashMap<String, Object>>>();
		HashMap<Integer, HashMap<String, Object>> commissionStatementdata = new HashMap<Integer, HashMap<String, Object>>();
		
		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No CommissionStatement Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					// System.out.println("getDebitDetails() : sCurrentLine "+sCurrentLine);
					Boolean add = false;
					HashMap<String, Object> commissionStatement = new HashMap<String, Object>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						commissionStatement = new HashMap<String, Object>();
						commissionStatementdata = new HashMap<Integer, HashMap<String, Object>>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
						if (data[0].equalsIgnoreCase("0001")||data[0].equalsIgnoreCase("0003")) {
							add = true;
						} 
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H")){
							commissionStatement.put("companyName",data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
					
							commissionStatement.put("address1",data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					
							commissionStatement.put("address2",data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
						
							commissionStatement.put("address3",data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
						
							commissionStatement.put("address4",data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
						
							commissionStatement.put("address5",data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
					
							commissionStatement.put("address6",data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
						
							commissionStatement.put("printHardCp",data[9] != null&& data[9].length() > 0 ? data[9].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("2H")) {
							commissionStatement.put("policyHolder",data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
				
							commissionStatement.put("subsidiary",data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
					
							commissionStatement.put("policyNum",data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
						
							commissionStatement.put("policyPeriod",data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
						
							commissionStatement.put("billNum",data[6] != null&& data[6].length() > 0 ? data[6].trim(): "");
					
							commissionStatement.put("dateOfIssue",data[7] != null&& data[7].length() > 0 ? data[7].trim(): "");
					
							commissionStatement.put("billingPeriod",data[8] != null&& data[8].length() > 0 ? data[8].trim(): "");
						}
						if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("1T")) {
								commissionStatement.put("totalAmnt",data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
						}
					if(add){
						commissionStatementdata.put(cuurline, commissionStatement);
						cuurline++;
						commissionStatementdataRS.put(pdfgencount, commissionStatementdata);
					}
					
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("[CommissionStatementService.getCommissionStatementDetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return commissionStatementdataRS;
	}
	
	
	
	private HashMap<Integer, List<CommissionStatementTableData>> getCommissionStatementTableData() {

		String FILENAME = "D:\\Test_Read\\txtFiles\\conventional\\Commissionstmnt.txt";

		BufferedReader br = null;
		FileReader fr = null;
		List<CommissionStatementTableData> commissionStatementTableDataList = new  ArrayList<CommissionStatementTableData>();
		HashMap<Integer,List<CommissionStatementTableData>> commissionStatementTableDataListListDetails = new HashMap<Integer, List<CommissionStatementTableData>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No CommissionStatement Flat file ");
			} else {
				String sCurrentLine;
				int  pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					CommissionStatementTableData commissionStatementTbleData=new CommissionStatementTableData();
					if ( sCurrentLine.contains("****")) {
						commissionStatementTbleData=new CommissionStatementTableData();
						commissionStatementTableDataList = new  ArrayList<CommissionStatementTableData>();
							pdfgencount++;
					}
					
					String data[]=sCurrentLine.split("\\|");
						 if(data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
								    commissionStatementTbleData.setProduct(data[2] != null&& data[2].length() > 0 ? data[2].trim(): "");
									commissionStatementTbleData.setDescription(data[3] != null&& data[3].length() > 0 ? data[3].trim(): "");
									commissionStatementTbleData.setCommission(data[4] != null&& data[4].length() > 0 ? data[4].trim(): "");
									commissionStatementTbleData.setAmount(data[5] != null&& data[5].length() > 0 ? data[5].trim(): "");
								
							}
					 if(data[0].equalsIgnoreCase("0002") && data[1].equalsIgnoreCase("1D")) {
						 commissionStatementTableDataList.add(commissionStatementTbleData);
							
						}
					 commissionStatementTableDataListListDetails.put(pdfgencount, commissionStatementTableDataList);
				}
				
			}

		} catch (FileNotFoundException e) {
			System.out.println("[CommissionStatementService.getcommissionStatementTbleData] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return commissionStatementTableDataListListDetails;
	}
	
	
	
	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		CommisionStatementService c = new CommisionStatementService();
		c.startBatch();
		System.out.println("startedd.....");
	}
}
